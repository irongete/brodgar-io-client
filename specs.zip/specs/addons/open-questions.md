# Open Questions — ALL RESOLVED

> **Status:** 🟢 Closed for design · **Spec:** AddOns
> Every design question is now resolved into a decision ([decisions.md](decisions.md)). This file
> is kept as the resolution index. Items marked *(tunable)* are decided in principle; only numeric
> limits may be adjusted during implementation — they do not block starting.

| # | Question | Resolution |
|---|---|---|
| Q-001 | How far on actions/automation? | **[D-025](decisions.md)** — Phase 4, config-gated (`addons.actions.enabled=false`), declared per-addon permission (D-027) |
| Q-002 | Account-wide saved data location | **[D-023](decisions.md)** — `savedata/account/<addon>.json`; per-var `scope` in manifest |
| Q-003 | LuaJ jar placement/classpath | **[D-014](decisions.md)** — `lib/brodgar/`, Ant-fetched, one manifest token |
| Q-004 | Dev vs release addon dir | **[D-015](decisions.md)** — `-Dhaven.addondir` override → jar-sibling → cwd |
| Q-005 | Manifest format | **[D-016](decisions.md)** — JSON (`manifest.json`) |
| Q-006 | JSON library | **[D-016](decisions.md)** — one small bundled Java JSON lib, exposed as `hafen.json` |
| Q-007 | Sandbox strictness | **[D-017](decisions.md)** — strict whitelist; no `io`/`os.execute`/reflection |
| Q-008 | Targeting a specific server window | **[D-024](decisions.md)** — a widget descriptor `{id,type,place,caption,parentType}` |
| Q-009 | Watchdog policy | **[D-018](decisions.md)** — instruction hard-stop + soft per-tick budget *(limits tunable)* |
| Q-010 | Load order & deps | **[D-019](decisions.md)** — topological, no LoadOnDemand v1 |
| Q-011 | Naming convention | **[D-020](decisions.md)** — namespaced `hafen.*` only |
| Q-012 | Hook priority/ordering | **[D-021](decisions.md)** — integer priority, first-preventDefault-wins |
| Q-013 | Token set & item addressing | **[D-022](decisions.md)** — `player`/`partyN`/`target`; `mouseover` deferred; items handle-only |
| Q-014 | Which gaps to design next | **[D-026](decisions.md)** — widget-tree mechanism → map → study/FEP → action bar → radar → slash → rest |

## Deferred to implementation (decided in principle, detail-tuned in-phase)

- **Watchdog numeric limits** (instruction cap, per-tick ms budget) — default given in [D-018](decisions.md); tune against real addons.
- **`"mouseover"` token** — deferred to a later phase (needs hover hit-test tracking); not v1 ([D-022](decisions.md)).
- **Per-subsystem API detail** for the coverage gaps (map/markers, action bar, study/FEP, kin, speed,
  crafting, quests, slash) — contract-level surface is in [api-reference.md](api-reference.md); each
  is fully detailed in its build phase ([15-implementation-plan.md](15-implementation-plan.md)).

> New questions that arise during implementation should be added back here (Q-015+) and resolved
> before the affected phase starts.
