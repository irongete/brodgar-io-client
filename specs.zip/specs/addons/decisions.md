# Decision Log (ADR-lite)

> **Status:** 🟢 Living · **Spec:** AddOns
> Each entry: decision, rationale, alternatives considered, and status.
> Referenced from other docs as `D-00x`.

Legend: ✅ Accepted · 🔄 Revisit later · ❌ Rejected · 💤 Superseded.

---

### D-001 — Addons live in a client-local `addons/` directory ✅
**Decision.** Addons are folders under an `addons/` directory resolved relative to the client
install (next to `hafen.jar`), **not** under `%APPDATA%`. Each addon is one subfolder, e.g.
`addons/partyframes/`, `addons/betterfishing/`.
**Rationale.** User preference; matches WoW's `Interface/AddOns/<name>/` model; keeps the client
self-contained and inspectable. The client already resolves jar-relative paths via
[`Utils.srcpath`](src/haven/Utils.java:122).
**Alternatives.** `Config.localdir()` = `%APPDATA%\Haven and Hearth` — rejected by user.
**See.** [02-filesystem-and-build.md](02-filesystem-and-build.md).

### D-002 — Saved data in a separate `savedata/<genus>_<char>/` tree as JSON ✅
**Decision.** Addon persistent data lives under a **separate** `savedata/` directory (sibling of
`addons/`), with one subfolder per **`<genus>_<character>`** combination, containing `.json`
files written by addons: `savedata/<genus>_<charname>/<addon>.json`.
**Rationale.** User preference; per-character scoping matches how the client already namespaces
state; JSON is portable and human-inspectable. `genus` and `chrid` are real fields on
[`GameUI`](src/haven/GameUI.java:257).
**Open.** Account-wide (shared) saved data location — see [Q-002](open-questions.md).
**See.** [02-filesystem-and-build.md](02-filesystem-and-build.md).

### D-003 — LuaJ runtime jar built via Ant, not committed ✅
**Decision.** The Lua runtime is **LuaJ**, shipped as a jar handled exactly like the voice jar:
built/placed via Ant for local testing and releases, **not** committed to the repo.
**Rationale.** User preference; consistent with the existing `lib/brodgar/*.jar` handling, which
is already gitignored ([`.gitignore`](.gitignore)).
**Implication.** The jar must be fetched/placed by an Ant target (mirroring the `extlib`
pattern) and referenced on the classpath; see [Q-003](open-questions.md) for exact placement.
**See.** [02-filesystem-and-build.md](02-filesystem-and-build.md), [04-engine.md](04-engine.md).

### D-004 — AddOns management is in-game only (initially) ✅
**Decision.** The **AddOns** options panel is available **in-game** only (via
[`OptWnd`](src/haven/OptWnd.java) inside `GameUI`), not on the login/character-select screen.
**Rationale.** User preference; `OptWnd` already lives in `GameUI`; pre-login management is extra
wiring for little initial value.
**Revisit.** Pre-login management is a possible later enhancement.
**See.** [10-options-panel.md](10-options-panel.md).

### D-005 — "Reload UI" reloads the addon layer only ✅
**Decision.** Reload UI tears down and rebuilds **only the addon layer** (all Lua state + every
resource addons created) from disk, keeping the session connected and the native/server-driven
Java UI untouched.
**Rationale.** In Hafen the base UI is Java and server-driven; the client cannot rebuild those
widgets without the server resending them (a reconnect). Reloading the addon layer delivers the
WoW dev-loop intent (edit Lua → reload → see changes, no relog), which is the part that matters.
**Alternatives.** Full rebuild incl. server UI ≈ a soft relog — heavier, flickers, out of scope.
**See.** [05-lifecycle-and-reload.md](05-lifecycle-and-reload.md).

### D-006 — Enable/disable uses the WoW model (apply on reload) ✅ — **default narrowed by [D-027](decisions.md)**
**Decision.** Toggling an addon's checkbox updates the persisted enabled-set and marks "changes
pending"; the change is applied on **Reload UI** (or next login), not live.
**Rationale.** User preference; predictable; avoids partial live-load edge cases. Live
enable/disable is a possible later enhancement (cheap once teardown is proven, since Reload needs
teardown anyway).
**Default (D-027).** A newly-discovered addon defaults to **enabled** — EXCEPT an addon that declares
the `"actions"` write permission, which defaults to **disabled** (opt-in per addon). The apply-on-reload
model is unchanged.
**See.** [10-options-panel.md](10-options-panel.md), [05-lifecycle-and-reload.md](05-lifecycle-and-reload.md).

### D-007 — Specification language is English ✅
**Decision.** All `specs/addons/**` documents are written in English. (Conversational
collaboration may be in Spanish.)
**Rationale.** User preference.

### D-008 — The engine lives in `src/io/brodgar/addon/`; Lua is a stable facade ✅
**Decision.** Engine + bridge live in a new `io.brodgar.addon` package. Addons target a stable
Lua facade (`hafen.*`) and never touch `haven.*` directly. `haven`-package helpers are used only
where package-private access is required.
**Rationale.** Isolates upstream churn (P1); enables complete resource ownership/teardown (P2);
mirrors the non-invasive voice-integration pattern.
**See.** [01-architecture.md](01-architecture.md).

### D-009 — Widget replacement is "wrap, don't reimplement" ✅
**Decision.** To replace native UI, keep the real server-bound widget as a hidden **model** and
present a custom **view**, delegating interactions to the real widget. Do not reimplement the
server protocol.
**Rationale.** Protocol fidelity for free; robust against content/version differences. Verified
that hidden widgets still receive `uimsg`/`addchild` (delivery is by id, not visibility).
**See.** [08-widget-replacement.md](08-widget-replacement.md).

### D-010 — Actions API (`hafen.act`) is gated behind explicit opt-in ✅ (finalized by [D-025](decisions.md))
**Decision (provisional).** The action/automation surface is delivered in a later phase and
gated behind an explicit opt-in.
**Rationale.** Write-actions let an addon act on the player's behalf, so they are an explicit,
user-granted permission; read/UI tiers only change presentation and are ungated. Scope of the action
tier is still open — see [Q-001](open-questions.md).
**See.** [12-security-and-permissions.md](12-security-and-permissions.md).

### D-011 — Invasiveness is acceptable where it yields materially better features ✅
**Decision.** The earlier "minimize core edits" priority is **relaxed**. The addon system may edit
the `haven` core (add first-class hook points, hookable subclasses, dispatch instrumentation)
when doing so enables substantially better capabilities. Minimal-edit seams are still preferred
*when equivalent*, but are no longer a hard constraint.
**Rationale.** User direction: for the addon system, good features outweigh strict
non-invasiveness. Enables a proper hook/interception system (pre/post/replace, `preventDefault`).
**Consequences.** Supersedes the strict framing of [G10](00-vision-scope.md); the invasiveness
ledger ([11-core-hooks.md](11-core-hooks.md)) becomes a *record* of edits, not a *budget*. Still
keep edits centralized and tagged (`// addon:`) so upstream merges stay manageable.
**See.** [13-hooks-and-interception.md](13-hooks-and-interception.md).

### D-012 — Reference-based reads, ONE flat calling style, unified under `hafen.gob` ✅
**Decision.** Entities are addressed by an explicit **reference**, like WoW unit tokens — not
implicit global state. A **GobRef** is a gob id (number) or a token (`"player"`, `"partyN"`,
`"target"`). There is **exactly one** calling style: a **flat accessor** `hafen.gob.<attr>(ref)`
(e.g. `hafen.gob.health("player")`) — **no** parallel handle/OO style for gobs ([D-013](decisions.md)).
All per-gob reads live under **`hafen.gob.*`**; `hafen.player`/`hafen.char`/`hafen.party` hold only
data with no per-gob equivalent. Reference accessors **re-resolve each call** (fresh; nil if gone);
**snapshots** (bulk enumeration via `hafen.world.gobs`) are point-in-time copies. **Items/widgets**
are addressed by **handles** (no stable token).
**Rationale.** Matches the WoW model the user referenced; a single canonical way ([D-013](decisions.md));
avoids stale-pointer bugs; fits Hafen (gobs have a stable `long id` and can despawn).
**Open.** The exact **token set** (`"mouseover"`? others) and item addressing — [Q-013](open-questions.md).
**See.** [api-reference.md](api-reference.md).

### D-013 — One canonical way per operation (no dual APIs) ✅
**Decision.** The Lua API exposes **exactly one** way to do each thing; we do not ship parallel
styles for the same operation (e.g. flat accessor vs handle-method for gob reads). For gob reads,
the chosen way is the flat reference accessor ([D-012](decisions.md)).
**Rationale.** User preference: *"no quiero ofrecer dos formas de hacer las cosas."* Smaller
surface, less to document, fewer ways to get subtly wrong.
**Consequences.** Handles still exist where they are the *only* natural model (items, windows) —
that is the one way for those, not a duplicate. Applies to all future API-surface decisions.

---

## Design-closure decisions (resolve all open questions)

### D-014 — LuaJ jar in `lib/brodgar/`, Ant-fetched, one manifest token ✅ (closes Q-003)
`org.luaj:luaj-jse:3.0.1` placed in `lib/brodgar/` (auto compile-classpath + auto-copy to
`bin/lib/`); a new Ant `extlib`-style target fetches it (not committed, like the voice jar); append
`lib/luaj-jse-3.0.1.jar` to the manifest `Class-Path` at [build.xml:147](build.xml:147) — the one
non-glob build line, so this token is mandatory.

### D-015 — Addon-dir default = the client's `addons/` (jar-sibling); `-Dhaven.addondir` override only ✅ (closes Q-004)
**Default, with no config: the `addons/` folder inside the client** —
`Utils.srcpath(...).resolveSibling("addons")` (= `bin/addons/` at runtime). `-Dhaven.addondir=<path>`
is an **optional override only** — it is **NOT** baked into the `run` target, so nothing needs to be
typed normally. The `bin` build step copies the repo `addons/` (first-party addons) into `bin/addons/`.
Same scheme for `savedata/`. Resolution order: override → jar-sibling → `./addons`.

### D-016 — Manifest and saved data are JSON; one small bundled JSON facility ✅ (closes Q-005, Q-006)
`manifest.json` (not TOML) and saved data are **JSON**. Ship one minimal JSON library (Java,
Ant-managed like the other jars) used for both manifest parsing and saved-var (de)serialization,
exposed to Lua as `hafen.json`. One format, one parser, no TOML dependency. **Supersedes the TOML
placeholder in [03-addon-format.md](03-addon-format.md).**

### D-017 — Strict default sandbox ✅ (closes Q-007)
Per-addon `_ENV`. Expose `string,table,math,os.time/clock/date,select,pairs,ipairs,next,type,
tostring,tonumber,pcall,xpcall,error,assert,unpack`. Withhold `io,os.execute/exit/getenv/remove/
rename,dofile,loadfile,load(path),unrestricted require,debug`. `require` resolves only within the
addon's own folder. **No Java reflection from Lua** (facade only). See [12-security-and-permissions.md](12-security-and-permissions.md).

### D-018 — Watchdog: instruction hard-stop + soft per-tick budget ✅ (closes Q-009)
LuaJ instruction-count hook aborts a single callback at a hard cap; plus a soft per-addon per-tick
time budget (default ~4 ms) — repeated violations auto-disable the addon. Both limits configurable
in `haven-config.properties`; defaults ship. See [04-engine.md](04-engine.md).

### D-019 — Topological load order, no LoadOnDemand v1 ✅ (closes Q-010)
Order by `dependencies`/`optional_dependencies` (topological), alphabetical-by-id tiebreak. No
LoadOnDemand initially. See [03-addon-format.md](03-addon-format.md).

### D-020 — Namespaced `hafen.*` only, no flat globals ✅ (closes Q-011)
API is namespaced (`hafen.gob.health(ref)`), no flat-global aliases (`GobHealth`). Avoids `_G`
pollution, is discoverable, and sandboxes cleanly. Terseness comes from the token, not the name.

### D-021 — Hook priority: integer priority, first-preventDefault-wins ✅ (closes Q-012)
Handlers carry an optional integer `priority` (default 0), registration-order tiebreak. First
`preventDefault` skips the default; later pre-hooks still run unless one calls `stopPropagation`;
post-hooks all run. Warn when two addons both `preventDefault` the same point. See
[13-hooks-and-interception.md](13-hooks-and-interception.md).

### D-022 — Token set + items handle-only ✅ (closes Q-013)
Tokens: `"player"`, `"party1".."partyN"` (ordered by `Member.seq`), `"target"` (combat only).
`"mouseover"` **deferred** (needs hover hit-test tracking — a later phase). Items are addressed
**by handle only** (no `(container,slot)` alternative), honoring [D-013](decisions.md).

### D-023 — Saved-data scope: per-char + account-wide ✅ (closes Q-002)
Per-character: `savedata/<genus>_<char>/<addon>.json` (default). Account-wide:
`savedata/account/<addon>.json`. A saved-var declared in the manifest can be marked
`"scope": "account"`; default is per-character.

### D-024 — Widget-replacement targeting via a descriptor ✅ (closes Q-008)
The replace handler receives a **widget descriptor** `{id, type, place, caption, parentType}`
(place-string + caption + parent type) so the addon decides per-instance which window it is
(main inventory vs a cupboard). See [08-widget-replacement.md](08-widget-replacement.md).

### D-025 — Actions tier: Phase 4, config-gated, permission notice ✅ (closes Q-001; finalizes D-010) — **refined by [D-027](decisions.md)**
`hafen.act.*` ships in Phase 4, **disabled by default** via `addons.actions.enabled=false`
(`haven-config.properties`); enabling surfaces a notice that addons will be able to act on the
player's behalf. Read/UI/event tiers are unaffected. See [12-security-and-permissions.md](12-security-and-permissions.md).
**Refinement (D-027).** The single global flag is kept as the **master switch**, but the opt-in is
now a **per-addon permission model**: the switch alone is not enough — an addon must ALSO declare the
capability. The user-facing control moves from a config-only flag to the AddOns panel checkbox.

### D-026 — Gap design/build order ✅ (closes Q-014)
Order: **widget-tree-read mechanism** ([14-widget-tree-reads.md](14-widget-tree-reads.md), foundational)
→ A5 overlays (done) → A1 map/markers → A4 study/curiosity/FEP → A3 action bar → A2 radar/GobIcon settings
→ A11 slash commands → A6–A10. Rationale: the widget-tree mechanism unblocks vitals/buffs/char/FEP/
action bar at once ([coverage-gaps.md](coverage-gaps.md) B1/C2), so it comes first.

### D-027 — Write-actions are a declared per-addon PERMISSION + a global master switch ✅ (refines D-010/D-025; maintainer, 2026-07-25) — **master switch dropped by [D-028](decisions.md)**
**Decision.** The gated write/automation tier (`hafen.act.*` and every per-subsystem *(gated action)*
verb) is granted to an addon only when **BOTH** hold — a two-part permission model, like app permissions:
1. **Global master switch ON.** For now the `haven-config.properties` flag `addons.actions.enabled`
   (default `false`; a config edit / `-Daddons.actions.enabled=true` enables it, restart to apply). Slice
   **4b** layers a **persisted, panel-toggled pref** on top of it (an **AddOns-panel checkbox**, with a
   notice that addons will be able to act on your behalf) so it can be flipped at runtime. This is the
   *user's* choice. (The switch reads the config flag ONLY until 4b — with no runtime toggle yet, a stray
   persisted pref must not be able to strand it ON with no UI to turn it off.)
2. **The addon DECLARED the permission** in its manifest: `"permissions": ["actions"]` (an array, so it
   can grow into finer categories — `"actions.move"`, `"actions.items"`, … — without a format change).
   This is the *addon author's* responsibility, and it lets the client tell the user, **before** the addon
   runs, that it wants to drive the character (the basis for a future "this addon moves your character /
   interacts with objects" breakdown at enable-time).

`requireActions(owner, verb)` enforces both with a **distinct** error for each (missing declaration vs.
master off). `hafen.act.enabled()` reports the **granted** state (both halves) so an addon can adapt.

**Consequences.**
- **Addons that declare `"actions"` are DISABLED BY DEFAULT** when newly discovered (opt-in per addon) —
  a narrowing of [D-006](decisions.md)'s "default-enabled"; **read-only addons keep default-enabled**.
- **Turning the master switch OFF disables the write-declaring addons entirely** (they don't load — a
  read+write addon loses its reads too; chosen for simplicity/safety over partial loading).
- Supersedes the provisional `:addons actions on|off` console command (4a) — the control is the panel
  checkbox; the console command is removed.
- The engine stays **server-authoritative** regardless: the permission gates *convenience/automation*,
  not capability — an addon can still only send what a player click could send. The permission exists so
  the **user stays in control** of which addons act on their behalf, not for any client-security reason.
**Rationale.** Maintainer direction: reads and writes should both be plain `hafen.*` API usable by
addons, with the only difference being an explicit *permission* for writes — declared by the addon and
authorized by the user — not a surface bolted onto the `:addons` console command.
**See.** [12-security-and-permissions.md](12-security-and-permissions.md), [10-options-panel.md](10-options-panel.md).
Order: **widget-tree-read mechanism** ([14-widget-tree-reads.md](14-widget-tree-reads.md), foundational)
→ A5 overlays (done) → A1 map/markers → A4 study/curiosity/FEP → A3 action bar → A2 radar/GobIcon settings
→ A11 slash commands → A6–A10. Rationale: the widget-tree mechanism unblocks vitals/buffs/char/FEP/
action bar at once ([coverage-gaps.md](coverage-gaps.md) B1/C2), so it comes first.

### D-028 — Write-actions permission is PER-ADDON ONLY; drop the global master switch ✅ (refines D-027; maintainer, 2026-07-25)
**Decision.** Remove the global master switch that [D-027](decisions.md) point 1 introduced. The gated
write/automation tier (`hafen.act.*` and every per-subsystem *(gated action)* verb) is now granted to an
addon by a **single condition**: the addon **declared** the `"actions"` permission in its manifest
(`"permissions": ["actions"]`). The action tier is **always available at the system level** — there is no
config flag, no persisted `addons/actions.enabled` pref, and no AddOns-panel "Allow addon actions (writes)"
checkbox. **The user's control is entirely per-addon:** a write-declaring addon is **disabled by default**
(opt-in; kept from D-027, via the persisted `addons/actions.seen` set) and **enabling it in the AddOns panel
raises a consent dialog** (slice **4c**, `ActionsConsentWnd`) that spells out it will act on your behalf. So a
running write addon is, by construction, one the user **knowingly permitted** — enabling **is** the grant.

`requireActions(owner, verb)` now checks **only** the manifest declaration (throws a guiding Lua error if
absent). `actionsGranted(owner)` (backing `hafen.act.enabled()`) is therefore just "did this addon declare
`"actions"`" — always true for a running write addon.

**Consequences.**
- **Removed:** `AddonManager.actionsEnabled()` / `setActionsEnabled()`, the `addons.actions.enabled` config
  flag + `addons/actions.enabled` pref, the panel master checkbox, `loadAll`'s master-switch load gate, and
  the `blocked: actions off` status. **Kept:** the per-addon default-disabled policy (`scanAddonDefaults` /
  `applyActionsDefaults` + `addons/actions.seen`) and the 4c consent dialog — together they ARE the permission.
- A write addon now **loads as soon as it is enabled** (like any addon); no second global toggle to also flip.
- Simpler + one canonical control: the user grants/revokes the permission by **enabling/disabling the addon**
  (with the consent prompt on enable), instead of a two-part (global switch × per-addon) gate.
- Still **server-authoritative**: the permission gates *which addons* may act, never *what* they can send.
**Rationale.** Maintainer direction (2026-07-25): the global on/off was redundant with the per-addon opt-in —
"las actions están habilitadas siempre, pero hay que darle permisos individualmente a cada addon". The
per-addon consent (4c) already makes granting a knowing, explicit act; a second global switch added friction
without adding user control. One canonical way: enable-with-consent = grant.
**See.** [12-security-and-permissions.md](12-security-and-permissions.md), [10-options-panel.md](10-options-panel.md),
[D-027](decisions.md) (the model this refines), [D-006](decisions.md) (default-enabled, narrowed for write addons).

### D-029 — Virtual entities (world ghosts) are client-only and SAFE-tier (not gated) ✅ (maintainer, 2026-07-25)
**Decision.** Addons may place **client-only virtual objects** in the 3D world ("ghosts") via
`hafen.ghost.new` (spec [16-virtual-entities.md](16-virtual-entities.md)). A ghost is a `Gob` with **no
server id**, rendered by adding its node to the MapView scene (the [`Plob`](src/haven/MapView.java:1779)
template) — it is **never** sent to the server. Therefore it is a **safe-tier** capability, alongside
`hafen.ui.overlay`/`gobOverlay`, **not** the gated actions tier: **no** `"permissions": ["actions"]`, **no**
consent dialog. Committing a real build stays the gated `hafen.act.place`.
**Rationale.** N1 (server-authoritative) is preserved because nothing reaches the server and no gameplay
advantage is conferred — a ghost is a visualization, like a HUD overlay. N2 (MapView not replaced) is
preserved because ghosts **overlay on** the scene; the vision doc already permits this. Gating a purely
visual, client-only aid would be miscategorising it (cf. the [[hafen-botting-allowed]] framing: the gate is a
user-control for *actions on your behalf*, which a ghost is not).
**See.** [16-virtual-entities.md](16-virtual-entities.md), [00-vision-scope.md](00-vision-scope.md) (N1/N2),
[07-ui-and-drawing.md](07-ui-and-drawing.md).

### D-030 — Ghosts use a dedicated `hafen.ghost.*` namespace, addressed by a HANDLE (not a GobRef) ✅ (maintainer, 2026-07-25)
**Decision.** The whole subsystem lives under a **dedicated `hafen.ghost.*` namespace** (`hafen.ghost.new`
to create, `hafen.ghost.list` to enumerate this addon's ghosts, `hafen.ghost.gizmo` for the transform gizmo)
— keeping `hafen.world.*` about scanning the *server* world. `hafen.ghost.new{...}` returns a bridge-owned
**handle** with flat verb methods (`:move`/`:rotate`/`:scale`/`:setRes`/`:tint`/`:alpha`/`:show`/`:hide`/
`:clickable`/`:pos`/`:destroy`), exactly like the `Window` handle — **not** a GobRef. Rationale: a ghost has
no server id, so the GobRef re-resolve model
([D-012](decisions.md)) is meaningless; and it is addon-owned and interactive, which is precisely the case the
conventions assign to handles ("Interactive things return handles", [api-reference.md](api-reference.md)).
Still **one canonical way** ([D-013](decisions.md)) — flat verbs on the handle, no OO/ref alternative.
**See.** [16-virtual-entities.md](16-virtual-entities.md) §3, [07-ui-and-drawing.md](07-ui-and-drawing.md).

### D-031 — The transform gizmo (`hafen.ghost.gizmo`) is a Lua library over Java primitives ✅ (maintainer, 2026-07-25)
**Decision.** The move/rotate/scale gizmo is **not** a monolithic Java widget. Java exposes
**primitives** — ghosts ([D-029](decisions.md)), `hafen.map.screenToWorld` (the [`Maptest`](src/haven/MapView.java:1810)
ground raycast), the existing `hafen.player.worldToScreen`, `hafen.hook.input`+`preventDefault` (2c), a `grab`
helper, and clickable ghost handles + a pick event ([D-032](decisions.md), V2) — and the gizmo **behaviour**
(handle hit-test, drag→delta math, axis constraint, snapping, apply) lives in a **bundled Lua library** shipped
in the `planner` example addon. Primary path = **3D-native clickable handles** (reusing the V2 ghost pick);
2D-projected handles are a fallback.
**Rationale.** Keeps the capability addon-native and iterable without recompiling Java, matches the project
ethos (engine exposes primitives, addons orchestrate — like `LuaGobOverlay`), and lets the hard interaction
design evolve in Lua. **Consequence:** the reusable gizmo Lua module is a first-party asset — a candidate for a
shared `lib/` once addon-to-addon reuse exists.
**See.** [16-virtual-entities.md](16-virtual-entities.md) §4.

### D-032 — Ghosts are opt-in CLICKABLE via client-only pick detection (still SAFE-tier) ✅ (maintainer, 2026-07-25)
**Decision.** Ghost entities are **clickable** (`clickable=true` / `g:clickable(bool)`, opt-in per ghost),
so an addon can select / drag / context-menu them — the core need for a planner. Clickability is **client-only
detection** and stays **SAFE-tier** (reinforces [D-029](decisions.md)): the engine pick pass returns the ghost,
the bridge fires `GhostClicked{ghost,button,x,y}` + the per-ghost `onClick`, and **nothing is sent to the
server**. The click is intercepted in [`MapView.Click.hit`](src/haven/MapView.java:2017) — **before** its
`wdgmsg("click", …)` — the same choke point the voice feature already hooks ([:2018](src/haven/MapView.java:2018));
if the picked object is a client ghost the intercept dispatches to the addon and returns (consume). A ghost has
no server id, so a server click for it would be bogus anyway.
**Consequences.**
- Pulls a clickable-ghost + `GhostClicked` slice **forward to V2** (was folded into the V5 "3D-native handles"
  polish). The gizmo's 3D-native handles then reuse the same pick, so pixel-perfect handle picking comes for free.
- Adds the **second** small `// addon:` MapView edit (the `Click.hit` intercept) alongside V1's add-gob seam.
- **No hijacking normal play:** clickability is opt-in (decorative ghosts never win a pick) and the handler
  chooses to consume or pass the click through to the default (walk / interact behind the ghost).
- Boundary intact: the only way a ghost click reaches the server is if the addon then calls a **gated**
  `hafen.act.*` verb, which needs the `"actions"` permission on its own. The clickability never contacts the server.
**Rationale.** Maintainer direction (2026-07-25): "quiero que los gobs ghosts sean clicables". Compatible with N1
(no server contact, no advantage) and with the safe-tier classification, since detection ≠ action.
**See.** [16-virtual-entities.md](16-virtual-entities.md) §3 (Clickability), [D-029](decisions.md) (safe-tier).

### D-033 — Ghost move/rotate reuse the client's placement snapping (placegrid / placeangle) ✅ (maintainer, 2026-07-25)
**Decision.** Moving and rotating a ghost — via the gizmo, or `:move`/`:rotate` with `snap="place"` —
**reuse the client's existing placement snapper** instead of a bespoke one, so it feels **identical to
placing a real building**. The engine adjusts a placement ghost ([`Plob`](src/haven/MapView.java:1779))
through [`PlobAdjust`](src/haven/MapView.java:1740) / [`StdPlace`](src/haven/MapView.java:1746), governed
by two **public, persisted** settings — [`MapView.plobpgran`](src/haven/MapView.java:57) (the
**placegrid**, `:placegrid <n>`, default 8) and [`MapView.plobagran`](src/haven/MapView.java:58) (the
**placeangle**, `:placeangle <n>`, default 12). The subsystem exposes `hafen.map.snapPlace`/`snapAngle`
(the `StdPlace` math) + `hafen.map.placeGrid`/`placeAngle` (read the settings), and the gizmo snaps
through them **by default**, honouring the same **SHIFT** (fine grid / free) and **CTRL/SHIFT**
(rotation) modifiers. `StdPlace` semantics reused verbatim: position → tile centre by default, SHIFT →
`plobpgran` sub-tile grid (or free at 0); rotation → 45° (π/4), SHIFT → `π/plobagran` fine.
**Consequences.**
- Lives in the gizmo slices — **placegrid in V5** (move), **placeangle in V6** (rotate). `:move`/
  `:rotate` stay raw/exact unless `snap="place"` is passed.
- Reading the settings is **zero core edit** (both fields are `public static`). Two implementation
  options for the math (D-009 tension): **(preferred)** a tiny `// addon:` refactor factoring
  `StdPlace`'s math into shared static `MapView.placeSnap*` helpers that both `StdPlace` and the bridge
  call (no drift); **(fallback)** mirror the small pure math in the bridge. Either respects a live
  `:placegrid`/`:placeangle`.
- The user's existing placegrid/placeangle preference automatically applies to ghosts — one setting,
  one behaviour, for both real placement and planning.
**Rationale.** Maintainer direction (2026-07-25): "al mover y rotar los ghosts quiero que funcione con
el sistema de placegrid y el otro que hay para rotaciones". Faithful reuse (D-009) over reinvention.
**See.** [16-virtual-entities.md](16-virtual-entities.md) §4.1, [D-009](decisions.md) (wrap-not-reimplement).

### D-034 — Custom (non-`.res`) rendering is a new `hafen.render.*` namespace ✅ (maintainer, 2026-07-26)
**Decision.** Rendering of assets that are **NOT engine `.res`** — **PNG images** (on screen and in the world) and
**custom 3D models** ([glTF](18-custom-models-gltf.md)) — lives in a **new `hafen.render.*` namespace**, separate
from `hafen.ghost`. **`hafen.ghost` is reserved for `.res` game models** and is **unchanged** (maintainer:
"hafen.ghost lo quiero únicamente para crear gobs como ahora, modelos del juego"). The path exposes the substrate
`.res` already uses: a `.res` image layer is PNG bytes decoded with `ImageIO.read` → [`TexI`](src/haven/TexI.java:52)
([`Resource.readimage`](src/haven/Resource.java:1061)); the 3D side builds the engine's own
[`Model`](src/haven/render/Model.java:45)/[`Material`](src/haven/Material.java:143) from glTF instead of a `.res`.
Surface (five capabilities, [17-custom-rendering.md](17-custom-rendering.md) §1):
- **loaders** — `hafen.render.image(path)` (PNG→`TexI`) · `hafen.render.model(path)` (glTF→mesh, [D-035](decisions.md));
  addon-relative + sandboxed ([`Addon.dir`](src/io/brodgar/addon/Addon.java:173); `..`/absolute rejected, [D-017](decisions.md)); cached, bridge-owned.
- **screen 2D** — `g:image`/`g:aimage` on [`LuaGOut`](src/io/brodgar/addon/LuaGOut.java) → [`GOut.image`](src/haven/GOut.java:97)/`aimage`.
- **world 2D** — `hafen.render.sprite{image=,billboard=…}` — a **billboard** ([`SpeakerIcon` `PView.Render2D`](src/haven/SpeakerIcon.java:44) screen blit, faces camera) or a **fixed** `TexI`-quad ([`SprDrawable`](src/haven/SprDrawable.java:40)).
- **world 3D** — `hafen.render.object{model=…}` — glTF `Model`s behind `SprDrawable`.
**Consequences.**
- **Shared virtual-entity core.** `ghost`, `render.sprite`, and `render.object` all build on **one** placement
  engine — the **generalized V-series core** ([16-virtual-entities.md](16-virtual-entities.md)): a client-only
  virtual `Gob` + `MapView.addClientGob` + `Placed` transform + `GhostGob.obstate` (tint/alpha/scale) + teardown +
  the **gizmo** ([D-031](decisions.md)). Only the **visual** differs (`Drawable` attr): `ResDrawable` (.res) /
  `TexI`-quad / glTF `Model`s. The gizmo works on any transform handle. This is an internal refactor, **not** a
  change to `hafen.ghost`'s public surface.
- **SAFE-tier, not gated** — client-only visualization like `hafen.ui.overlay`/ghosts ([D-029](decisions.md));
  nothing reaches the server. Sandbox: own assets only; no shadowing of client `.res`.
- **Likely zero-to-minimal `haven` core edit** for images/2D (`GOut.image`/`aimage`, `TexI`, `SprDrawable`,
  `Material`, `Model` all public); the glTF loader is `io.brodgar.addon` over our [`Json`](src/io/brodgar/addon/Json.java).
- Built as the **R-series** (R1 screen-2D, R2 world-2D, R3 glTF-3D) — one slice + one in-game verification each.
**Rationale.** Maintainer direction (2026-07-26), re-scoped from an earlier "extend `hafen.ghost`" draft:
`hafen.ghost` stays a pure `.res` tool; all custom-asset rendering is a sibling namespace. Reflects the maintainer's
own instinct ("a lo mejor esto podría ir en `hafen.render`"). Faithful reuse of the substrate ([D-009](decisions.md)),
one canonical home per concern ([D-013](decisions.md)).
**See.** [17-custom-rendering.md](17-custom-rendering.md), [18-custom-models-gltf.md](18-custom-models-gltf.md), [D-035](decisions.md), [D-030](decisions.md).

### D-035 — Custom 3D models use glTF 2.0 (static subset first) ✅ (maintainer, 2026-07-26)
**Decision.** The custom-model format ([D-034](decisions.md) #4, `hafen.render.model`/`object`) is **glTF 2.0**
(maintainer choice 2026-07-26, over OBJ/FBX). **v1 = the STATIC subset**: `.glb` (single-file binary) preferred,
`.gltf`+external buffers too; static meshes (`POSITION`/`NORMAL`/`TEXCOORD_0` + indices), multiple
nodes/meshes/primitives with **baked** node transforms, PBR **baseColor** only (factor + texture), alpha modes
OPAQUE/MASK/BLEND, double-sided. **Deferred:** skins/joints, **keyframe animation**, morph targets, full PBR maps,
Draco/meshopt. Parsed by a **hand-rolled pure-Java** reader over [`Json`](src/io/brodgar/addon/Json.java) (accessors
decoded by hand via `ByteBuffer` little-endian; data-URIs via `java.util.Base64`; textures via `ImageIO`) — **no
native dependency** (the reason FBX is rejected: it effectively needs Assimp/JNI). Each glTF primitive → an engine
`Model` + `Material` (baseColor `TexI.st()`), collected in a `Sprite` behind `SprDrawable` on the shared core.
**Consequences.**
- **Two hard bits, flagged early** ([18-custom-models-gltf.md](18-custom-models-gltf.md) §4): (1) a fixed
  **basis/units conversion** (glTF right-handed +Y-up metres → the H&H world axes/tile scale), baked once; (2)
  **PBR→engine shading** — the client isn't PBR, so v1 draws **unlit baseColor** (R3a/b) and adds **basic lighting**
  via `NORMAL` + the engine light state only in **R3c**; fidelity approximates, not matches, a PBR viewer.
- Sub-sliced **R3a** (parse + static mesh, unlit) → **R3b** (textures + multi-material + alpha) → **R3c** (lighting
  polish); animation is a later series.
- Unsupported glTF features fail with a **clear addon-facing error** (name the missing feature), never a client
  crash; vertex/primitive counts are capped with a logged limit ([D-018](decisions.md) spirit).
**Rationale.** glTF is the open, modern runtime standard (scene + material graph + optional animation) — richer than
OBJ, and unlike FBX needs no proprietary/native lib. Static-first keeps the first delivery bounded and pure-Java.
**See.** [18-custom-models-gltf.md](18-custom-models-gltf.md), [17-custom-rendering.md](17-custom-rendering.md), [D-034](decisions.md).

### D-036 — JSON is a `hafen.json` namespace (parse/encode), reusing the existing reader + writer ✅ (maintainer, 2026-07-26)
**Decision.** Expose JSON to addons as **`hafen.json.parse(str)`** (JSON string → Lua value) and
**`hafen.json.encode(value)`** (Lua value → compact JSON string) — **not** the maintainer's first-draft
`hafen.utils.parseJSON`; a `utils` grab-bag violates [D-020](decisions.md)/[D-013](decisions.md) (namespaced by
concern). It **reuses what already exists**: the dependency-free reader [`Json.parse`](src/io/brodgar/addon/Json.java:25)
(manifests + saved vars today) and the compact writer [`AddonManager.json`](src/io/brodgar/addon/AddonManager.java:8250)
(REPL echo + `hafen.store` today). The **one refactor** ([D-013](decisions.md)): move the writer into
[`Json`](src/io/brodgar/addon/Json.java) as `Json.write(LuaValue[, strict])` so reader + writer live together and
the REPL, `hafen.store`, `hafen.json.encode`, and the `hafen.http` JSON-body path all call **one** serializer (no drift).
**Consequences.**
- `parse`: JSON object → string-keyed table, array → 1-indexed table, number → Lua number (ints kept as ints);
  **`null` → `nil`** (documented caveat — a hole in an array; no `json.null` sentinel in v1, one canonical way).
  Malformed input → `LuaError` (rethrows `Json.err`'s offset); **input-length + max-depth caps** ([D-018](decisions.md)
  spirit) guard the recursive parser against `StackOverflow`/OOM.
- `encode`: same array-vs-object heuristic + integer cleanup + cycle detection as the REPL writer; the public path is
  **strict** — a function/userdata/thread or a cycle throws a `LuaError` (vs the REPL's forgiving `tostring`/`"<cycle>"`).
- **Ungated** — pure CPU, no I/O, no server contact. **Zero `haven` core edit** (all `io.brodgar.addon`).
- Built as **N1** (the first N-series slice).
**Rationale.** The machinery is already written and battle-tested internally; this is mostly *exposing* it the one
canonical way. JSON is independent of the network (parse a `hafen.store` string offline), so it earns its own namespace.
**See.** [19-data-and-network.md](19-data-and-network.md) §2, [D-016](decisions.md) (the bundled JSON facility), [D-037](decisions.md).

### D-037 — External requests are `hafen.http` (async get/post), gated by a `network` allowlist ✅ (maintainer, 2026-07-26)
**Decision.** Addons reach the network through **`hafen.http.get(url[,opts],cb)`** and
**`hafen.http.post(url,body[,opts],cb)`** — **asynchronous, always**. A blocking request cannot run on the UI thread
(it would freeze the client, and the instruction watchdog counts **Lua** instructions, so a blocking **Java** call is
never interrupted), so `hafen.http` returns a **request handle** immediately and delivers the result via a
**callback marshalled to the tick** — the exact `GobAdded`/timer pattern (off-thread queue drained on tick, per-handler
error isolation, all Lua serialized on the UI thread). `HttpURLConnection` (Java 1.8-compatible, unlike
`java.net.http.HttpClient`). The callback gets **one `res` table**: `ok` (an HTTP reply arrived, any status),
`status`, `body`, `headers` (lower-cased), or `error` (transport failure) — separating "did we get a reply?" from
"what code?". GET + POST only in v1 (read + send — two operations, not a dual style, so [D-013](decisions.md) holds);
POST `body` may be a string (verbatim) or a table (auto-`Json.write` → `application/json`).
**Security (maintainer choices, 2026-07-26).**
- **Allowlist, declared in the manifest** — a **`network` block** whose **`hosts`** array is the allowlist (exact host,
  case-insensitive, `*.domain` sub-domain wildcard). Its **presence grants the permission** (scoped to those hosts);
  no block ⇒ every `hafen.http.*` throws a guiding `LuaError`, like `requireActions`
  ([AddonManager.java:311](src/io/brodgar/addon/AddonManager.java:311)). A disallowed host is rejected **synchronously**
  at call time. This mirrors the "actions" permission ([D-027](decisions.md)/[D-028](decisions.md)) but as its own
  block (it carries config), following the `saved_variables` precedent — **not** a `permissions[]` flag. The AddOns
  panel shows declared hosts before enable (transparency, the network analog of [D-025](decisions.md)'s notice).
- **Private/loopback/link-local IPs blocked** by default (`127/8`, `10/8`, `172.16/12`, `192.168/16`, `169.254/16`,
  `::1`, `fc00::/7`, `fe80::/10`) — checked on the resolved IP, to stop LAN-scan / internal-SSRF from third-party code.
  No user-facing localhost override in v1.
- **Limits** ([D-018](decisions.md) spirit, `-D`-tunable): response size 8 MB, timeout 10 s (cap 60 s), 6 in-flight
  per addon (excess queued), a shared bounded pool (8 threads). Generic `User-Agent`, no cookie jar, no auto identity;
  hop-by-hop headers stripped; TLS verified (JDK trust store).
- **Redirects:** none auto-followed in v1 (N2a returns the 3xx raw); N2b follows ≤5 hops **re-validating the allowlist +
  private-IP check per hop** (a redirect can never escape the allowlist).
**Consequences.**
- **Ownership/teardown:** the handle is bridge-owned in `Addon.requests` (like `subs`/`timers`/`ghosts`/`images`);
  `:reload`/disable/relog cancels in-flight requests and the result is discarded on drain (cancelled ⇒ callback never
  fires). The pool is one static `ExecutorService` on `AddonManager`.
- **`haven` core edits: none expected** (JDK HTTP + our JSON + the addon-package async plumbing). Any client-shutdown
  hook for the pool would be a single `// addon:` line — flagged at build time, not assumed.
- Built as **N2a** (GET + the whole async/security substrate) then **N2b** (POST + rich headers + redirect-follow).
**Rationale.** Network access from third-party code is powerful (exfiltration, phone-home, LAN/SSRF, DoS), so it is
opt-in, allowlisted, and visible — the project's security-by-design posture ([D-017](decisions.md)) applied to I/O.
Async + tick-drain reuses proven infrastructure rather than inventing a threading model. Maintainer ratified the
allowlist model, the private-IP block, and GET+POST (2026-07-26).
**See.** [19-data-and-network.md](19-data-and-network.md) §3–§5, [12-security-and-permissions.md](12-security-and-permissions.md), [D-036](decisions.md), [D-027](decisions.md)/[D-028](decisions.md), [D-018](decisions.md).

### D-038 — Addon widgets receive drops via an `onDrop` callback ✅ (maintainer, 2026-07-26)
**Decision.** `hafen.ui.widget`/`hafen.ui.window` gain an optional `onDrop = fn(x, y, drop)` callback, and
[`LuaWidget`](src/io/brodgar/addon/LuaWidget.java) **implements [`haven.DropTarget`](src/haven/DropTarget.java)**.
When the client's drag-drop machinery drops a "thing" over the widget, the bridge forwards it to Lua as a
**neutral descriptor** in widget-local pixels; returning **truthy consumes** the drop (like the other input
callbacks). v1 handles the **`dropthing` path only**, whose "thing" is a
[`MenuGrid.Pagina`](src/haven/MenuGrid.java:63) (a menu-grid action) — delivered as
`{ kind = "pagina", res = "<resource name>" }`. The engine already dispatches menu-grid drops generically —
[`MenuGrid.mouseup`](src/haven/MenuGrid.java:588) calls `DropTarget.dropthing(ui.root, ui.mc, dragging)`, and the
`Drop` event walks the widget tree via `PointerEvent.propagation`, calling `dropthing` on the first `DropTarget`
under the cursor — so a bridge widget receives paginae with **zero `haven` core edit**.
**Rationale.** Lets addons build **drop targets** (custom action bars, ability shelves, quick-slots) reusing the
game's own drag gesture, with no new UI verbs to learn. A **neutral descriptor** (not a live Java object) keeps it
**ungated** — a resource name is plain data, already exposed all over the read API
([`hafen.actionbar.slot`](api-reference.md) etc.) — and forward-compatible: a later menu-ability primitive can also
hand the addon a resolvable handle without changing the callback shape.
**Scope / limits.**
- v1 = **menu-grid paginae** only. Item drag-drop uses the separate `DTarget.drop(Coord, Coord)` / `iteminteract`
  path, **not** `dropthing` — out of scope (a later slice may add item drops).
- **No activation.** `onDrop` gives you *what* was dropped, not the power to *fire* it. Firing a dropped action
  needs the deferred **menu-ability primitive** (a resolvable ability handle + a gated `use`) — planned separately.
- **id-only paginae** (server-`id`, non-`Indir` — the `fl&2` case in
  [`MenuGrid.uimsg`](src/haven/MenuGrid.java:615)) have **no stable resource name**, so the descriptor carries
  `kind` only (`res` absent); such a drop is usable in-session but **not reliably persistable** across relogs. Most
  real abilities are resource-based, so this is a corner case.
**Alternatives.** Hand Lua the live `Pagina` object — rejected (leaks a mutable Java handle into the sandbox, and
conflates "what was dropped" with "the ability primitive" that is deliberately deferred). A dedicated
`hafen.ui.dropTarget(...)` widget type — rejected (a callback on the existing widget is the one canonical way, D-012).
**Consequences.** Additive in `io.brodgar.addon`: `LuaWidget implements DropTarget` + read `onDrop` from opts + a
`Pagina`→descriptor marshal; `newUi` passes opts through unchanged. **Zero `haven` core edit.** Ungated.
**See.** [07-ui-and-drawing.md](07-ui-and-drawing.md), [D-040](decisions.md) (widget `mods`), [D-039](decisions.md)
(`g:resource`, the icon you draw from the dropped `res`), the deferred menu-ability primitive.

### D-039 — `g:resource(name, x, y[, w, h])` draws an engine `.res` image in the draw wrapper ✅ (maintainer, 2026-07-26)
**Decision.** Add **`g:resource(name, x, y [, w, h])`** to the [`LuaGOut`](src/io/brodgar/addon/LuaGOut.java) draw
wrapper — blit an **engine resource's default image layer** (the `.res` icon) by **resource name**, optionally
scaled into a `w × h` box. It is the sibling of `g:image`: `g:image` draws the addon's **own** PNGs (via
`hafen.render.image`, D-034), whereas `g:resource` draws the **client's own `.res` art** (action icons, hud pieces,
…). The name is resolved **asynchronously and cached** (one `Indir<Resource>` per name via
[`Resource.remote().load(name)`](src/haven/Resource.java:866)); a draw is **`Loading`-guarded** — it draws nothing
until the texture is ready, then blits from cache (the client's own idiom — cf.
[`MenuGrid.draw`](src/haven/MenuGrid.java:461) swallowing `Loading`). Realizes the original spec-07 surface line
`g:image(res, …)` "draw a Tex/resource image".
**Rationale.** Addons need to render **real game icons** to match native UI — e.g. draw the icon of an action whose
`res` name arrived via [`onDrop`](decisions.md#d-038). A single **by-name** primitive is more canonical (D-012, "one
way") than a family of special-case verbs (`g:slot`, `g:ability`, …).
**Scope / limits.**
- Draws the **static default image layer** (`Resource.imgc`), **not** a live [`GSprite`](src/haven/GSprite.java): no
  animation and **no cooldown sweep / info overlays**. The rich per-ability draw (icon + `PagButton.meter` wedge +
  overlays, à la [`PagBeltSlot.draw`](src/haven/GameUI.java:134)) belongs to the deferred **menu-ability primitive**
  (a future `g:ability`), not here.
- The **native empty-slot square** [`Inventory.invsq`](src/haven/Inventory.java:34) is a **code-built `TexI`**, not a
  plain `.res`, so it is **not** reachable through `g:resource`; an addon draws its own slot background (a
  `g:frect`/`g:rect`), or a small dedicated helper may expose it later. `g:resource` covers any real `.res`.
**Alternatives.** Special-case verbs `g:slot`/`g:ability` (my first sketch) — rejected in favour of one generic
by-name verb (D-012). A blocking `Resource.loadtex(name)` in the draw — rejected (would stall the render thread; the
async-cache + `Loading`-guard is the client's own idiom).
**Consequences.** Additive in `LuaGOut` + a tiny name→`Indir`/`Tex` cache on the bridge (bridge-owned, dropped on
reload/disable). **Ungated** — client-side pixels that never reach the server, exactly like `g:image` (D-034).
**Zero `haven` core edit** (`Resource.remote().load` + the image layer + `GOut.image` are all public).
**See.** [07-ui-and-drawing.md](07-ui-and-drawing.md) §"The GOut drawing wrapper",
[17-custom-rendering.md](17-custom-rendering.md), [D-034](decisions.md), [D-038](decisions.md).

### D-040 — Widget mouse callbacks carry a `mods` table ✅ (maintainer, 2026-07-26)
**Decision.** [`LuaWidget`](src/io/brodgar/addon/LuaWidget.java) passes a trailing **`mods = {shift, ctrl, alt}`**
table (booleans, from `ui.modflags()`) as the **last argument** of its mouse callbacks:
`onClick(x, y, button, mods)`, `onMouseUp(x, y, button, mods)`, and — for consistency —
`onMouseMove(x, y, mods)` / `onWheel(x, y, amount, mods)`. **Additive and back-compatible**: existing handlers that
ignore the extra argument are unaffected.
**Rationale.** An addon must know the modifier state **at press time** to branch on it — e.g. **Shift+drag to move**
a bar vs. a plain click to use a slot — but today the callbacks pass only `(x, y, button)`, so the modifier is
invisible until too late. Reuses the existing `modsTable(ui.modflags())` helper and **mirrors** the `mods` already
delivered by `hafen.hook.grab` (`{shift, ctrl, alt}`), so one modifier shape is used everywhere (D-012).
**Alternatives.** A separate `hafen.ui.mods()` global reader — rejected (racy vs. the event, and a second way to read
the same thing). A raw integer bitfield — rejected (the boolean table matches `hafen.hook.grab`).
**Consequences.** Additive in `LuaWidget` (build the table from `ui.modflags()` at each mouse forward).
**Ungated. Zero `haven` core edit.**
**See.** [07-ui-and-drawing.md](07-ui-and-drawing.md) §Input, [13-hooks-and-interception.md](13-hooks-and-interception.md)
(`hafen.hook.grab` `mods`), [D-038](decisions.md).

### D-041 — Generic read-only widget-tree introspection via opaque `WidgetNode` handles ✅ (maintainer, 2026-07-26)
**Decision.** Add a **generic, read-only** way to walk *any* widget's children to arbitrary depth (the
**W-series**, spec [20](20-widget-introspection.md)). Two entry points return an opaque, stale-graceful
**`WidgetNode`**: `hafen.ui.root()` (the top of the whole client tree) and `hafen.ui.node(id)` (by server widget
id — a `desc.id`, a model's `:raw()`, or another node's `:id()`; `nil` if unresolved). Each node exposes
`:type()` (class simple name), **`:id()` (server id, or `nil` when the widget is not server-bound)**, `:children()`
(array of child nodes, tree order), `:parent()`, `:pos()`, `:size()`, `:visible()`, `:text()` (best-effort, one
localized switch), `:walk(fn)` (depth-first), and **`:same(other)`** (reference identity — `true` iff both handles
wrap the same live widget; nil-safe). `:same` is the identity primitive: each `node`/`at` call mints a *fresh* handle
and client-only children have no `:id()`, so it is the only reliable "same widget as before?" check (the per-frame
guard `widgetstack` needs, [D-042](decisions.md)). **Read-only and facade-safe** — no `haven.Widget` crosses into
Lua ([D-017](decisions.md)); the node is a Lua handle over a Java `LuaWidgetNode` that holds the widget inside Java
and resolves lazily.
**Rationale.** Lets an addon **discover any window's structure from Lua** — no `.res` decompiling, no per-window
Java. The maintainer reads the upstream widget class once, then writes the adapter (`barterstand.products()`/
`price()`/`buy()`, or any window) **in pure Lua** over `:children()`/`:text()` + `hafen.act.raw`. Complements the
[14](14-widget-tree-reads.md) typed adapters (which stay for hot/event-driven reads and private-field reflection);
this is the generic, on-demand, **public-structure** reader. **`:id()` is the pivot:** it is what makes a node
actionable — a `wdgmsg` from an unbound sender is dropped ([UI.java:681](src/haven/UI.java:681)), so you act on the
**server-bound** node with the message a client-only button would have sent, not on the button.
**Scope / limits.**
- **Read-only.** No mutation of widget internals (fragile, desyncs from the server — [D-009](decisions.md) spirit);
  legitimate mutation goes through the gated `hafen.act.raw` on a server-bound node. **No new gate here** — reading
  the tree is ungated client-side data; sending `wdgmsg` stays in the Phase-4 actions tier.
- **`:text()`** is best-effort over a known type set ([`Label.texts`](src/haven/Label.java:34), button captions,
  `TextEntry`, …), localized in one Java method; an unknown type returns `nil`, never throws.
- **Whole-tree reachable** via `root()`/`:parent()` — consistent with the ungated read API (all client-side, never
  reaches the server).
- Nodes are **transient** (not owned-registry entries): a `GobRef`-style lazy handle that checks liveness per access
  and nulls its ref once the widget dies (no pinning, no teardown hook, no leak).
**Alternatives.** A Java adapter per window (rejected as the default — repeats Java per UI; this reader lets adapters
be pure Lua). Handing Lua the raw `Widget` (rejected — [D-017](decisions.md)). A mutating node API (rejected —
fragile; mutation belongs to the gated action tier at most). Registering every node for teardown (rejected — a deep
tree mints thousands; borrow-and-check-liveness matches `GobRef`).
**Consequences.** Additive in `io.brodgar.addon` (a new `LuaWidgetNode` + the `hafen.ui.root`/`hafen.ui.node`
globals + `model:node()` sugar); all backings public ([`Widget.children()`](src/haven/Widget.java:1742)/
[`wdgid()`](src/haven/Widget.java:560)/`c`/`sz`/`visible()`/`getClass`, [`Label.texts`](src/haven/Label.java:34)) →
**zero `haven` core edit. Ungated.**
**See.** [20-widget-introspection.md](20-widget-introspection.md), [08-widget-replacement.md](08-widget-replacement.md)
(adopt/replace — the wrap model), [14-widget-tree-reads.md](14-widget-tree-reads.md) (typed adapters — the other
half), [D-025](decisions.md) (`hafen.act.raw`).

### D-042 — Coordinate hit-testing (`hafen.ui.at` + `hafen.ui.mouse` + `node:rootpos`) — the `/framestack` enabler ✅ (maintainer, 2026-07-26)
**Decision.** Extend the W-series (**W2**, spec [20](20-widget-introspection.md)) with the two reads that let an addon
find *what widget is under the cursor* — a WoW-`/framestack` clone: **`hafen.ui.mouse()`** (→ `{x,y}`, the cursor in
root coords, from public [`UI.mc`](src/haven/UI.java:54)); **`hafen.ui.at(x, y)`** and **`node:at(coord)`** (→ the
**deepest** [`WidgetNode`](decisions.md#d-041) under a point, or `nil`); and **`node:rootpos()`** (→ `{x,y}` top-left
in root coords, from public [`Widget.rootpos()`](src/haven/Widget.java:496), for a highlight box). `at()` **mirrors the
engine's own pointer dispatch** [`PointerEvent.propagation`](src/haven/Widget.java:981): children walked `lchild→prev`
(**topmost-first**), `!visible()` skipped, descend by `parent.xlate(child.c,true)` + rect-intersect, and honour
[`checkhit`](src/haven/Widget.java:794) at the leaf — so it returns exactly the widget a real click would hit.
**Rationale.** W1 gives the tree + `:parent()` walk (the stack); the only missing piece for `/framestack` is *finding
the leaf under the mouse*. **`onMouseOver` is the wrong tool and is deliberately NOT added:** a hover callback on a
[`LuaWidget`](src/io/brodgar/addon/LuaWidget.java) fires only for the addon's **own** widgets, whereas `/framestack`
inspects **arbitrary native** widgets — WoW itself hit-tests the cursor against the whole tree rather than hooking
per-frame hover. Hover is then just **polling `ui.mc`** each tick (optionally gated behind a `hafen.hook.grab`/hotkey
toggle) — no new event needed.
**Scope / limits.**
- **Faithful, not naïve:** `at()` must reuse the engine walk (`xlate` for scroll offsets, `checkhit` for
  non-rectangular hit areas), or it mis-resolves inside scrolled lists / custom hit shapes. A plain
  `pos..pos+size` rect test is rejected.
- **Read-only, ungated.** Reading cursor + geometry is client-side data; nothing reaches the server. (Acting on the
  resolved node still goes through the gated `hafen.act.raw` on its `:id()`, [D-041](decisions.md).)
- **No generic native `onMouseOver`.** That would require hooking the engine's pointer-dispatch path (more invasive)
  and adds nothing over the poll here — deferred unless a concrete need appears.
**Alternatives.** A per-widget `onMouseOver` event on native widgets (rejected — invasive pointer-dispatch hook, and
useless for *arbitrary* widgets). A naïve rectangle hit-test (rejected — wrong under scroll/`checkhit`). Exposing raw
`ui.mc`/`Widget` objects (rejected — [D-017](decisions.md); the facade returns plain tables + `WidgetNode` handles).
**Example addon (`widgetstack`).** W2 ships **`addons/widgetstack/`** — the `/framestack` clone: on `OnUpdate(dt)` it
reads `hafen.ui.mouse()` + `hafen.ui.at(...)`, walks `:parent()` to the root, and shows the stack (type/#id/'text'/WxH
per level) in a window + outlines the hovered widget via `:rootpos()`+`:size()`. **Efficiency guard (maintainer
requirement):** it caches the last hovered leaf and **bails early** (`if leaf:same(last) then return`) so the tree
walk + window rebuild happen **once per hover change, not per frame** — `:same` ([D-041](decisions.md)) is what makes
that guard possible (client-only leaves have no `:id()`). This addon is the in-game harness for W2 (and re-exercises
W1). *(A slash toggle + an optional `hafen.hook.grab` freeze key are addon-side niceties, not new API.)*
**Consequences.** Additive in `io.brodgar.addon` (`hafen.ui.mouse`/`hafen.ui.at` globals + `LuaWidgetNode.at`/
`rootpos`/`same`); backings all public (`UI.mc`, `Widget.xlate`/`checkhit`/`visible()`/`rootpos()` + reference identity
+ the `lchild/prev` walk mirrored in the bridge) → **zero `haven` core edit. Ungated.**
**See.** [20-widget-introspection.md](20-widget-introspection.md) §W2, [D-041](decisions.md) (the `WidgetNode` +
`:same` it extends), [09-events-catalog.md](09-events-catalog.md) (`OnUpdate`), [07-ui-and-drawing.md](07-ui-and-drawing.md)
(`hafen.hook.grab` for a freeze toggle).

### D-043 — Fonts are a per-addon `hafen.font.*` system: private handles + owned overrides (NO shared registry) ✅ (maintainer, 2026-07-27)
**Decision.** Add a **`hafen.font.*`** namespace (the **F-series**, spec [21](21-fonts.md)) giving an addon
**complete control over client typography**, built on the client's existing **owned-resource** model — not on a
shared media registry. Three moving parts:
- **`hafen.font.load(source[, opts])` → a private `FontHandle`.** `source` = a `.ttf`/`.otf` under the addon
  folder, or a built-in (`"sans"/"serif"/"mono"/"fraktur"`); `opts = {size,aa,bold,italic,color}` (`size` in
  logical px, `UI.scale`d). The handle is an **opaque, per-addon Lua value the addon holds** ([D-017](decisions.md)
  facade-safe) — **no cross-addon name, no shared table.** Methods `:derive(opts)`, `:family()` (AWT family, for
  `$font`), `:size()`.
- **Apply to the addon's OWN drawing** (isolated, conflict-free): `font =` on `hafen.ui.window`/`widget`,
  `g:text(str,pos,{font=…})`, and per-run `$font[h:family(),sz]{…}` in rich text.
- **Apply to a GLOBAL client surface** via an **owned override**: `hafen.font.setFont(scope, h)` /
  `hafen.font.reset(scope)` / `hafen.font.scopes()`, over an **enumerated** scope set (`"default"`,
  `"window.title"`, `"button"`, `"label"`, `"tooltip"`, `"menu"`, `"chat"`, `"textentry"`, `"world.nick"`,
  `"world.speech"`). Resolution is **most-specific first**: *per-instance (F5) → scope override → `"default"`
  override → stock foundry*, so `setFont("default", h)` **cascades to everything** unless a scope refines it.
**Rationale.** The maintainer wants total freedom to restyle *anything* AND each addon **independent**. A shared
LibSharedMedia-style registry is rejected: there is no cross-addon code sharing here and it would add a global
name namespace + coupling. A private handle + owned override delivers the same power while fitting the client's
existing teardown model (hooks/overlays/adopt are all owner-tagged and reverted on `:reload`, [05](05-lifecycle-and-reload.md)).
**Scope / limits.**
- **Naming:** `setFont(scope, h)` (maintainer renamed `setScope`→`setFont`). The global default is
  `setFont("default", h)` — **no separate `setDefault` sugar** (one canonical way, [D-012](decisions.md)); revisit
  if wanted.
- **Conflict on a global surface is intrinsic:** a scope is shared client state → an **owner-tagged stack,
  last-wins, reverted per owner on teardown** (mirrors [08](08-widget-replacement.md) adopt). Two addons cannot
  own the same surface at once; that is correct, not a gap.
- **Invalidation cost is real:** `Text`/`Tex` are cached at each render site, so the provider carries a
  **generation counter**; `setFont`/`reset` bump it and routed sites/widgets rebuild when it moves. **F1 proves
  this end-to-end** on `"default"` (`Text.std`+`Label`); later slices reuse the pattern.
- **Coverage grows per slice, API does not:** the scope enum is declared in full at F1; each scope becomes
  effective when its render site is routed (`// addon:` one-liners), avoiding a one-shot rewrite of all ~81
  `Foundry` sites.
- **`$font` needs the family registered:** the existing `RichText` `$font` tag resolves by **AWT family name**
  ([RichText.java:566](src/haven/RichText.java:566)), so `load` of a `.ttf` also `GraphicsEnvironment.registerFont`s
  it — then the tag works with **zero RichText edit**.
- **Engine change ⇒ rebuild + restart** (per project rules); only Lua files hot-reload.
**Alternatives.** Shared named registry / LibSharedMedia (rejected — cross-addon coupling, name collisions, no
sharing exists). Rewiring all ~81 `Foundry` sites up front (rejected — huge, unverifiable in one step; route
per-slice instead). A global mutable `Text.std` reassignment (rejected — `final`; and it misses the many sites
that don't read `std`; the provider + scope enum is the general answer). Exposing raw AWT `Font` to Lua
(rejected — [D-017](decisions.md)).
**Consequences.** Additive: a new `io.brodgar.addon.FontApi` + a `haven`-reachable `Fonts` provider facade +
`FontHandle`; per-slice `// addon:` one-liners at routed render sites (F1 = `Text.std`/`Text.render`/`Label`);
each `Addon` gains an owned font-override list for teardown. **Ungated** (client-only cosmetic — no server
traffic). Rollout F1→F5 in [21](21-fonts.md).
**See.** [21-fonts.md](21-fonts.md), [07-ui-and-drawing.md](07-ui-and-drawing.md) (draw wrapper + `font=` opt),
[20-widget-introspection.md](20-widget-introspection.md) (the `WidgetNode` F5 reuses), [D-012](decisions.md)
(one canonical way), [D-017](decisions.md) (facade safety), [05-lifecycle-and-reload.md](05-lifecycle-and-reload.md)
(owned teardown).
