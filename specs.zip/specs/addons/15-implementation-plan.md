# Implementation Plan

> **Status:** 🟡 Draft · **Spec:** AddOns · **This is the "ready to build" doc.**
> **Related:** [01-architecture.md](01-architecture.md), [11-core-hooks.md](11-core-hooks.md), [14-widget-tree-reads.md](14-widget-tree-reads.md), [decisions.md](decisions.md)

All design is closed ([open-questions.md](open-questions.md) — all resolved). This document is the
build order: prerequisites, package/class layout, the exact `haven` core edits, and phases with a
definition of done (DoD) each.

## Working process (per change)

- Each feature/phase is **documented individually in [`docs/addons/`](../../docs/addons/README.md)
  before its commit**, building the usage docs progressively (`specs/addons/` = design;
  `docs/addons/` = implementation/usage).
- The **maintainer verifies everything before any commit.** The assistant prepares code + docs and
  stops; it never commits on its own.

## Prerequisites (one-time build setup)

1. **Dependencies** ([D-014](decisions.md), [D-016](decisions.md)): add `luaj-jse-3.0.1.jar` and a
   small JSON jar to `lib/brodgar/` via a new Ant `extlib`-style target (not committed). Append
   both tokens to the manifest `Class-Path` at [build.xml:147](build.xml:147) — the only non-glob
   build line.
2. **Addons dir** ([D-015](decisions.md)): default is the client's `addons/` (jar-sibling, resolved
   via `Utils.srcpath`); add a `bin` copy step `addons/` → `bin/addons/` so first-party addons ship.
   `-Dhaven.addondir` is an **optional override only** (not baked into `run`).
3. Create `src/io/brodgar/addon/` (compiles automatically, whole-tree `javac`).

## Package layout

```
src/io/brodgar/addon/
  AddonManager.java        engine: discovery, load/enable, tick pump, reload, watchdog, console cmds
  Addon.java               one addon: manifest + Lua Globals + owned-resource registry
  Manifest.java            manifest.json parse (D-016)
  lua/                     LuaJ setup, sandbox (D-017), coercion, hafen.json
  api/                     bridge facade: WorldApi, GobApi, ItemsApi, CharApi, PartyApi, UiApi,
                           EventsApi, HookApi, ActApi(gated), SoundApi, ChatApi, TimeApi, StoreApi …
  api/tree/                widget-tree Locator + Adapters (doc 14): Vitals/Buffs/Fep/Study/Skills/
                           Actionbar/Equip
  event/                   EventBus + source adapters (OCache.callback, chat, uimsg hooks)
  ui/                      LuaWidget, LuaWindow, GOut wrapper, replacement plumbing, AddonPanel
  store/                   saved-vars (JSON) per savedata/ (D-002/D-023)
src/haven/AddonHook.java   ONE small package-private helper (Widget.types access, private-field reads)
```

## Core edits ledger (the actual `haven` touches)

Tagged `// addon:`; kept centralized ([D-011](decisions.md)). Minimal set:

| # | File / method | Edit | Phase |
|---|---|---|---|
| 1 | [`RemoteUI.init(UI)`](src/haven/RemoteUI.java:147) | `AddonManager.attach(ui, sess)` | 0 |
| 2 | *(none — tick via invisible addon-root widget on `ui.root`)* | — | 0 |
| 3 | [`UI.wdgmsg`](src/haven/UI.java:665) | `if(Addons.filterAction(sender,msg,args)) return;` (action hooks) | 2 |
| 4 | [`UI.uimsg`](src/haven/UI.java:702) | `Addons.onUimsg(id,msg,args)` (message hooks + tree-read events) | 2 |
| 5 | [`UI.NewWidget.run`](src/haven/UI.java:433) | `Addons.onWidgetCreated(id,type,wdg)` (WidgetCreated + replace + locate) | 2–3 |
| 6 | [`GameUI.addchild`](src/haven/GameUI.java:910) | `if(Addons.placeChild(this,child,args)) return;` (context replacement) | 3 |
| 7 | [`ChatUI.Channel.append`](src/haven/ChatUI.java:275) | `Addons.fire("ChatMessage", …)` | 2 |
| 8 | `AddonHook` (new, package `haven`) | `Widget.types` register/restore; cached private-field reads (vitals/FEP) | 1/3 |
| 9 | [`Console.run(Host,String)`](src/haven/Console.java) | expose the raw command line via `rawcmd()` (so the `:lua` REPL's string literals survive `splitwords`) | 1a (done) |

Zero-edit seams (no existing-file change) do the rest: tick, overlays, `OCache.callback` events,
`KeyBinding`, `Console.setscmd`, `OptWnd.Panel`+`PButton`, `Utils.srcpath`, resource loading — see
[11-core-hooks.md](11-core-hooks.md).

## Phases (build order — [D-026](decisions.md))

### Phase 0 — Spike  *(prove the loop)* — ✅ DONE & verified in-game
Built: prereqs (LuaJ auto-fetched by `get-luaj`); `AddonManager` static facade capturing the live
`MapView` via the two MapView hooks (mirroring `Voice`); one shared LuaJ `Globals` (permissive —
sandbox deferred to Phase 1); `:lua <expr>` console command; `hafen.gob.pos(ref)`.
**DoD (met):** in-game, `:lua hafen.gob.pos().x` shows the player's X as a system message — proves
Lua runs on the UI thread with safe state access. (Tick widget deferred to Phase 1, where `ui` is
available at `RemoteUI.init`; an on-demand read needs no tick loop. The console strips quotes, so
`pos()` defaults to the player and `player`/`me` are predefined globals.)
Docs: [docs/addons/phase-0-spike.md](../../docs/addons/phase-0-spike.md).

### Phase 1 — Read + engine + panel + reload  *(the safe modding tier)*
Build: `Manifest` (JSON) + discovery + enabled-set (`addons/enabled.txt`); per-addon `Globals` +
full sandbox ([D-017](decisions.md)) + watchdog ([D-018](decisions.md)); event bus with
`OnLoad`/`OnEnterWorld`/`OnDisable`/`OnUpdate`/`GobAdded`/`GobRemoved` (zero-edit sources); the read
APIs `hafen.gob/world/map/items/char/party/player/time/sound`; `hafen.log`, `hafen.timer`,
`hafen.store` (JSON saved-vars, [D-023](decisions.md)); `hafen.ui.overlay` + `hafen.key`; the
**AddOns `OptWnd` panel** (enable/disable + Reload UI, [10](10-options-panel.md)); **Reload UI**
teardown ([05](05-lifecycle-and-reload.md)).
Example addons: gob-radar overlay, item-quality display.
**DoD:** install/enable/disable/Reload-UI works with no leaks; two example addons run and reload
live without relog.

### Phase 1.5 — Widget-tree read mechanism  *(foundational, [14](14-widget-tree-reads.md))*
Build: Locator + Adapters (Vitals, Buffs, Fep, Study, Skills, Equip) + update-hook→semantic events
(needs edits #4/#5/#8). Powers `hafen.player.vitals`, `hafen.buffs`, `hafen.char.food/skills`,
`hafen.study`, `hafen.items.equipment`.
**DoD:** a FEP/curiosity-timer example addon works end-to-end (reads + `FepChanged` events).

### Phase 2 — Windows + input + events + hooks
Build: `LuaWidget`/`LuaWindow` + `GOut` wrapper; input callbacks; the full event catalog
one-liners (#3/#4/#5/#7); `hafen.hook.input/action/message` ([13](13-hooks-and-interception.md)).
**DoD:** a custom draggable window + a `hook.action("click")` demo (intercept a move) work.

### Phase 3 — Widget replacement
Build: factory-override (via `AddonHook`) + `GameUI.addchild` hook (#6); descriptor ([D-024](decisions.md));
model/view delegation ([08](08-widget-replacement.md)).
**DoD:** a bag/inventory overhaul replaces the native inventory and restores it on disable.

### Phase 4 — Actions (gated, [D-025](decisions.md))
Build: `hafen.act.*` behind `addons.actions.enabled` + a declared per-addon permission (D-027). Enables the *(gated action)*
verbs already referenced (actionbar.use, speed.set, kin.add, craft.make, etc.).
**DoD:** a click-macro example works only when the flag is on; warning shown on enable.

### Gap phases (each a small project on the Phase-1.5 mechanism + hooks)
Order [D-026](decisions.md): **A1 `hafen.markers`** → **A4 `hafen.study`/FEP** (mostly Phase 1.5) →
**A3 `hafen.actionbar`** → **A2 `hafen.radar`** → **A11 `hafen.slash`** → **A6–A10** (kin, speed, craft,
quests, wounds, fight-config). Each: adapter/back-end + Lua facade + events + example addon.

## Testing strategy
- **Headless where possible:** `Window.main()`/`DrawBuffer` render addon windows off-screen; unit-test
  adapters against captured `uimsg` sequences.
- **Reload leak check:** after N reloads, assert widget/callback/overlay/timer counts return to
  baseline (the [00](00-vision-scope.md) success criterion).
- **Sandbox tests:** assert `io`/`os.execute`/reflection are absent; watchdog kills an infinite loop.
- **Example addons double as integration tests** (radar, quality, FEP timer, bag overhaul).

## Start here (first PR)
Prereqs + Phase 0 = one PR: `build.xml` (jars + run `-D`), `src/io/brodgar/addon/AddonManager.java`
(+ invisible tick widget), minimal LuaJ env, `:lua` command, `GobApi.pos`. Small, self-contained,
proves the whole approach.
