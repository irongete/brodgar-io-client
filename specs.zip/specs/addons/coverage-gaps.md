# Coverage Gaps & Unflagged Risks

> **Status:** 🟢 Living · **Spec:** AddOns
> **Source:** the spec-vs-client audit (2026-07-23). This file tracks **client subsystems the
> spec doesn't yet cover** and **risks not flagged elsewhere**, so they aren't lost. Each item
> names the client class(es) and why an addon author wants it. Nothing here is designed yet —
> these feed prioritization ([Q-014](open-questions.md)).

## How to read this

The audit found the **backings/mechanisms we did document are accurate** and the "not reliably
available" claims are all genuinely absent. The real weakness is **breadth**: whole client
subsystems below are unmentioned or lumped into one "deferred/TBD" line. Ranked by typical
Haven & Hearth addon demand.

## A. Missing capabilities (ranked)

### A1 — Map / minimap / markers  ⭐ biggest gap
Classes: [`MiniMap`](src/haven/MiniMap.java), [`MapWnd`](src/haven/MapWnd.java) (`implements Console.Directory`),
[`MapFile`](src/haven/MapFile.java) (client-side on-disk map DB: `PMarker`/`SMarker` ~:301/:316,
`Segment`, `Grid`, export/import). `MapWnd` owns a marker subsystem (`MarkerList`,
`markobj(gobid,oid,resid,data,nm)` ~:922, `exportmap`/`importmap`).
Why: **auto-mapping, quality/gob radar, custom markers** are the #1 H&H addon category. The spec
currently references the map only as the gob `icon` string. Needs a `hafen.map`/`hafen.markers`
surface: read/add/remove markers, minimap query, segment/grid addressing (see [C4](#c-unflagged-risks)).

### A2 — GobIcon settings / radar categories
Classes: [`GobIcon`](src/haven/GobIcon.java) `Settings` registry (per-category show/hide/notify).
Why: radar addons ("show boars, hide trees", "notify when X spawns") drive `GobIcon` categories
and register custom icons per resource — beyond the single `hafen.gob.icon(ref)` name we expose.

### A3 — Action bar / hotbar
API name: `hafen.actionbar` (the engine calls it the "belt").
Classes: [`GameUI.belt`](src/haven/GameUI.java:68) = `BeltSlot[144]`, `Belt`, `ResBeltSlot`/`PagBeltSlot`;
uimsg `setbelt`/`setbelt2`, action `wdgmsg("belt"|"setbelt"|"setbelt2")`.
Why: custom action bars. **Note ([B4](#b-architectural-corrections)):** the action bar is
server-authoritative, so a real action-bar addon needs the widget-replacement path **and** the gated
action tier — not simple client-side UI. Deserves a `hafen.actionbar.*` (read slot res/cooldown; use slot).

### A4 — Study / curiosity / FEP / experience / credo  ⭐ most-wanted tracker
Classes: [`CharWnd`](src/haven/CharWnd.java)+`haven.resutil.Curiosity` (study window),
[`BAttrWnd`](src/haven/BAttrWnd.java) `FoodMeter feps` (:39) / `GlutMeter` (:41) (FEP/hunger),
[`SkillWnd`](src/haven/SkillWnd.java) (`@RName("credo")`/`@RName("expls")`).
Why: **curiosity-slot timers and FEP-by-food tracking are the first addons H&H players build.**
Data arrives as targeted `uimsg` to these widgets — see [C2](#c-unflagged-risks): today there is
**no end-to-end supported path** (read API to locate these widgets is deferred).

### A5 — Gob overlays (`Gob.ols`)
Classes: [`Gob.ols`](src/haven/Gob.java:42) = `Collection<Overlay>`, `Gob.Overlay` (:49), `addol` (:525).
Why: overlays carry decisive state — **crop growth stage, fire/smoke, drying/tanning progress,
aggro markers**. The outline had `overlays=` (TBD); the authoritative `Gob` snapshot dropped it.
**FIXED in api-reference.md** (re-added to the `Gob` shape); full overlay API still to design.

### A6 — Buddy / kin management
Classes: [`BuddyWnd`](src/haven/BuddyWnd.java) (`implements Iterable<Buddy>`, `@RName("buddy")`/`@RName("grp")`).
Why: kin lists, group/color/online status, add/remove/rename kin (kin alerts, group coloring).
Today `GameUI.buddies` is used only to resolve a chat sender's name.

### A7 — Movement speed (`Speedget`)
Classes: [`Speedget`](src/haven/Speedget.java) (`@RName("speedget")`) — crawl/walk/run/sprint.
Why: speed-toggle keybind, auto-crawl-on-sneak — classic convenience addon. Read + gated set.

### A8 — Crafting: structured read (`Makewindow`)
Classes: [`Makewindow`](src/haven/Makewindow.java) (`@RName("make")`).
Why: crafting helpers need current recipe / inputs+qualities / output / craft-all state —
independent of the reskin path (`08` lists crafting only as a replacement target).

### A9 — Quests & wounds
Classes: [`QuestWnd`](src/haven/QuestWnd.java), [`WoundWnd`](src/haven/WoundWnd.java).
Why: quest tracker, wound/health alerts. At least catalogue events (`QuestAdded`, `WoundChanged`).

### A10 — Combat school / deck builder (`FightWnd`)
Classes: [`FightWnd`](src/haven/FightWnd.java) (`@RName("fmg")`) — configures decks/maneuvers
(distinct from in-combat `Fightview` already covered). Loadout addons have no surface.

### A11 — Console / slash commands for addons
Classes: [`Console`](src/haven/Console.java) (`setscmd`/`Directory`).
Why: WoW-style `/command`. Currently only the Phase-0 `:lua` spike exists. Needs `hafen.console.*`
(or `hafen.slash`). **See [C1](#c-unflagged-risks):** `Console` has no unregister → reload leak risk.

### A12 — Lower priority (acknowledge, defer)
`Screenshooter` (programmatic screenshot); custom cursors (`UI.Cursor`/`CursorQuery` — Lua widgets
can't currently answer a `CursorQuery`); [`GSettings`](src/haven/GSettings.java) (read/write client
graphics/display settings); `Polity` (village/realm management); `NewsFeed`; `Cal` (calendar);
`DynresWindow` (`@RName("dynres")` — server-published custom windows, a special replacement case);
`Partyview` (`@RName("pv")` — the on-screen party **HUD**, distinct from the `Glob.party` roster
we read; see [C7](#c-unflagged-risks)).

## B. Architectural corrections (applied to the specs)

### B1 — "Everything hangs off `Glob`" was oversold  ⚠ important
Reality: most high-value reads live in **`GameUI` widget trees**, not `Glob` — vitals
(`GameUI.meters`), buffs (`GameUI.buffs`), the action bar (`GameUI.belt`), char sheet/skills/study (`CharWnd`), FEP
(`BAttrWnd`), inventory/equip (`maininv`/`equwnd`), chat (`ChatUI`), map/markers, crafting.
`Glob` covers gobs, terrain, party, character *attributes*, and time. **Consequence:** the "stable
facade over two universal primitives" thesis ([01 P1/P3](01-architecture.md), [00](00-vision-scope.md))
is weaker than stated — a large part of the facade is pinned to **widget-tree shape + resource
names**, the most upstream-volatile surface. → Corrected in `00`/`01` (honest framing: `wdgmsg` is
a true universal action bus; `Glob` is *a* root but much state is widget-tree-bound, so the bridge
absorbs real churn there and those surfaces are higher-maintenance).

### B3 — Map replacement ≠ inventory replacement
The map is a **client-side subsystem** (`MapFile` on-disk DB, `MapWnd` owning it), not a thin
server widget. The wrap-and-delegate model ([08](08-widget-replacement.md)) and "match a server
window" ([Q-008](open-questions.md)) don't apply to the map. → Noted in `08`.

### B4 — The action bar ("belt") is a gated action, not client UI
Action-bar contents arrive via `setbelt` uimsg; using a slot sends `wdgmsg`. A "custom action bar" needs
widget-replacement **+** the Phase-4 action tier. → Noted with A3.

### B5 — `player.vitals()` is not a zero-edit read
Backed by **private/protected** fields (`GameUI.meters`, `LayerMeter.meters`) → reflection or a
core hook; contradicts "Phase 1 = zero core edits" ([09](09-events-catalog.md)). → Noted in
`api-reference.md` and `09`.

## C. Unflagged risks

### C1 — Reload can leak console/global registrations
`Console.setscmd` has **no unregister**. If addons register slash commands (A11) or the engine
registers `:lua`, Reload UI re-runs registration → duplicate/leaked commands, violating the
leak-free criterion ([00](00-vision-scope.md), [05](05-lifecycle-and-reload.md)). Same risk for any
client-global registry the engine writes (`GobIcon.Settings`, resource sources). Fix: a single
engine-lifetime command dispatcher that routes to current addon state (never re-registers), and a
tracked shim for any other global registry. → To reconcile in `05`.

### C2 — Most-wanted trackers have no end-to-end path
FEP (`BAttrWnd.feps.update`), study/curiosity (`CharWnd`+`Curiosity`), skills/credo (`SkillWnd`)
update via targeted `uimsg`. The only route is `hafen.hook.message` against a widget the addon
located by tree-walking — but the read API to locate those widgets is exactly what's deferred. So
the headline H&H tracker (FEP/curiosity) is not yet buildable, and the spec didn't say so.

### C3 — `MenuGrid` action paths are lazy, content-defined trees
`hafen.act.menu(path...)` walks the *current* pagina tree; paginae are server-fetched, resolve
`Indir<Resource>` (throws `Loading`), and a path resolves only if that page is loaded/open. Names
are localized/versioned. It is **not** a stable address space. → Caveat to add to `hafen.act.menu`.

### C4 — There is NO global world position; anchor on grid IDs
Haven & Hearth deliberately **obfuscates position — there is no global coordinate.** `Gob.rc` /
`hafen.gob.pos` is **login/session-relative** (the player starts around **(-10,-10) tiles**), local
to the session — **not** comparable across sessions or between players. Stable anchors:
- **Grid IDs** (`MCache.Grid.id`, `long`) are **fixed and identical for all players** — the only
  global/shared anchor. A grid is **100×100 tiles** (`cmaps`); tile = 11×11 world units.
- The player's **position within a grid** (0..99 tiles / 0..1099 world units) is valid and shareable.
- **Segments** group grids and have IDs, but **segment IDs are LOCAL per player** (not shared).

**How village/shared 2D maps work (technique to emulate):** match **grid IDs common to both
players**, combining each player's segment-relative grid x,y with the within-grid offset — so the
shareable "global" position is **grid id + within-grid offset**.

**Consequences:** markers must be stored as **grid id + within-grid offset** (not raw world units,
which shift per session and don't survive a relog); the map/marker API must expose grid/segment
info, not just `rc` — `hafen.map.grid(x,y)` + `hafen.map.gridPos()`. Phase 0's `hafen.gob.pos`
(= rc) is not wrong, just **local**. Backing: `MCache.Grid.id`, `MCache.getgrid`, `MapFile.Segment`.

### C5 — `Gob.ols` mutates on Loader threads and throws `Loading`
Same discipline as other gob reads (copy under lock, swallow `Loading`) — now that `overlays` is
in the `Gob` shape (A5), document the guard.

### C6 — `hafen.key.bind` must be idempotent across reload
The `KeyBinding` singleton persists by id; every Reload re-calls `hafen.key.bind`, so binding must
be idempotent-by-id and the **handler** swapped (not the binding), or handlers stack/leak. State
as a correctness requirement in `07`/`13`.

### C7 — `Partyview` (HUD) ≠ `Glob.party` (roster)
Reskinning the party HUD targets `Partyview` (`@RName("pv")`), which the spec never names, while
the data API reads `Glob.party`. Don't conflate them.

## Prioritization — RESOLVED ([D-026](decisions.md))

All gaps now have a **contract-level surface** ([api-reference.md](api-reference.md) → "Gap
subsystems") and a build slot ([15-implementation-plan.md](15-implementation-plan.md)). Build order:
**widget-tree mechanism ([14](14-widget-tree-reads.md)) → A5 overlays (done) → A1 map/markers →
A4 study/FEP → A3 action bar → A2 radar → A11 slash → A6–A10.** This file stays the reference for *why*
each matters and its per-item client backing.
