# AddOn System — Execution Plan (LIVING DOCUMENT)

> **This is the single source of truth for WHERE WE ARE and WHAT'S NEXT.**
> It is **self-contained**: a fresh session with no prior conversation can read this, do the next
> task, and stop. **Update this file at the end of every task** (§6).
> This is a **personal, local-only** build — obey the RULES in §1.

---

## 1. RULES (non-negotiable)

- **NEVER `git push`.** Everything stays **local**. Pushing is forbidden unless the maintainer
  explicitly asks.
- **NEVER commit on your own.** The maintainer **verifies everything in-game before every commit**.
  Prepare code + docs, compile/verify, then **STOP and report**. Run `git commit` **only** when the
  maintainer explicitly says so (e.g. "commit", "dale al commit").
- **Document each task in `docs/addons/` BEFORE its commit** (progressive usage docs).
- **`specs/` is LOCAL-ONLY** — it is gitignored (`/specs` in `.gitignore`). The whole design lives
  here but is **never uploaded**. **`docs/addons/` IS committed.**
- **Language:** converse in **Spanish**; write all docs/specs/code-comments in **English**.
- **API design:** exactly **one canonical way** per operation (no dual styles); **namespaced
  `hafen.*`** (no flat globals); reference-based accessors (`hafen.gob.health(ref)`), `ref` = gob id
  or token (`"player"`, `"party1"`, `"target"`).
- **Core edits:** keep them minimal and **centralized**, tagged `// addon:`. Invasiveness IS
  allowed where it yields materially better features (decision D-011) — but prefer new code in
  `src/io/brodgar/addon/` and few one-liners in `haven`.
- **Java:** compiles at `source/target 1.8` (NO `var`, `Files.readString`, switch-expressions, …),
  runs on Java 23. **Engine (Java) changes require a rebuild + full client restart** — the JVM does
  not hot-reload classes. (Only Lua addon *files* will reload live, once `:reload` exists.)

---

## 2. The project in one paragraph

A **World-of-Warcraft-style AddOn system in Lua (LuaJ)** for **`brodgar-io-client`** (a
`dolda2000/hafen-client` fork; the game is Haven & Hearth / "Hafen"). Goal: make the client fully
moddable by installing/enabling Lua addons instead of forking the Java client. The engine + bridge
live in a new **`src/io/brodgar/addon/`** package and expose a **stable `hafen.*` facade**; addons
never touch `haven.*` directly. The existing **proximity-voice integration**
(`src/io/brodgar/voice/Voice.java` + a few `haven` hooks) is the **non-invasive integration
template**. Two choke points make it tractable: **`Widget.wdgmsg`** (all player actions) and
**`Glob`** via `ui.sess.glob` (much — but not all — state). Work happens on branch
**`feature/addons`**.

---

## 3. Orientation — where everything is (READ THESE)

**Design (this folder, `specs/addons/`, local-only):**
- `README.md` — index of the whole spec.
- `decisions.md` — **D-001..D-042 resolved** (ADR-lite; D-034/D-035 = R-series; D-036/D-037 = N-series,
  ratified 2026-07-26; D-038..D-040 = U-series; **D-041/D-042 = W-series** widget introspection: W1 tree walk +
  W2 hit-testing/`/framestack`). The authority on choices.
- `api-reference.md` — the **`hafen.*` contract** (every function + Java backing) — authoritative.
- `code-map.md` — **Java `file:line` index** per subsystem (the fastest way to find backings).
- `coverage-gaps.md` — audit output: subsystems NOT yet covered (map/markers, action bar, study/FEP, …)
  + risks; and **B1** (much state is in `GameUI` widget trees, not `Glob`).
- `15-implementation-plan.md` — build order, package layout, and the **core-edit ledger**.
- `14-widget-tree-reads.md` — mechanism for reading GameUI-bound data (vitals/buffs/char/FEP/action bar).
- `16-virtual-entities.md` — **NEW capability, design CLOSED** (D-029..D-033; namespace `hafen.ghost.*`):
  client-only world ghosts + transform gizmo (the **V-series** queue). Read before task V1.
- `17-custom-rendering.md` + `18-custom-models-gltf.md` — **NEW capability, decisions RATIFIED** (D-034..D-035,
  2026-07-26): the **`hafen.render.*`** namespace for **non-`.res`** assets — PNG images (screen + world:
  billboard/fixed) and **glTF** 3D models — on a shared world-entity core; `hafen.ghost` stays `.res`-only. The
  **R-series** queue (slices R1–R3 open). Read before task R1.
- `19-data-and-network.md` — **NEW capability, decisions RATIFIED** (D-036/D-037, 2026-07-26): **`hafen.json`**
  (parse/encode, ungated — reuses the existing reader + REPL writer) + **`hafen.http`** (external GET/POST, **async**,
  **gated** by a manifest `network` host-allowlist; private IPs blocked). The **N-series** queue (slices N1–N2 open).
  Read before task N1.
- `20-widget-introspection.md` — **NEW capability, decisions RATIFIED** ([D-041](decisions.md)/[D-042](decisions.md),
  2026-07-26): a **generic read-only** widget-tree walk (`hafen.ui.root()`/`hafen.ui.node(id)` → opaque `WidgetNode`
  with `:type/:id/:children/:parent/:pos/:size/:visible/:text/:walk`) so window adapters (barter stand, …) are written
  in **pure Lua** — no Java per window (**W1**); plus coordinate **hit-testing** (`hafen.ui.mouse()`/`hafen.ui.at(x,y)`/
  `node:rootpos()`) — a WoW-`/framestack` clone, mirroring the engine's pointer dispatch (**W2**). Complements
  [14](14-widget-tree-reads.md) (typed adapters). The **W-series** queue (slices W1, W2 open). Read before task W1.
- `13-hooks-and-interception.md`, `08-widget-replacement.md`, `09-events-catalog.md`,
  `12-security-and-permissions.md`, `04-engine.md`, `05-lifecycle-and-reload.md`, `10-options-panel.md`,
  `glossary.md`, `open-questions.md` (all resolved).

**Implementation/usage docs (`docs/addons/`, committed):** one file per completed task.

**Memory files** (auto-loaded each session, `~/.claude/.../memory/`): `addon-system-project`,
`addon-dev-workflow` (the RULES), `api-one-canonical-way`, `hafen-positioning`.

---

## 4. Build & verify (how-to)

```
ant get-luaj        # fetch lib/brodgar/luaj-jse-3.0.1.jar (Maven Central; gitignored, not committed)
ant hafen-client    # compile src -> build/classes (the primary compile check)
ant bin             # package bin/hafen.jar + copy deps and addons/ -> bin/addons/
ant run             # build + launch the client (fork)
```
- **Addons dir default = the client's `addons/`** (jar-sibling → `bin/addons/` at runtime), resolved
  by `Utils.srcpath`. `-Dhaven.addondir=<path>` is an **optional override only** (not baked into
  `run`). The `bin` target copies the repo `addons/` (first-party addons) into `bin/addons/`.
- **Verification ladder:** (1) `ant hafen-client` → `BUILD SUCCESSFUL`; (2) runtime logic via
  `jshell --class-path build/classes` where feasible (e.g. parsing, pure functions); (3) then
  **STOP** for the maintainer's in-game test.
- **In-game debug:** the `:lua <expr>` console REPL (results shown as compact JSON) and `:addons`.

---

## 5. STATUS — done (committed on `feature/addons`)

- **Phase 0 ✅** — LuaJ engine embedded; `:lua` REPL (compact-JSON output); `hafen.gob.pos(ref)`.
  Core edits: `MapView` attach/detach; `build.xml` `get-luaj` + manifest token.
  Doc: `docs/addons/phase-0-spike.md`.
- **Phase 1a ✅** — Addon loading from disk: `manifest.json` (own JSON reader), per-addon Lua envs,
  `hafen.log`, `:addons`. Core edits: `RemoteUI.init` hook; `Console.rawcmd()` (raw console line for
  `:lua` string literals); `build.xml` addons copy. Doc: `docs/addons/phase-1a-loading.md`.
- **Phase 1b ✅** — Runtime: per-frame **tick pump** (invisible `AddonRoot` widget on `ui.root`),
  synthesized **event bus** `hafen.events.on(name,fn)`→`sub:off()` (`OnLoad`, `OnEnterWorld`,
  `OnUpdate(dt)`, `OnDisable`, `GobAdded`/`GobRemoved` via `OCache.callback`, marshalled to the UI
  thread), **timers** `hafen.timer.after/every`→`:cancel()`, per-handler error isolation, per-addon
  owned-resource registry. **Zero core edits** (reuses `RemoteUI.init` + `MapView.attach` +
  `OCache.callback`). Headless-verified (dispatch/off/isolation/one-shot/repeat). The `:lua` REPL is
  a resource owner too. Doc: `docs/addons/phase-1b-events-timers.md`.

- **Phase 1c-1 ✅** — Read API (part 1): `hafen.gob.*(ref)` — the canonical per-gob accessor
  (exists/info/pos/facing/name/health/moving/speed/speech/icon/distance) — and `hafen.world.*`
  (gobs/count/nearest/within) with a string-substring or function filter. Centralized GobRef
  `resolve` (id / "player" / "me" / nil = player; unknown tokens → nil), a full `gobSnapshot` (the
  `Gob` shape: id/name/x/y/angle/moving/speed/hp/speech/icon/overlays/isplayer), Loading-guarded
  per-attribute readers, and `matches`/`distTo` helpers. `nearest`/`within` measure from the player
  and skip self. `GobAdded`/`GobRemoved` now carry the full snapshot. **Zero core edits** (OCache/Gob
  via the existing session hooks). Compile + 20 headless checks passed; **in-game verified**
  (gob.info/world.count/nearest/distance all worked). The `:lua` REPL now also **echoes input+result
  to stdout** tagged `[console]` (was in-game notice only). Doc: `docs/addons/phase-1c-read-gobs.md`.

- **Phase 1c-2 ✅** — Read API (part 2): `hafen.map.*` (tile/height/grid/gridPos + worldToTile/
  tileToWorld/tileToGrid — `MCache`; args in world units; **grid ids exposed as exact decimal
  strings** since they're 64-bit persistence anchors and Lua numbers are doubles; `gridPos` =
  grid id + within-grid world offset 0..1100 = the shareable position), `hafen.player.*`
  (exists/id/name via `GameUI.chrid`; worldToScreen via `MapView.screenxf`, map-view-relative),
  `hafen.time.*` (clock via `Glob.globtime`; day/night/season/moon/year via `Glob.ast`/`Astronomy`,
  nil-guarded until first astro update), and `hafen.sound.play` + `hafen.music.play` (resource
  resolve/defer off the UI thread to dodge `Loading`, mirroring `GobIcon.resnotif`). New helpers
  `glob()`/`mcache()`/`astro()`/`gui()`/`xy()`/`playSound()`; `oc()` now routes through `glob()`.
  **Zero core edits.** Compile + 13 headless coord-math checks passed (incl. negative flooring).
  **In-game verified ✅** (all reads correct; grid id came back as `-666514804926139788` string, tile
  = `gfx/tiles/grass`, name = `Irongete W16.1` resolved inside `OnEnterWorld`, world had 167 gobs, the
  `hello` `[+3s]` re-read showed the map surfaces resolving). **`OnEnterWorld` retimed** to fire once
  the HUD (`GameUI`) is up — the map view attaches a few frames earlier, so `getparent`/`ui.root` alone
  weren't enough; gating the event on `gui() != null` makes `player.name` (and all future GameUI-backed
  reads) resolve in-handler and de-risks 1c-3. `gui()` keeps both reaches (getparent + `ui.root` DFS).
  `hello` re-reads map data after 3s (grid/camera stream in just after enter-world). Deferred:
  `player.vitals` (→1d, private meters), `grid().seg` (→A1, MapFile). Doc:
  `docs/addons/phase-1c2-map-player-time-sound.md`.

- **Phase 1c-3 ✅** — Read API (part 3): `hafen.items.*` (inventory/equipment/hand/find) returning
  **Item snapshots** `{res,name,num,wear,pos,slot}`, `hafen.char.*` (attr/attrs via `Glob.getcattr` —
  zero-info→nil; **lp/weight** via public live `CharWnd.exp`/`enc`), and `hafen.party.*`
  (members/leader/member — `Glob.party`, ordered by `Member.seq`; `PartyMember{id,x,y,color={r,g,b,a},
  leader}`, **no name field**). The **`"partyN"` GobRef token** is now wired into the central
  `resolve()`, so `hafen.gob.*("party1")` works. **Zero core edits** — item reads **walk the `WItem`
  children** of the `Inventory`/`Equipory` widgets (public: `WItem.item`, `Widget.children(Class)`,
  `Equipory.epat`/`etts`) instead of their package-private `wmap`; char/party/lp/weight are all public
  fields/methods. New helpers `maininv()`/`equipory()`/`charwnd()`/`cellPos()`/`slotOf()`/`slotName()`/
  `itemName()`/`itemRes()`/`itemSnapshot()`/`attrSnapshot()`/`party()`/`partyMembers()`/
  `partyMemberByOrdinal()`/`memberSnapshot()`/`color()`. Compile OK + LuaJ parse. **In-game verified ✅**:
  `inventory()`→12 named items w/ grid pos, `equipment()`→19 slots (two-slot items = two entries;
  unnamed slots keep the numeric `slot`), `find("coin")`, `hand()`, `char.attrs()` (9× base/comp),
  `lp()`=403475, `weight()`=12429, `party.members()` (solo→self as leader), `gob.pos("party1")` all
  correct. **Char attrs / lp / weight and the inventory/equipment STREAM IN a beat after `OnEnterWorld`**
  (like the 1c-2 map data): nil/empty on the immediate read, populated ~seconds later — `hello` now
  re-reads them at `+3s`. Doc `phase-1c3-items-char-party.md`. This **completes Phase 1c** (the full
  Glob-backed read API). Deferred: item `quality`/`contents`, per-item accessor fns (→ item handles, UI
  phase), FEP/food/skills (→1d).

- **Phase 1d-1 ✅** — Widget-tree read mechanism + player vitals. The **foundation** for reading state
  bound to `GameUI` widget trees (audit B1): a **Locator** (`gui()` + public `children(Class)`), a
  `TreeAdapter` abstraction, the **inbound-`uimsg` core tap** (`UI.UiMessage.run` → `AddonManager.onUimsg`,
  post-apply, off-thread → only flags the interested adapter dirty; the tick re-reads + fires the
  semantic event on the UI thread, mirroring the gob-event marshalling), and a **`haven`-package accessor**
  (`AddonWidgets`, the "SpeakerIcon trick") for `private`/`protected` fields — Lua never gets reflection
  (D-017). First adapter: **`hafen.player.vitals()`** → `{hp,stamina,energy}` 0..1 read live from the HUD
  `IMeter`s (`children(IMeter.class)` to locate; the `protected LayerMeter.meters` via `AddonWidgets`;
  positional hp/stamina/energy mapping), plus the **`VitalsChanged`** event (change-detected; initial
  values stream in as individual `set` uimsgs a beat after the meters are created, so it fires as each
  bar appears too). **Two core edits** — the first non-zero-edit reads, exactly as B5 predicted:
  `UI.java` (one-line uimsg tap) + new `AddonWidgets.java`. Compile OK + **8 headless change-detection
  checks** (`vitalsEqual`) + LuaJ parse of the harness. `hello` bumped to v0.6.0 (reads `vitals()` at
  now/+3s, logs the first 5 `VitalsChanged`). **In-game verified ✅** — positional mapping correct
  (`hp=1` full, `stamina` 1→draining, `energy=0.886`), `VitalsChanged` fired as each bar streamed in
  (hp→stamina→energy) and on live stamina drain; `vitals()` nil at enter-world, populated by +3s.
  Doc `phase-1d1-vitals-widget-tree.md`. 1d continues with buffs/FEP (1d-2), study/skills (1d-3),
  action bar/equip (1d-4).

- **Phase 1d-2 ✅** — Buffs + FEP/food/hunger, on the widget-tree mechanism. **`hafen.buffs.list/has`**
  (`GameUI.buffs` → `children(Buff.class)`; snapshot `{res,name,amount,cooldown,number}` — `res` =
  `Buff.res` name, `name` = resource tooltip / server Name info, `amount`/`cooldown`/`number` via
  `ItemInfo.find(AMeterInfo/MeterInfo/NumberInfo, Buff.info())` — all 0..1 fractions / an int,
  content-defined, often nil, **never seconds**) with **`BuffAdded`/`BuffRemoved`/`BuffChanged`**;
  **`hafen.char.food()`** (`{fep={cap,total,entries={{res,name,amount}}}, hunger={level,label,
  efficacy}}` — the one place absolute FEP/hunger numbers exist) with **`FepChanged`**. New mechanism
  piece: a **per-tick `poll()`** (default no-op) on `TreeAdapter` — buff **add/remove** is a widget
  create/`cdestroy`, NOT a uimsg, so `BuffsAdapter.poll()` diffs `children(Buff.class)` each tick
  (identity-keyed cache); buff **content** (`"ch"/"tt"`) → `BuffChanged` and FEP (`"food"/"glut"`) →
  `FepChanged` ride the 1d-1 inbound-uimsg tap (`refresh` runs before `poll` so a new buff is one
  `BuffAdded`, not change-then-add). **`BAttrWnd` located via the public `CharWnd.battr` field** (no
  tree-walk); `feps`/`glut` and all their sub-fields (`FoodMeter.cap/els`, `El.res/a/ev()`,
  `GlutMeter.glut/lbl/gmod`) are **public** → FEP is **zero haven-edit**. **One 3-line core edit**:
  `AddonWidgets.buffDest` (the `protected Buff.dest` fade flag) so a removed-but-fading buff is
  excluded from `list()` and `BuffRemoved` is timely. Compile OK + 11 headless change-detection checks
  (`buffEqual`) + LuaJ parse. `hello` bumped to v0.7.0 (reads buffs/food at now/+3s, logs the first
  few of each event). Doc `phase-1d2-buffs-food.md`. **In-game verification pending.** 1d continues
  with study/skills (1d-3) and action bar/equip (1d-4).

- **Phase 1d-3 ✅** — Study/curiosity + skills, on the widget-tree mechanism. **`hafen.study.slots()`**
  (the curiosities in the study window: `SAttrWnd.StudyInfo.study` → `children(GItem.class)`, each
  snapshot `{res,name,lp,attention,cost,time,progress?}` — `lp/attention/cost/time` from the item's
  `resutil.Curiosity` info via `ItemInfo.find`, `progress` = `GItem.meter/100` best-effort; **`time` is
  the TOTAL study time — the client has no per-item countdown**) + **`hafen.study.summary()`**
  (`{lp,attention,cost}` live totals straight off `StudyInfo.texp/tw/tenc`) + **`StudyChanged`**; and
  **`hafen.char.skills()`/`skill(name)`** (known skills `{name,res}` from `SkillWnd.skg.csk.items`;
  `skill` = substring membership over name/res, like `buffs.has`). **`StudyChanged` is poll-driven**
  (reusing the 1d-2 `poll()` path): a curiosity being placed/finished is a widget create/`cdestroy`
  (not a uimsg) and its Curiosity info streams in a beat later, so `StudyAdapter.poll()` diffs the
  slots snapshot each tick (change-detected via `studySlotsEqual`) — `interested()`/`refresh()` are
  no-ops. **Zero `haven` edit** — every field read is public (`CharWnd.sattr`/`skill`, `SAttrWnd.
  StudyInfo`, `SkillWnd.skg.csk.items`, `Skill.nm/res`, `Curiosity.exp/mw/enc/time`, `GItem.res/meter/
  info()`), so 1d-1's `UI.java` tap and `AddonWidgets` are untouched; only `AddonManager.java` changed.
  Compile OK + 15 headless change-detection checks + LuaJ parse. `hello` bumped to v0.8.0 (reads study/
  skills at now/+3s, logs the first few `StudyChanged`). Doc `phase-1d3-study-skills.md`. **In-game
  verified ✅** — 3 study slots (`StudyChanged` streamed `0→1→3`), `summary` `lp=25567 att=8 cost=1`,
  40 known skills, `skill("Alchemy")`→true, full regression intact. **Finding:** not every study-slot
  item carries a `Curiosity` — two "A Bond of Blood & Soil" (Hearth-Magic bonds) returned `{res,name}`
  only and contributed 0 to the totals (faithful, not a gap); `progress`/meter was absent (best-effort
  confirmed). Deferred: per-item "time left" (doesn't exist), `SkillsChanged`, credos/experiences. 1d
  finishes with action-bar read + equip-change event (1d-4).

- **Phase 1d-4 ✅** — Action bar (read) + equip-change event, on the widget-tree mechanism.
  **API is `hafen.actionbar` — the engine's own name for the action bar is the "belt"** (`GameUI.belt`),
  which is confusing (you also *wear* a belt), so the addon API exposes it as `actionbar`; the bridge
  helpers are `actionbar*` but read the engine's `belt[]`. **`hafen.actionbar.slot(n)`** (`GameUI.belt`,
  a `BeltSlot[144]`; snapshot `{res,name,cooldown}` — `res` = icon resource, `name` = pagina action name /
  resource tooltip, `cooldown` = `PagButton.meter` 0..1 **only on ability slots, never seconds**) with
  **`ActionbarChanged{n}`**; and **`EquipChanged`** (payload = the equipment array) over the 1c-3
  equipment read. **Indexing = the raw 0-based game index (0..143)** — the same index the server +
  Phase-4 `actionbar.use` take (one canonical way), NOT 1-based Lua. **Both poll-driven** (like
  buffs/study): a slot set/clear mutates `belt[]` on a **deferred loader task** (so a uimsg-refresh would
  race the write) and equip/unequip is a widget create/`cdestroy` — neither a trustworthy targeted
  uimsg, so `ActionbarAdapter`/`EquipAdapter` diff each tick. Change-detection **excludes `cooldown`**
  (action bar) / **`wear`** (equip) so a live meter / durability drift doesn't spam the event. **Zero
  `haven` edit** (like 1d-3) — all reads public (`GameUI.belt`, `ResBeltSlot.getres`/`PagBeltSlot.pag`,
  `Pagina.res/button`, `PagButton.name/meter` [`AttrCache.get` swallows `Loading`→null],
  `Equipory.children`); only `AddonManager.java` changed. `hafen.items.equipment` refactored onto a shared
  `readEquipment()` (reused by `EquipAdapter`). Compile OK + **19 headless change-detection checks**
  (`actionbarEqual`/`equipEqual`) + LuaJ parse. `hello` bumped to v0.9.0 (scans the action bar at
  now/+3s, logs first few `ActionbarChanged`/`EquipChanged`). Doc `phase-1d4-actionbar-equip.md`.
  **In-game verification pending** (`ActionbarChanged` confirmed firing on stream-in + a manual slot-clear
  during the maintainer's first run). Deferred: `actionbar.use` (Phase 4, gated), per-slot `EquipChanged`
  granularity. **This completes Phase 1d** (the widget-tree read surfaces).

- **Phase 1e ✅** — Saved variables (`hafen.store`), the first **write-to-disk** surface. **`hafen.store.
  <name>`** is a per-addon proxy **table** (one Lua table per manifest `saved_variables` entry; read/write
  in place or replace wholesale) + **`hafen.store.flush()`**. Persisted as **compact JSON** under
  `savedata/<genus>_<char>/<addon>.json` (per-char, default) / `savedata/account/<addon>.json` (D-023
  account scope, declared `{"name":..,"scope":"account"}`) — reusing the REPL **`json()` writer** and the
  **`Json` reader** (`fillTable`: JSON obj→string-keyed table, array→1-based; arrays round-trip). `savedata`
  = **sibling of the addon dir** (follows the dev/release rule; `-Dhaven.savedatadir` overrides). **Lifecycle
  split:** account vars load at addon-load (before `OnLoad`); **per-char vars load at `OnEnterWorld`** — the
  `<genus>_<char>` folder is unknown at `RemoteUI.init` (pre-HUD). Flush on **`OnDisable`/teardown** (a relog
  rebinds the session → tears down + flushes old addons) using a **`charScope` captured at OnEnterWorld**
  (a live `gui()` lookup fails mid-relog), plus a **30 s throttled auto-save** in `tick` (UI thread; covers
  unclean exit) with a **write-skip cache** (unchanged scope → no disk I/O). Writes are **atomic** (tmp +
  move) and **non-fatal** (logged, never thrown). **Zero `haven` edit** — pure engine + filesystem
  (`GameUI.genus`/`chrid` already public). Edits: `Manifest.java` (parse `saved_variables`→`List<SavedVar>`),
  `Addon.java` (`store` ref + write-skip caches), `AddonManager.java` (facade + lifecycle + store helpers),
  `.gitignore` (`/savedata`). Compile OK + **19 headless end-to-end checks** (write→relog→read→increment→
  relog, nested-array round-trip, write-skip, `scopeKey` sanitize) + LuaJ parse. `hello` bumped to **v0.10.0**
  (bumps a per-char + an account login counter each world-entry, + a bounded `recent` array). Doc
  `phase-1e-saved-variables.md`. **In-game DoD check pending** (relog → the counter increments; a
  `hello.json` appears under `savedata/`). Deferred: sandbox/quotas (1f), dedicated shutdown hook.

- **Phase 1f-1 ✅** — Lua **sandbox**: strict env whitelist (D-017) + instruction hard-stop watchdog
  (D-018 layer 1). New **`io.brodgar.addon.Sandbox`**. Addons previously ran in full
  `JsePlatform.standardGlobals()` — which bundles `io`, `os.execute`, and **`luajava`** (arbitrary Java
  reflection/instantiation, a straight bypass of the `hafen.*` facade / P1). `Sandbox.create()` now
  builds the env **constructively**: `new Globals()` + load ONLY the safe libs (`JseBaseLib`,
  `PackageLib`, `TableLib`, `StringLib`, `JseMathLib`, `JseOsLib`) + the compiler (`LoadState`/`LuaC`),
  so `io`/`luajava`/`debug`/`coroutine`/`bit32` are **absent by construction**; `require`/`package`/
  `module` are stripped (PackageLib is loaded only so the stdlib modules can register in
  `package.loaded`, then dropped — libraries kept, require machinery gone), as are base `load`/
  `loadfile`/`dofile`/`loadstring` and `os.execute`/`exit`/`getenv`/`remove`/`rename`/`tmpname`/
  `setlocale`. The **watchdog** is a `DebugLib` subclass **assigned** to `Globals.debuglib` (NOT
  `load()`-ed → the per-instruction `onInstruction` hook fires but **no `debug` table** is reachable —
  verified `LuaClosure.execute` guards the hook only on `debuglib != null`); it enforces a per-call
  instruction budget (`-Dhaven.addon.insncap`, default 10 M → measured **~36 ms** to abort a tight
  `while true do end`; `onCall`/`onReturn`/`traceback` no-op'd to avoid the null-`globals` error-hook
  NPE via `processErrorHooks`). `Sandbox.arm(env)` resets the budget before **every** entry into Lua
  (`AddonManager.callLua`, `Addon.run`, REPL `eval`). The **`:lua` REPL keeps full `standardGlobals()`**
  (trusted operator console, incl. `luajava`) + the watchdog (typo protection). **Zero `haven` edit**
  (pure engine): `AddonManager` (loadAll/console/callLua/eval), `Addon.run`, new `Sandbox.java`. Compile
  OK + **49 headless checks** (withheld absent / whitelisted present / watchdog aborts a loop in BOTH
  the addon env and the console / bounded loop no false-trip) + LuaJ parse of `hello` under the sandbox.
  `hello` v0.11.0 (self-checks the sandbox at OnLoad: logs `withheld={io,require,…}`, proves `os.execute`
  is unusable via `pcall`; manifest `version` synced to 0.11.0). Doc `phase-1f1-sandbox.md`. **In-game
  verified ✅** (all withheld surfaces absent + `os.execute usable=false`; `:lua while true do end`
  aborted via the watchdog, client kept running). Deferred to 1f-3:
  the D-018 **soft per-tick time budget + auto-disable** (pairs with the panel warning). Also deferred:
  controlled addon-folder-only `require`, per-env string metatable (`LuaString.s_metatable` is a
  process-global static — a hostile addon could tamper with it).

- **Phase 1f-2 ✅** — **Reload UI + enabled set**: the WoW dev loop. **`:reload`** rebuilds the **addon
  layer only** (D-005) with no relog — `AddonManager.reload()` tears down every addon in **reverse load
  order** (reusing the relogin `teardown`: `OnDisable` → flush saved vars → drop subs/timers), re-scans
  `addons/` + the enabled set via `loadAll`, re-runs the enabled addons (`OnLoad`), and — if already
  in-world — restores per-char saved vars + **re-fires `OnEnterWorld`** (the WoW `PLAYER_LOGIN` analog, so
  login-counter saved vars tick on each reload). It's **queued to the UI-thread tick** (a `volatile
  reloadPending` checked first in `tick`, reset in `init`), because a console command lands on the UI
  thread (in-game chat) OR the stdin reader thread (terminal) — the same defer trick as
  `enterWorldPending`; `reload()` is `synchronized` so it serializes with session `init`. **Session infra
  is untouched** (the `AddonRoot` tick pump, the `OCache` gob callback, the inbound-`uimsg` tap are all
  session-scoped — reload only rebuilds the Lua layer). Teardown is complete-by-construction (P1+P2: the
  bridge is the sole factory; `Addon.subs`/`timers` are the owned-resource registry → no leaks). The
  **enabled set** (D-006, WoW apply-on-reload) is a persisted **disabled set** (default-**enabled**, so a
  new addon runs unless turned off) stored in the client's own prefs (`Utils.getprefsl`/`setprefsl`, key
  `addons/disabled`, i.e. client-folder not per-char); `loadAll` skips disabled ids and clears the pending
  flag. Console: **`:addons`** (lists every discovered addon + status: version/disabled/error + a pending
  hint), **`:addons enable|disable <id>`** (persist, pending until reload), **`:reload`**. Public
  `isEnabled(id)`/`setEnabled(id,on)` for the 1f-3 panel. **Zero `haven` edit** (only `AddonManager.java`).
  Compile OK + **14 headless enabled-set checks** (default-enabled / disable+enable round-trip /
  idempotency / persistence across a fresh read / null-empty no-op — against an **isolated `-Dhaven.prefspec`
  node** so real prefs are untouched) + LuaJ parse of `hello`. `hello` v0.12.0 (an editable **reload
  marker** log line + an account-scope **`acct.loads`** counter proving saved vars survive reload; the
  existing `OnDisable` log makes teardown visible). Doc `phase-1f2-reload-enabled-set.md`. **In-game DoD
  pending.** Deferred: `:reload <id>` / live enable-disable, the AddOns panel + `synchronized(ui)` widget
  teardown (→1f-3 / Phase 2 widgets).

- **Phase 1f-3 ✅** — **AddOns options panel + soft CPU-budget auto-disable** — completes Phase 1f. The
  **panel** is a new **`io.brodgar.addon.ui.AddonPanel`** (spec 10's intended home): it clones the voice
  `OptWnd.VoiceChatPanel` pattern but lives in the addon package, driving the all-static `AddonManager`
  facade like the voice panel drives `Voice`. It **extends `OptWnd.Panel` (a non-static inner class)
  cross-package** via qualified `opt.super()` + `opt.new PButton(...)` — needing **zero package-private
  `haven` access** (every widget it uses — `Scrollport`/`CheckBox`/`Button`/`Label` — is public), so the
  **only `haven` edit is ONE `// addon:` line** in `OptWnd` (the main-list button). One row per
  **discovered** addon (folder scan): an **enable/disable checkbox** (→ 1f-2 `setEnabled`, WoW apply-on-
  reload D-006), **name·version·author** + the description as a **tooltip**, and a **live status**
  (`loaded vX`/`disabled`/`error`/**`auto-disabled`**) refreshed each frame via `liveStatus(id)`. Globals:
  **Reload UI** (`requestReload`), **Enable all**, **Open addons folder** (`java.awt.Desktop`), + a
  "changes pending" hint (`reloadNeeded()`). It holds **no listener** (polls in `tick`) → **no leak**;
  rows capture only the id string (never an `Addon`/env) → reload-safe; it rebuilds rows when
  `reloadGen()` (bumped per completed `reload()`) changes. New public data API on `AddonManager`:
  `AddonInfo` + `describeAddons()`/`liveStatus()`/`reloadNeeded()`/`reloadGen()`/`requestReload()`/
  `openAddonsFolder()`. **Soft per-tick CPU budget (D-018 layer 2)** — the complement to 1f-1's per-call
  instruction cap: `callLua` (the single Lua entry point) times each call into `Addon.tickLuaNanos`;
  `tick()` zeroes it at the top (skipped on a reload tick) and runs `enforceSoftBudget()` at the end,
  which auto-disables an addon over **`Sandbox.SOFT_BUDGET_NANOS`** (10 ms; strict `>`) for
  **`SOFT_STRIKE_LIMIT`** (30) **consecutive** ticks — one at-or-under tick **resets** the strike count
  (must be sustained; a heavy `OnEnterWorld`/one janky frame won't trip it). `autoDisable()` records a
  panel warning (`autoDisabledWarn`, cleared in `loadAll`), runs the 1f-2 teardown, and drops the addon
  from the live set — **session-only, NOT the persisted enabled set** (a reload/login re-tries; the user
  persist-disables via the checkbox). The **`:lua` REPL owner is exempt** (not in `addons`). Tunables
  `-Dhaven.addon.tickbudgetms`/`tickstrikes`. **One `haven` edit** (the `OptWnd` line) + engine
  (`Sandbox` constants, `Addon` fields, `AddonManager`) + the new `ui` package + the new **`hogtest`**
  demo addon (dormant by default via account var `cfg.arm`, seeded false; when armed burns ~15 ms/
  `OnUpdate` — over budget, under the hard cap — to demo the auto-disable; folding a hog into `hello`
  would break the regression harness, so it's a dedicated addon per PLAN). Compile OK + **16 headless
  checks** (strikes accumulate → auto-disable at the limit / under-budget resets / `==budget` no-strike /
  `callLua` accumulates wall time / REPL exempt) + LuaJ parse of hogtest under the sandbox. `hello`
  **unchanged** (1f-3 adds no Lua-facing API — it's operator UI + an engine watchdog). Doc
  `phase-1f3-options-panel-soft-budget.md`. **In-game DoD pending.** Deferred: live enable/disable,
  per-addon config sub-panel (Phase 2), string-metatable hardening.

- **Phase 2a ✅** — Custom widgets/windows + the GOut draw wrapper (`hafen.ui`), the **first slice of Phase 2**
  and the foundation for overlays/hooks. **`hafen.ui.window(opts)`** = a draggable, titled `haven.Window`
  wrapping a content widget; **`hafen.ui.widget(opts)`** = a bare content widget. Both return a handle
  (`:move(x,y)`/`:show`/`:hide`/`:visible`/`:pack`/`:size(w,h)`/`:destroy`). New **`io.brodgar.addon.LuaWidget
  extends haven.Widget`** — a leaf whose `tick`/`draw`/`mousedown`/`mouseup`/`mousemove`/`mousewheel` forward
  to Lua callbacks (`onDraw(g,w,h)`, `onTick(dt)`, `onClick(x,y,button)` [truthy = consume], `onMouseUp`,
  `onMouseMove(x,y)`, `onWheel(x,y,amount)`, `onClose`) through **`callLua`** (the one watchdog-armed,
  error-isolated, CPU-accounted choke point). The **`g` GOut wrapper** (`text/atext/rect/frect/line/prect/
  color`, colon-called → self=arg1) is bound to the live `GOut` **only during `onDraw`** and inert otherwise
  (an addon can't stash `g` and corrupt the pipeline); coords are widget-local pixels; `g:image` deferred
  (needs Tex/resource resolution). **Windows are composition, not a `LuaWindow` subclass** — a plain `Window`
  (title bar + drag + close, for free) + a `LuaWidget` content child, so the forwarding lives in exactly one
  class; the window's `reqclose` is redirected to fire `onClose` then destroy (a client-side widget has no
  server to send `wdgmsg("close")` to). **Bridge-owned (P2):** new **`Addon.widgets`** (`List<LuaWidget>`)
  owned-resource list; `teardown` destroys every one under `synchronized(ui)` (`destroyWidgets`) — cascades to
  the chrome, no leaks, reload-safe. **`callLua` changed `void`→`Varargs`** so the input forwards read the
  callback's return for consume (existing callers ignore it — no behavior change). Default parent `ui.root`;
  `parent="gameui"` attaches under the HUD (falls back to root pre-HUD). **Zero `haven` edit** — every
  `Widget`/`Window`/`GOut` member used is public (like 1d-3/1e). Compile OK + **13 headless input-plumbing
  checks** (mouse arg order = params-direct-no-self, truthy consume, `dead` guard after `kill()`, no-callback
  fall-through) + LuaJ parse of the harness under the sandbox. `hello` **v0.13.0** (a draggable "Hello 2a"
  window drawing clock + hp/stamina/energy bars + a click counter; auto-destroyed on reload/disable). Doc
  `phase-2a-custom-ui-gout.md`. **First in-game run** surfaced (+fixed) an OnEnterWorld-timing bug: the window
  was hidden until `:reload` because `OnEnterWorld` fired one tick BEFORE `GameUI` is attached to `ui.root`
  (proven by tracing the widget protocol — see §8), so the window was a ui.root sibling placed before GameUI
  and drawn under the HUD. **Fixed** by gating OnEnterWorld on `gui().parent != null` (HUD in the tree) — one
  line in `tick()`, benefits every addon. **Clean-login re-verification pending** (drag / click-consume / close).
  **Known gap:** `onDraw` runs in `UI.draw` *after* the tick's soft-budget window, so draw time isn't counted
  toward the per-tick CPU budget (only the per-call instruction cap guards a runaway draw). Deferred to later
  2 slices: `g:image`/resources, `UI.scale`, keyboard (`hafen.key`), widget focus/`grab`, overlays (2b).

- **Phase 2b ✅** — HUD overlays + world-space gob overlays (`hafen.ui.overlay` / `hafen.ui.gobOverlay`), the
  second Phase-2 slice — addons can now draw **outside a widget**. **`hafen.ui.overlay(fn)`** paints `fn(g,w,h)`
  on top of the HUD: `UI.drawafter` is one-shot (cleared each `UI.draw`), so the engine keeps a persistent
  per-addon list and **re-queues ONE afterdraw each tick** — the frame loop runs `tick()` then `display()`
  (`UILoop.Frame.run`), so the afterdraw fires that same frame **after `root.draw`**, i.e. above GameUI (which
  a `ui.root` sibling added before GameUI can't be — the 2a login/reload asymmetry). **`hafen.ui.gobOverlay(
  filter, fn)`** paints `fn(g,gob,sx,sy)` over each matching gob via a new **`LuaGobOverlay`** — a `GAttrib`
  that is also `RenderTree.Node`+`PView.Render2D`, modelled 1:1 on `haven.SpeakerIcon`: the render tree keeps
  it pinned over the gob in every camera and disposes it with the gob, and its `Render2D` pass runs inside the
  same `UI.draw` traversal (`PView.draw`→`list2d.draw`) so a Lua draw callback there never races the tick.
  **One shared attrib per gob serves all addons** (it holds no addon state — on draw it asks
  `paintGobOverlays` to re-check every addon's filter for that gob); a **throttled sweep** (in `tick`, default
  5 Hz, `-Dhaven.addon.gobsweepsec`) attaches the attrib to matching gobs (attach-only, like `SpeakerIcon.
  sweep`, but with dynamic Lua filters so it's rate-limited); idle attribs are detached wholesale once no
  addon wants gob overlays. **`filter`** is a function `filter(gob)->truthy` OR a name-substring string (like
  `world.gobs`); the `gob` is the `hafen.gob.info` snapshot. Both handles auto-remove on reload/disable
  (bridge-owned lists `Addon.hudOverlays`/`gobOverlays`, P2). The 2a `g` wrapper was **extracted into a shared
  `io.brodgar.addon.LuaGOut`** — widgets, HUD overlays and gob overlays now use one canonical draw surface
  (D-013); `LuaWidget` refactored onto it (identical behaviour). Everything runs on the one UI thread (frame
  loop is `tick→draw→swap`), so tick-Lua and draw-Lua never overlap; all filter/draw calls route through
  `callLua` (watchdog + isolation + CPU accounting). The **sweep** filter time IS budget-covered (in `tick`);
  **draw** callbacks (HUD + gob, like 2a `onDraw`) run in `UI.draw` after the budget window, so their time
  escapes the soft budget (hard per-call instruction cap still applies — a known gap). **Zero `haven` edit**
  (all public: `UI.drawafter`/`AfterDraw`, `GAttrib` public ctor+`gob`, `Gob.setattr/getattr/delattr`,
  `PView.Render2D`, `RenderTree.Node`, `Homo3D.obj2view`, `Area.sized`, `GOut.sz()`). Compile OK + **21
  headless checks** (register/remove lifecycle, string+function filter, `error()` isolation, nil-guard,
  invalid-arg reject) + LuaJ parse of the harness under the sandbox. `hello` **v0.14.0** (a HUD overlay =
  top-centre readout + a crosshair at exact screen centre; a gob overlay = a green marker + label over every
  player's head — self always matches; gob count cached on a 1 s timer, not per-frame). Doc
  `phase-2b-overlays.md`. **In-game DoD pending** (overlay paints over the HUD; head-tags track the camera;
  `:reload`/disable removes both cleanly). Deferred: draw-time CPU budget, per-overlay anchor/offset,
  `g:image`, a possible per-gob match cache for the sweep.

- **Phase 2c ✅** — Input/gesture hooks (`hafen.hook.input`), the **first hook level** (spec 13 §L1) and the
  third Phase-2 slice — addons can now **intercept a client widget's input before the widget sees it** and
  cancel it (`ev:preventDefault()`), the JS `event.preventDefault()` model at the widget-input layer.
  **`hafen.hook.input(target, event, fn)`** installs `fn` as a **pre-hook** via Haven's built-in
  **`Widget.listen`** seam: `Widget.handle` runs listeners **before** the widget's own handler, and a listener
  returning `true` **short-circuits** it — so a Lua handler calling `ev:preventDefault()` <i>is</i> the
  pre-hook's preventDefault, at **ZERO `haven` edit**. (Per the audit, that short-circuit also blocks child
  dispatch, so at L1 preventDefault is also stopPropagation → **one** canonical consume, no separate
  `stopPropagation`; `ev:default()`/`resend()` belong to the L2 action choke point in 2d.) New
  **`io.brodgar.addon.LuaInputHook`** = an `EventHandler<Widget.Event>` that, on dispatch (UI thread), builds
  the `ev` table for the concrete event type (`PointerEvent.c`→`x,y`; `MouseButtonEvent.b`→`button`;
  `MouseWheelEvent.a`→`amount`), calls the addon's `fn` through **`callLua`** (watchdog-armed, error-isolated,
  CPU-accounted), and returns whether `preventDefault()` was called (the Lua return is **ignored** — differs
  from a `LuaWidget`'s own `onClick` truthy-return, because a hook intercepts *someone else's* widget).
  **`target`** is a string token → a live engine widget: `"mapview"`(alias`"map"`)→`view`, `"gameui"`(alias
  `"hud"`)→`gui()`, `"root"`→`ui.root`; **`event`** ∈ `mousedown`/`mouseup`/`mousemove`/`mousewheel`. Register
  in **`OnEnterWorld`** (the target must exist — an unknown/absent target throws a clear Lua error, mirroring
  2a). **Bridge-owned (P2):** new **`Addon.hooks`**; `teardown` runs **`teardownHooks`** (set dead +
  `Widget.deafen`) **before** clearing subs — critical because a `:reload` keeps the engine widgets **alive**
  (only the Lua layer rebuilds), so a leaked listener would fire into a torn-down env; the `alive` flag also
  no-ops a dispatch racing teardown. A generic `listen()` cast (`Class<? extends Event>`→`Class<Event>`,
  compile-time only) sidesteps the wildcard-capture inference. **Zero `haven` edit** (all backings public:
  `Widget.listen`/`deafen`/`handle`, `PointerEvent.c`, `MouseButtonEvent.b`, `MouseWheelEvent.a`, `UI.root`).
  Edits: `AddonManager.java` (facade + helpers + teardown), `Addon.java` (`hooks` list), new `LuaInputHook.java`.
  Compile OK + **20 headless checks** (preventDefault suppresses the widget default / passthrough runs it / ev
  fields x,y,button,amount / dead-flag + deafen both inert) + LuaJ parse of the harness. `hello` **v0.15.0** (a
  **map-lock** demo: clicking the 2a window body toggles `mapLock`; the MapView `mousedown` hook cancels map
  clicks while ON — movement suppressed — and only observes-logs while OFF; the window line + 2b HUD readout
  border turn **red** when locked). Doc `phase-2c-input-hooks.md`. **In-game DoD pending** (toggle map-lock →
  clicks cancelled, char doesn't move; toggle off → moves; `:reload` leaves no leaked hook). Deferred: widget-
  *type* targets (needs the 08 factory seam), key events + global hotkeys (2e), `ev:default()`/`resend()` (2d),
  hook priority/ordering (Q-012), draw/dispatch not applicable (synchronous input).

- **Phase 2d ✅** — Action hooks (`hafen.hook.action`), the **second hook level** (spec 13 §L2) and the fourth
  Phase-2 slice — addons can now **intercept an outbound player action before it reaches the server**, cancel
  it, or re-issue it, at the single choke point **`UI.wdgmsg`** where the args are **already fully resolved**
  (for a MapView move: `ev.args[2]` = the destination world coord — impossible at 2c's L1, pre-hit-test). The
  **DoD**: intercept a move-click, run logic, then re-send. **`hafen.hook.action(msg, fn)`**: `fn(ev)` runs
  before the send with `ev = { msg, sender (widget class simple name), args (1-based snapshot; Coord→{x,y},
  primitives direct, any other Java object opaque + round-tripping), preventDefault(), resend(), send(t) }`.
  **`ev:resend()`** re-sends the **original** args verbatim (lossless); **`ev:send(t)`** sends a new arg table
  (converted Lua→Java); both **bypass the hook chain** (they call the new **public `UI.rawWdgmsg`**, not
  `wdgmsg`) so re-issuing an action **cannot loop** (spec's re-entrancy caveat), and both **imply
  preventDefault**. `ev.args` is a read snapshot — to rewrite an action use `send` (one canonical way). **The
  one `haven` edit**: `UI.wdgmsg` split into a hook call (`AddonManager.onWdgmsg`) + the original send body
  moved into `rawWdgmsg` (two `// addon:` lines) — D-011's invasiveness allowance, minimal + centralized.
  **Threading (the key insight):** the MapView `"click"` is sent from the **render thread** (the async
  hit-test callback `Hittest.ckdone`) but **under `synchronized(ui)`**, and the frame loop runs input dispatch
  + the addon tick + draw under that **same `ui` monitor** (`UILoop.Frame.tick`). So `onWdgmsg` runs the hook's
  Lua **only when the calling thread already holds the `ui` monitor** (`Thread.holdsLock(ui)`) — true on every
  player-action path, and since tick/draw hold it too the hook Lua **never races other Lua**; it only *tests*
  the lock (acquires nothing) so there's **no deadlock**. A rare off-lock `wdgmsg` is passed through unhooked.
  A **near-zero fast path** (`actionHooks.isEmpty()` → per-`msg` lookup) keeps `UI.wdgmsg` cheap when unhooked
  (it's on the hot action path), and a **re-entrancy guard** stops a hook that itself sends an action from
  recursing. New **`io.brodgar.addon.LuaActionHook`** (builds `ev`, forwards via `callLua`, and the
  `toLua`/`toJava`/`argsToLua`/`luaToArgs` marshalling), **`Addon.actionHooks`** (owned list, unregistered on
  teardown — no widget to deafen, the hook lives only in the dispatch map), facade + `onWdgmsg` +
  register/unregister/teardown in `AddonManager`. Compile OK + **33 headless checks** (marshalling round-trips
  incl. Coord↔{x,y} + opaque-object identity + a full click-arg vector; `ev` build + preventDefault +
  passthrough + error isolation in a real `Sandbox.create()` env; the colon-call **self=arg1** convention
  `send` relies on; the no-hook fast path) + LuaJ parse of the harness. `hello` **v0.16.0** (RIGHT-click the
  window arms **move-intercept**: the `"click"` action hook logs the resolved destination, `preventDefault` +
  `resend` → the char still moves; LEFT-click still toggles 2c map-lock; HUD border orange while intercepting;
  map-lock ON pre-empts it — L1 cancels before any `"click"` is sent). Doc `phase-2d-action-hooks.md`.
  **In-game DoD pending.** Deferred: hook priority/ordering (Q-012), post-hooks, the action-hook/draw CPU-budget
  gap (Lua time between ticks is zeroed before enforcement — layer-1 instruction cap still applies).

- **Phase 2e-1 ✅** — Message hooks (`hafen.hook.message`), the **third hook level** (spec 13 §L3) and the fifth
  Phase-2 slice — the **inbound mirror of 2d's L2**: addons can now **intercept a server→client UI update before
  the widget applies it** and either **swallow** it (`ev:preventDefault()`) or **rewrite** its args
  (`ev:rewrite(t)`). Where L2 sits on the outbound `UI.wdgmsg` (player actions), L3 sits on the inbound
  `UI.uimsg` (server updates). **`hafen.hook.message(msg, fn)`**: `fn(ev)` runs at the single application point
  `UiMessage.run`, before `dispatch(wdg, MessageEvent)`, with `ev = { msg, target (receiving widget class
  simple name), args (1-based snapshot, same marshalling as L2), preventDefault(), rewrite(t) }`.
  `preventDefault` **wins** over `rewrite` when both fire; a **swallowed** message also **skips the 1d post-apply
  read tap** (the widget didn't change → no `*Changed`). **The one `haven` edit**: `UiMessage.run` calls
  `AddonManager.onMessage(wdg,msg,args)` (returns the args to apply, or null to swallow) before the dispatch,
  and gates the read tap on the message being applied — two `// addon:` lines (the **second edit region** in
  `UI.java`, after 1d-1's tap / 2d's hook; D-011). **Threading:** unlike L2 (whose senders aren't all
  UI-locked, hence its `holdsLock` gate), L3 is reached **only** from `UiMessage.run` **always under
  `synchronized(ui)`** — the same monitor tick/draw hold — so the hook Lua never races other Lua and **no gate
  is needed**; the trade-off is that a heavy handler stalls the frame (spec's Loader-thread caveat; the
  instruction watchdog still bounds a single runaway). A **near-zero fast path** (`messageHooks.isEmpty()` →
  per-`msg` lookup) keeps hot `uimsg` application cheap when unhooked. `MessageEvent`'s ctor **interns** the
  name, so this slice (which never rewrites the name) sidesteps the intern caveat by construction. The 2d arg
  marshalling was **extracted into a shared `io.brodgar.addon.LuaMarshal`** (pure refactor; both hook levels use
  it — D-013, like `LuaGOut`/`readEquipment`). New **`io.brodgar.addon.{LuaMarshal, LuaMessageHook}`**,
  `Addon.messageHooks` (owned list; unregistered on teardown — no widget to deafen, like an action hook, P2),
  facade + `onMessage` + register/unregister/remove/`teardownMessageHooks` in `AddonManager`; `LuaActionHook`
  refactored onto `LuaMarshal` (identical behaviour). Compile OK + **27 headless checks** (`LuaMarshal`
  round-trips incl. Coord↔{x,y} + opaque identity + the large-`Long` double path; `ev` build + preventDefault +
  rewrite [the colon `self=arg1` convention] + passthrough + error isolation in a real `Sandbox.create()` env;
  `onMessage` precedence — prevent-wins-over-rewrite, dead-hook skip — and the no-hook fast path) + LuaJ parse of
  the harness. `hello` **v0.17.0** (MIDDLE-click the window arms **vitals-freeze**: the `"set"` message hook,
  scoped to `ev.target == "IMeter"`, `preventDefault`s the meter update while ON → the hp/stamina/energy bars
  freeze on the HUD + in the window until toggled off, fully reversible; observe-logs the first few meter `set`s
  while OFF; LMB=map-lock and RMB=move-intercept still work; HUD border cyan while freezing). Doc
  `phase-2e1-message-hooks.md`. **Task 2e was split** into 2e-1 (this) + 2e-2 (`hafen.key`), like 2c=L1/2d=L2.
  **In-game DoD pending.** Deferred: rewrite the message *name*, hook priority (Q-012), post-hooks, the
  message-hook/draw CPU-budget gap.

- **Phase 2e-2 ✅** — Global hotkeys (`hafen.key`), the sixth Phase-2 slice and the second half of task 2e —
  addons can now bind a **remappable, persisted** key that runs a Lua handler on press. **`hafen.key.bind(name,
  defaultKey, fn)`** → handle `{ :remove(), :key() }`: `name` namespaces the binding to `addon/<id>/<name>` in
  the client's own **`KeyBinding`** registry (so it's re-mappable + persisted in the client prefs and can't
  collide); `defaultKey` is a key string (`"F5"`/`"Ctrl+M"`/`"Shift+Alt+Left"`, or **`nil`/`"None"`** for
  unbound-by-default); `fn()` runs on press. **ZERO `haven` edit** (like 2c's `Widget.listen`): the seam is the
  engine's own global-hotkey path — **`UI.keydown` fires a `GlobKeyEvent` only after an unconsumed focused
  `KeyDownEvent`** (a focused text field consumes all ordinary typing, so a plainly-typed hotkey is suppressed
  while typing — like the client's own hotkeys), and that event walks the widget tree calling
  **`Widget.globtype`**; the invisible **`AddonRoot`** tick widget (already on `ui.root` every
  session) **overrides `globtype`** to run **`AddonManager.onGlobKey`**, which matches every registered hotkey
  and, on a match, runs the handler and **consumes** the key. AddonRoot is an **early** `ui.root` child →
  walked **last** in the reverse-child `GlobKeyEvent` traversal, so **a client binding on the same key wins**
  (addon hotkeys are the fallback, never a hijack). New **`parseKeyMatch`** (key string → `KeyMatch`:
  `KeyMatch.forcode` for named keys via a `KEYCODES` table — F1..F12/arrows/Home/End/PageUp-Down/Space/Enter/
  Tab/Esc/Backspace/Delete/Insert — and `KeyMatch.forchar` for any single char; case-insensitive modifier
  aliases Ctrl/Control/Ctl/C, Shift/S, Alt/Meta/M; **exact** modifier match so `"M"` never fires on `Ctrl+M`;
  invalid → a clear Lua error). Dispatch runs on the **UI thread** (input dispatch, under `synchronized(ui)`,
  like a 2c input hook) → `callLua` direct, no thread guard; **near-zero fast path** (`keyBinds.isEmpty()`),
  scanned only on an unconsumed keypress (not per frame). New **`io.brodgar.addon.LuaKeyBind`** (a client
  `KeyBinding` + the Lua `fn` + `alive`; `matches(ev)` = `binding.key().match(ev)` — the **same** `KeyMatch`
  comparison the client uses), **`Addon.keybinds`** (owned; `teardownKeyBinds` marks each dead + drops it from
  the global dispatch list — like an action/message hook there's no widget to `deafen` — but **deliberately
  keeps** the process-global persistent `KeyBinding`, which is how a user's re-map survives a reload), facade
  `hafen.key.bind` + `newKeyBind` + `onGlobKey` in `AddonManager`. Compile OK + **31 headless checks** (parser
  incl. named keys/letters/modifier aliases/`None`/invalid; `KeyMatch` modifier-exactness on `forcode` keys +
  a `forchar` match; `onGlobKey` fast-path/fire+consume/mod-mismatch-no-fire/dead-skip/first-match-wins in a
  real `Sandbox.create()` env; `newKeyBind` register/handle/`:key()`/error paths) + LuaJ parse of the harness.
  `hello` **v0.18.0** (**Ctrl+H toggles the 2a window** — bound in the **file body**, showing a hotkey needs no
  live target, unlike the input/action/message hooks). Doc `phase-2e2-global-hotkeys.md`. **In-game DoD pending**
  (Ctrl+H toggles the window; ordinary typing in a focused field never triggers a hotkey; the `addon/hello/toggle`
  binding is re-mappable + persisted in the keybind options; `:reload`/disable leaves no leaked hotkey).
  **Committed `55b71ecf`.** (**L4** method/hookable-subclass hooks → Phase 3.)

- **Phase 2e-3 ✅** — Addon hotkeys in the client keybind panel (WoW-style) — completes the `hafen.key` contract
  ("shown in the client keybind panel"), which 2e-2 had deferred. When an addon registers ≥1 `hafen.key.bind`
  hotkey, **Options > Keybindings** now shows **a section named after the addon** with the client's standard
  capture button per hotkey; an addon with no hotkey shows no section. **Re-mapping persists across restarts for
  free** — it rides the client's own `KeyBinding` persistence (the capture `SetButton` calls `KeyBinding.set` →
  `Utils.setpref`, restored next launch by `KeyBinding.get`/`KeyMatch.restore`), so the addon layer adds **no
  new capture or persistence code**. **One `haven` edit** (D-011): a `// addon:` block in `OptWnd.BindingPanel`
  after "Voice chat" that loops the new **`AddonManager.describeKeyBinds()`** (the live addon hotkeys grouped by
  owner — `KeyBindGroup{addon, binds}` / `KeyBindEntry{name, binding}`, only live binds, first-registration
  order) and reuses the existing `addbtn` + `SetButton`. This is the **second** `OptWnd` addon edit (after
  1f-3's AddOns-panel button); the engine side is purely the read-only `describeKeyBinds()` + two immutable
  data types (mirroring 1f-3's `AddonInfo`). **Plus a client-wide keybinding-EXCLUSIVITY fix** — the maintainer
  found the vanilla client lets the **same key bind to several actions at once** (`KeyBinding.set` had **no
  conflict check** → the `GlobKeyEvent` walk's first match wins, the rest are silently shadowed; **not an addon
  bug** — addon binds are ordinary `KeyBinding`s and inherited it). Patched at the source: **`KeyBinding.set(key)`
  now unbinds a newly-assigned real key from every OTHER binding firing on the same key+modifiers** (WoW-style —
  a key can only be bound to one action), setting them to `None`; the panel's `SetButton` re-reads `key()` each
  frame so a stolen row updates to `None` live. Char-vs-code representations reconciled via
  `KeyEvent.getExtendedKeyCodeForChar` (a letter's `forchar('G',C)` and `forcode(VK_G,C)` conflict); different
  modifiers coexist (`J` vs `Ctrl+J`); disable (nil) / revert-to-default (null) never steal; `KeyBinding.get`
  (load) bypasses `set` so there's no load-time cascade; shipped default overlaps stay until reassigned. **Second
  `haven` core edit this slice** (`KeyBinding.java`: `set` + private `clear`/`sameKey`/`keycode`, one `// addon:`
  block; benefits ALL client bindings, not just addons). Compile OK + **8 headless panel checks** (`describeKeyBinds`:
  empty→no sections; two addons → two sections in registration order, labelled by `manifest.name`, rows carrying
  the identical `KeyBinding`; dead bind excluded; addon with no live bind → no section) **+ 9 exclusivity checks**
  (steal-on-assign, incl. when the other held the key only as a **default** and across char/code forms; different
  mods coexist; disable/revert don't steal, no NPE) + LuaJ parse of the harness. `hello` **v0.19.0** (a second
  **`ping` hotkey unbound by default** → the "Hello" section lists `toggle`=Ctrl+H + `ping`=None, demoing
  multi-row grouping + the panel's assign-from-scratch flow). Doc `phase-2e3-keybind-panel.md`. **In-game DoD
  pending** (a "Hello" section appears in the keybind options; re-map `toggle` and it persists across a client
  restart; assign the unbound `ping` a key and it fires; **assigning a key steals it from whatever row/section
  held it**; disable `hello`+`:reload` removes the section). Deferred: per-binding **display labels** (rows use
  the `name` arg — a friendlier title would need an optional API arg, kept out to preserve the 2e-2 API), showing
  stored-but-inactive (disabled-addon) bindings, live panel refresh while the panel is open, exclusivity
  `modign`/revert-to-default edge cases.

- **Phase 3a ✅** — Widget-creation interception (`hafen.ui.onWidgetCreate`), the **first slice of Phase 3
  (widget replacement)** — addons can now **observe every SERVER widget as the client builds it**, from Lua, with
  the **targeting descriptor** `{id, type, place, caption, parentType}` (D-024). `fn(desc)` runs per placed
  server widget (return **ignored** — this slice is **observe-only**; adopting a widget as a hidden model + a
  custom view is 3b/3c). Every server widget flows through `UI.NewWidget.run` (construct + `bind(wdg,id)`) then
  `UI.AddWidget.run` (`pwdg.addchild(wdg,pargs)` — e.g. `GameUI.addchild`, the `place`-string HUD switch); the
  descriptor needs **both** (`type` is only known at creation — the instance doesn't carry it; `place`/
  `parentType`/`caption` only exist after placement), so **two `// addon:` core edits** feed it, both in
  **`UI.java`** (the **third `UI.java` edit region**, after 1d-1's read tap / 2d's `wdgmsg` split / 2e-1's
  message hook): `NewWidget.run` → `onWidgetCreated(id, typenm)` records `id→typenm` (only while an observer
  exists; only the in-flight set — the matching placement `remove`s it, so the map stays tiny), `AddWidget.run`
  (right after `pwdg.addchild`) → `onWidgetPlaced(id, wdg, pwdg, pargs)` builds the descriptor + fires observers.
  **Firing at placement** (not pure creation) is the first moment the FULL descriptor exists — refines the
  api-reference's indicative "`UI.NewWidget` hook" note. Uses **adopt-after-create (seam B)**, not the factory
  override (seam A / `Widget.types`, deferred — dodges the audit's off-UI-thread `create()` caveat + needs no
  registry tampering); B is the spec's default for HUD windows. New **`io.brodgar.addon.LuaWidgetObserver`**
  (builds the `desc` table — a null field is left **absent** → Lua `nil` — and forwards via `callLua`,
  watchdog+isolation+CPU-accounted); **`Addon.widgetObservers`** owned list (flat **global** observer list — an
  observer watches EVERY creation, no per-target keying, unlike the hook levels' per-name maps); facade
  `hafen.ui.onWidgetCreate` + `newWidgetObserver`/`removeWidgetObserver`/`teardownWidgetObservers` +
  `widgetTypes`/`widgetObservers` fields (cleared/torn down per session) in `AddonManager`. **Threading:**
  `onWidgetPlaced` runs inside `AddWidget.run`'s `synchronized(ui)` (Loader thread, monitor tick/draw hold — no
  race, like L3; no `holdsLock` gate). **Near-zero fast path** when no observer is registered (every widget
  placement passes here, so this matters); `widgetTypes` records nothing when unused. Descriptor fields:
  `parentType="GameUI"` for every HUD-placed window; `caption` = a `Window`'s own `cap` (a cupboard reports its
  title), `nil` for a bare widget the engine wraps (e.g. `Inventory` — identify by `type`/`place`); `place` =
  `pargs[0]` if a string. **Beyond the 2 one-liners, zero `haven` edit** (`Window.cap`/`Widget.getClass` public).
  Compile OK + **25 headless checks** (descriptor incl. nil-handling for absent fields; `onWidgetPlaced`
  fast-path no-fire + full field extraction + `type`-from-map + record removal + non-string-place→nil;
  `onWidgetCreated` records-only-when-observed + null-type ignore; `Window` caption via the direct `invoke` test
  — the `instanceof Window` path is skipped headless since the class needs GL) + LuaJ parse of the harness.
  `hello` **v0.20.0** (a file-body `onWidgetCreate` observer logging the descriptor of every HUD window + any
  titled container — capped login burst, uncapped titled windows; window title bumped to "Hello 3a"). Doc
  `phase-3a-widget-interception.md`. **In-game DoD pending** (login logs the HUD-window descriptors; open a
  cupboard/crafting window → a fresh `caption=`d line; `:reload`/disable leaves no leaked observer). Deferred to
  3b (the `model` handle: adopt/hide/show/items/item-actions/lifecycle) + 3c (`hafen.ui.replace` + the bags
  example + reload un-hide). Also deferred: factory-override seam (A), pre-filtering the observer to HUD-level.

- **Phase 3b ✅** — The **`model` handle** (`hafen.ui.adopt`), the **second Phase-3 slice** — an addon can now
  **adopt a live server widget by its `desc.id`** (the handle a 3a `onWidgetCreate` observer hands out) and hold it
  as a hidden **model** it presents a custom **view** over ("wrap, don't reimplement", D-009). **`hafen.ui.adopt(id)`**
  → a **`LuaModel`** handle, or `nil` if no widget has that id (destroyed/absent). Handle: **`:hide()`/`:show()`**
  (toggle `Widget.hide`/`show`; a hidden server widget **stays bound to its id** → still receives `uimsg`/`addchild`
  and still routes `wdgmsg` — *delivery is by id, not visibility* — so it is a perfect **headless model**, D-009
  verified), **`:visible()`**, **`:raw()`** (the server widget id — a facade-safe `WidgetRef`; **no raw Java object
  crosses into Lua**, P1/D-017), **`:items()`** (an array of **Item snapshots** `{res,name,num,wear,pos}` read live
  off the widget's `WItem` children, reusing the 1c-3 `itemSnapshot`/`cellPos` — empty for a non-inventory widget),
  and lifecycle **`:onItemAdded(fn)`/`:onItemRemoved(fn)`** (`fn(item)`; **poll-diffed each tick**, identity-keyed
  `IdentityHashMap<WItem,LuaValue>` exactly like `BuffsAdapter` — an item add/remove is a `WItem` create/`cdestroy`,
  not a `uimsg`) **/`:onDestroy(fn)`** (`fn()` once when the SERVER destroys the widget, detected in the same poll by
  `UI.getwidget(id) != wdg`). The model lives in a **flat global list** (`pollModels()` in `tick` after the tree-
  adapter poll; near-zero fast path when nothing is adopted) + the addon's owned registry (`Addon.models`, P2).
  **Teardown UN-HIDES** any widget the addon had hidden (`hidden` flag), so disabling a UI-replacement addon
  **restores the stock window** (spec 08) — only a still-live server-bound widget (skips a stale/destroyed id), under
  `synchronized(ui)` like `destroyWidgets`; fires on `:reload`/disable/auto-disable (same session, widget alive) and
  **skips a relog** (widget already gone). `init` clears the session-scoped `models` (ids are per-session). New
  **`io.brodgar.addon.LuaModel`** (data holder: `owner`/`id`/`wdg`/`alive`/`hidden` + the callbacks + item cache);
  `newModel`/`modelHandle`/`fnOrNull`/`pollModels`/`pollModelItems`/`teardownModels` + the `models` field in
  `AddonManager`; `Addon.models`. **Threading:** every op (adopt, handle methods, poll, un-hide) runs on the UI
  thread holding the `ui` monitor (tick/draw/input/hotkey, or an observer under `AddWidget.run`'s `synchronized(ui)`)
  → no race, no new lock, no `holdsLock` gate. **KEY SCOPE CALL — item MUTATING verbs deferred to Phase 4 (gated):**
  spec 08's `model` sketch listed `take`/`drop`/`transfer`/`use` (→ `GItem.wdgmsg`), but those are **outbound
  gameplay actions**, which the closed design **gates** (D-010/D-025; the security spec's "the modding build never
  exposes automation"; this queue's Phase-4 **"item verbs"**). So 3b ships the model's **read + lifecycle** surface
  only (`:items()` = read-only snapshots) — the 3b DoD requires exactly that; the verbs attach to the Phase-4
  `hafen.act.*` tier (one canonical, gated place). **Zero `haven` edit** (all backings public: `UI.getwidget`,
  `Widget.hide`/`show`/`visible`/`children`, the 1c-3 helpers) — 3a's two `UI.java` observe seams stay the only
  Phase-3 core edits. Compile OK + **27 headless checks** (the handle surface on a bare `Widget` — `raw`/`visible`/
  `hide`/`show`/`items`/the three callback setters, incl. chaining, `fnOrNull`, and dead-model no-ops; `newModel`
  rejects a non-number id + returns nil with no UI; `pollModels` no-mass-`onDestroy` with no UI; `teardownModels`
  drops both lists + is ui-null/empty safe) + LuaJ parse of the harness under the sandbox. `hello` **v0.21.0**
  (adopts the main inventory from the onWidgetCreate observer; **Ctrl+B** hides/shows its grid; `readBags` logs the
  item count/first/visible at now/+3s; logs the first few item ADD/REMOVE + a destroy; a third "Hello" keybind row
  `bags`=Ctrl+B). Doc `phase-3b-model-handle.md`. **In-game verified ✅** (adopted the main inventory at login,
  Ctrl+B hid/showed the grid, and **`onItemAdded` fired on a ground pick-up while the grid was HIDDEN** — the
  D-009 headless-model claim confirmed live; a first run showed the initial-fill log burst masking the pick-up,
  fixed by the `bagsReady` gate — see §8). Deferred to 3c: re-finding an
  already-open window by descriptor (`hafen.ui.replace` — an `onWidgetCreate` observer won't re-fire for the
  existing inventory after a `:reload`, so re-adoption waits for a relog), hiding the wrapper window (the main
  inventory is an `Inventory` the engine wraps in a `Hidewnd`; `desc.id` is the `Inventory` → `:hide()` hides the
  grid, not the frame). Also deferred: item actions (Phase 4), an explicit `:remove()`.

- **Phase 3c ✅** — **`hafen.ui.replace` + the `bags` example — the Phase-3 DoD** (replace the native inventory
  with a custom view; disabling restores it). **`hafen.ui.replace(type, opts, fn(model))`** is spec 08's high-level
  sugar over 3a (observe) + 3b (adopt): it **finds** a server widget by descriptor, **adopts** the real widget as a
  hidden model, and calls **`fn(model)`** which draws a custom **view** (a `hafen.ui.window`) and **returns** it
  (bridge-owned). The target is found on **two paths**: the **creation** path (folded into 3a's `onWidgetPlaced`
  dispatch — catches a target opened *after* registration, e.g. the inventory streaming in at login) and, crucially,
  a one-time **scan** at registration for an **already-open** target — the **`:reload` gap 3b flagged** (a rebuilt
  addon layer gets no creation event for the existing inventory). The scan keys on the widget's **Java class**
  (`typeClass`: `inv`→`Inventory`, `epry`→`Equipory`, `chr`→`CharWnd`, `wnd`→`Window`) since the server type string
  isn't stored for a live widget; `context="main"` resolves to the unambiguous public **`GameUI.maininv`**. `opts` =
  **`context`** (`"main"`), **`caption`** (exact window title), **`match`** (a `desc`-predicate escape hatch). It
  **hides the WRAPPER window** (`nativeWindowOf` = nearest enclosing `Window` — the *"Inventory"* `Hidewnd` around
  `maininv`, the other 3b-deferred item), and **restores its ORIGINAL visibility** on teardown (`LuaModel.hideTarget`
  + `hideTargetOrigVisible`; a hidden-by-default wrapper goes back to hidden, not shown). A plain 3b `adopt` model
  still targets the widget itself → **3b behaviour unchanged**. **`:remove()` fully undoes** (restore native +
  destroy view); teardown (reload/disable) does the same automatically. **Item verbs stay gated Phase-4** → the view
  is **read-only** (a click logs the item). **Zero new `haven` edit** — reuses 3a's two `UI.java` one-liners (the
  replacer dispatch rides `onWidgetPlaced`; `onWidgetCreated` records the type when observers **or** replacers
  exist). New **`LuaReplacer.java`**; edits to `LuaModel` (hide-target + view fields), `AddonManager`
  (`replace`/`newReplacer`/`scanForReplace`/`matchOnCreate`/`matchCriteria`/`fireReplace`/`nativeWindowOf`/
  `typeClass`/`removeReplacer`/`undoReplace`/`teardownReplacers` + the shared `descTable` + `modelHandle`/
  `teardownModels`/`pollModels` on `hideTarget`), `Addon` (`replacers` list), `LuaWidgetObserver` (shared
  `descTable`, DRY). Compile OK + **36 headless checks** (`descTable` nil-omit; `matchOnCreate` type + `context=main`
  gating [container-inv rejected] + caption + `match` fn; scan `matchCriteria`; `nativeWindowOf`; `LuaReplacer.
  handled`; `LuaModel` hide/show/visible via `hideTarget` + `origVisible` capture for visible-grid AND
  hidden-default-wrapper) + LuaJ parse of `bags` under the sandbox. New dedicated **`bags`** addon (`addons/bags/`),
  **dormant** via a **Ctrl+Shift+I** toggle (so it never disturbs `hello`/the regression harness): press → the
  inventory is replaced by a custom "Bags" window drawing the real items at their grid cells (no icons yet —
  `g:image` deferred — so short name + count per cell; hover highlight; click logs the item); press again / disable /
  `:reload` → restored. Doc `phase-3c-replace-bags.md`. **In-game verified ✅** (Ctrl+Shift+I replaced the open
  inventory with the custom view — the scan path; toggle-off / X-close / disable+`:reload` all restored the stock
  inventory; `hello` regression intact). Committed. **Completes Phase 3.** Deferred: item verbs (Phase 4),
  `g:image` icons, intercepting the client `Tab`/menu toggle, live-grid sizing (`Inventory.isz`), the
  factory-override seam A (`Widget.types`).

- **A1 ✅ (gap subsystem — map markers)** — **`hafen.markers`** over the client-side on-disk map DB (`MapFile`,
  owned by `MapWnd`/`MiniMap`): **`list([filter])`/`nearest([filter])`** (marker **snapshots** `{id,name,
  type("player"|"system"),seg(id string),tc={x,y}, color+onmap|icon, x,y,dist}`), **`add(name,x,y[,opts{color,
  onmap}])`** (create a persistent **PMarker** at a **WORLD** position), **`remove(ref)`**, and **`MarkersChanged`**
  (poll `MapFile.markerseq` — a marker add/remove is not a uimsg; primed on first sight, fired on genuine changes).
  **Coordinate model (C4):** a marker's **persistent anchor is seg+tc** (segment id + segment tile coord — survives
  a relog); the snapshot's **x,y (world tile-centre) + dist are session-local**, present only when the marker shares
  the player's segment. The **world↔segment bridge** is the corner minimap's live **`sessloc`** (`MiniMap.Location`
  = segment + segment-tile-coord of session origin): `add` does world→seg = `sessloc.tc + floor(world/tilesz)`
  (mirrors `MapWnd.FindMark.hit`), the snapshot does seg→world = `(tc − sessloc.tc)*tilesz + tilesz/2`; both floor
  (negatives correct). **Threading:** reads **copy `MapFile.markers` under `file.lock.readLock()`** then snapshot +
  filter **outside** the lock (markers mutate on loader threads — server `markobj` SMarkers, segment merges — the
  OCache discipline); the marker-ref map (facade-safe `long` ids, P1) is `synchronized` (UI + REPL threads).
  **Zero `haven` edit** — every backing is public (`GameUI.mapfile`/`mmap`, `MapWnd.file`/`MiniMap.file`,
  `MiniMap.sessloc`, `MapFile.markers`/`markerseq`/`lock`/`add`/`remove`, `Marker`/`PMarker`/`SMarker` fields,
  `Location.seg`/`tc`, `Segment.id`); only `AddonManager.java` changed (facade + helpers `mapfile`/`sessloc`/
  `markerSnapshot(s)`/`addMarker`/`removeMarker`/`markerId`/`markerByRef`/`pollMarkers` + tick + session reset).
  `sessloc`/the DB **stream in a beat after enter-world** (read on a timer, like the map/char/vitals). Compile OK +
  **64 headless checks** (world↔segment round-trip incl. negatives + non-zero origin; marker-ref assign/resolve/
  session-reset/stale; `luaColor`/`clampByte`) + LuaJ parse. `hello` **v0.22.0** (Ctrl+Shift+M drops/removes a
  "Hello marker" at the player — a fourth "Hello" keybind row; reads markers at now/+3s; logs `MarkersChanged`;
  OnDisable removes the demo marker so the harness never pollutes the persistent map). Doc `a1-markers.md`.
  **In-game verified ✅. Committed `72d42277`.** Deferred: SMarker/icon add (server-owned oid), marker edit (`MapFile.update`), a
  per-marker grid-anchor field (derive via `hafen.map.gridPos(m.x,m.y)`), `nearest` across segments, map overhaul (B3).

- **A4 ✅ (gap subsystem — completes study/skills)** — the **rest of the "Lore & Skills" window** (`SkillWnd`)
  beyond the headline A4 trackers that already shipped in Phase 1d (study slots + `StudyChanged` 1d-3, FEP/food +
  `FepChanged` 1d-2, **known** skills 1d-3). Three new **read-only** `hafen.char` surfaces: **`skillsAvailable()`**
  (buyable skills `{name,res,cost}` from `skg.nsk` — the sibling of the known `skg.csk`; `cost` = LP price),
  **`credos()`** (the Credos tab as one composite `{acquired, available` (each `{name,res}`)`, pursuing={name,res,
  level,levelTotal,quest,questTotal,questId}` or absent`, cost}` from `SkillWnd.credos` — mirrors the `food()`
  composite pattern; nil until the window is up), and **`experiences()`** (the Lore tab `{name,res,score,mtime}`
  from `exps.seen`; `mtime` = the raw server time field, passthrough). **No `*Changed` event** — buyable skills,
  credos and lore change only on explicit, infrequent player actions (buy / pursue / quest progress), not per-frame
  or via cheaply-pollable uimsgs, so (like the deferred `SkillsChanged`) an addon reads them on demand. **Zero
  `haven` edit** — every backing is public (`SkillWnd.skg.nsk`, `SkillWnd.credos` = `CredoGrid.ccr`/`ncr`/`pcr`/
  `pcl…pqid`/`cost`, `SkillWnd.exps.seen`, `Skill.nm/res/cost`, `Credo.nm/res`, `Experience.res/score/mtime`); only
  `AddonManager.java` changed (the three facades + helpers `readAvailableSkills`/`credoSnapshot`/`readCredoList`/
  `readCredos`/`experienceSnapshot`/`readExperiences`, plus the **generic `resTipName`/`resIdent`** resource-name
  helpers extracted from `skillName`/`skillRes` — now delegating, DRY across skill/credo/experience). Reads run on
  the UI thread and copy each off-thread-swapped `Group.items`/`ccr`/`ncr` (`new ArrayList<>`) before iterating;
  names Loading-guarded (nil while resolving). Compile OK + **5 headless guard checks** (`resTipName` returns the
  fallback / `resIdent` returns null on a Loading or null `Indir<Resource>`) + LuaJ parse. `hello` **v0.23.0** (a
  `readLore(tag)` helper logging the three surfaces at now/+3s, like the streaming char reads). Doc
  `a4-skills-credos-lore.md`. **In-game verified ✅. Committed `df6705b2`.** Deferred: a credo-progress event (poll-driven, if wanted),
  and the actions (skill `buy` / credo `crpursue` → Phase-4 gated tier).

- **A2 ✅** — **`hafen.radar`** (radar / minimap icon categories). `categories([filter])` reads the per-character
  gob-icon registry (`GobIcon.Settings` / `GameUI.iconconf` — **the same registry the in-client "Icon settings"
  window edits**) as snapshots `{name (the icon tooltip, falling back to res), res (the resource name = stable id),
  show (drawn on the minimap), notify (sound + msg on spawn)}`; `setVisible(filter,on)` / `setNotify(filter,on)`
  flip the **show** / **notify** flag on **every category the filter matches** and **persist** it (`Settings.dsave()`,
  the debounced write the settings-window checkboxes use), returning the **number matched**. The **filter is the one
  canonical form** used across the API (nil = all, string = `name` substring, function = predicate over the snapshot —
  use a predicate to match on `res`) — reusing the shared `matches` helper. **Read-only, no `*Changed` event** (the
  category set only grows as new icon types are seen — rare; A4 precedent). **Zero `haven` edit** — every backing is
  public (`GameUI.iconconf`, `Settings.settings` [swapped wholesale by the icon loader → a local ref is a stable
  snapshot] / `dsave`, `Setting.id.res` / `show` / `notify` / `icon.name()`); only `AddonManager.java` changed (facade
  + helpers `iconconf`/`radarSnapshots`/`radarSnapshot`/`radarName`/`radarSet` + the **testable core `radarSetIn`**
  that operates on a given `Settings` so it runs headlessly). Reads/writes run on the **UI thread** — the exact thread
  + race model the settings-window checkboxes already live with (atomic boolean writes). Compile OK + **21 headless
  checks** (nil/string/function filter match-counts, show-vs-notify routing, snapshot shape + `radarName` res-fallback
  when the icon/tooltip is absent, throwing-predicate isolation, null/empty-registry safety — exercised via a
  `Settings` subclass with a **no-op `save()`** so the test writes nothing to disk; + 5 `clampMsg` boundary checks
  below) + LuaJ parse of the harness under `Sandbox.create()`. `hello` **v0.24.0** (a **read-only** `readRadar(tag)`
  logging the category count / #shown / #notify / first at now/+3s — the setters persist to the user's REAL icon
  config, so the regression harness never mutates them; the mutation surface is a documented `:lua` DoD step + the
  headless test). Doc `a2-radar.md`. **Read verified in-game ✅** — `:lua hafen.radar.categories()` returned the full
  ~400-entry registry with correct `name`/`res`/`show`/`notify`. **That first run also surfaced (+fixed) a crash: the
  `:lua` REPL mirrors its result to the in-game notice (`UI.msg`), which renders a line as ONE text texture; a
  ~400-entry registry is a ~40 KB SINGLE-LINE compact-JSON dump (no spaces → no break points) → the texture width
  exceeded `GL_MAX_TEXTURE_SIZE` → `GL_INVALID_VALUE (1281)` on the render thread.** The radar read is correct (the
  full result printed to the terminal fine — radar is just the first read big enough to trip a PRE-EXISTING REPL
  limit). Fixed at the choke point: a `clampMsg` helper bounds anything handed to the in-game notice sink to
  `NOTICE_MAX` (500) chars (`... (N chars; full output on the terminal)` tail), applied to ALL THREE in-game output
  paths (REPL result + REPL error + both `hafen.log` variants); the terminal keeps the full text and addons get the
  real Lua value, so nothing is lost. **In-game verified ✅ (read + mutation) — no more crash. Committed `8e40c8b1`.**
  Deferred: per-category **permanent-marker** + **notification-sound** picker + the global "notify on newly-seen
  icons" flag, **addon-registered custom icons**, a `RadarChanged` event.

- **A11 ✅** — **`hafen.slash` (console / slash commands).** `hafen.slash.register(name, fn)` → handle
  `{ :remove() }` routes the console command **`:name args…`** to `fn(args)`, where `args` = a **1-based table of
  the whitespace-split words after the name** (name excluded; `"quoted words"` group / `\` escapes via
  `Utils.splitwords`). The WoW `SlashCmdList` pattern over Haven's `Console`. **Reload-safe by construction — the
  audit's C1 fix:** `Console.setscmd` has NO unregister, so per-reload re-registration would leak/duplicate
  commands; instead the bridge installs a **SINGLE engine-lifetime dispatcher per name** that forever routes to
  `slashHandlers.get(name)` (the CURRENT live handler) and **never touches `Console` again** — reload/disable only
  **swaps/drops** the handler (`slashDispatched` grows only, deliberately NOT reset per session, unlike the
  session-scoped hook maps); a dropped name replies `no addon currently handles :name`. Last registration wins
  (cross-addon takeover logs a reassignment + is **identity-safe** on teardown — one addon's teardown can't steal a
  name another took over). **Refused:** reserved engine names (`lua`/`addons`/`reload`), an already-existing client
  command, and whitespace/empty/non-function names (clear Lua errors). Dispatch runs on the **UI thread** (in-game
  `:` console = input handling, like tick/draw → never races other Lua; matches the `:lua` REPL) through `callLua`
  (watchdog + isolation + CPU accounting). **Zero `haven` edit** — reuses public `Console.setscmd`/`findcmd`. New
  **`io.brodgar.addon.LuaSlashCommand`** + `Addon.slashCommands` (owned list, P2) + `AddonManager` (facade +
  `slashHandlers`/`slashDispatched` registries + `newSlashCommand`/`dispatchSlash`/`removeSlashCommand`/
  `teardownSlashCommands`, wired into `teardown`). Compile OK + **41 headless checks** (`invoke` args marshalling;
  register→dispatch→remove→teardown; the one-dispatcher reload round-trip [E: teardown drops the handler but keeps
  the dispatcher, re-register reuses it and routes to the fresh handler]; cross-addon takeover; the four refusal
  paths) + LuaJ parse of `hello` under `Sandbox.create()`. `hello` **v0.25.0** (a `:hello` command with
  `toggle`/`ping`/`echo` sub-commands, registered in the file body; also **fixed the stale `hello loaded` version
  line** — was `v0.23.0` while the manifest was `v0.24.0`). Doc `a11-slash-commands.md`. **In-game verified ✅.
  Committed `e8065754`.**
  Deferred: the raw-remainder arg (`cons.rawcmd()`/`stripCmd`), tab-completion/help integration, `:reload <id>`.

- **A6 ✅** — **`hafen.kin` (kin/buddy roster read).** `hafen.kin.list([filter])` reads the Kin window
  (`GameUI.buddies`, a `BuddyWnd`) as snapshots **`{id, name, group (0..7), color={r,g,b,a}, online(bool)}`** in
  the window's current sort order, over the **canonical filter** (nil=all / name-substring / predicate);
  `hafen.kin.find(nameOrId)` returns one entry (a **number** matches by id via `BuddyWnd.find`, a **string** by
  **exact case-insensitive** name). **`KinChanged`** fires with the **new list** when the roster changes.
  **Mechanism:** every roster change is a targeted `uimsg` to the `BuddyWnd` (`add`/`rm`/`upd`/`chst`), so
  (unlike buffs/study, whose add/remove is a widget create → polled) it's a **uimsg-driven `KinAdapter`** riding
  the 1d-1 inbound-`uimsg` tap — `interested` flags those four msgs, the tick's `refresh` re-reads + diffs the
  snapshot list and fires only on a real change (**zero work when idle**). Change-detection is a **snapshot diff,
  NOT `BuddyWnd.serial`** — `serial` bumps on add/rm/upd but **not `chst`** (the online/offline flip a kin-alert
  addon most wants). `online` is exposed as a **boolean** (`Buddy.online==1`; the internal `-1`
  hearth-secret-only vs `0` offline tri-state and `Buddy.seen`/`notes` are deferred — one canonical way).
  **Zero `haven` edit** — all backings public (`GameUI.buddies`, `BuddyWnd.iterator()` [copies under the
  widget's lock] / `find(int)`, `Buddy.id`/`name`/`online`/`group`, `BuddyWnd.gc` palette); only
  `AddonManager.java` changed (+ one import `haven.BuddyWnd`). Compile OK + **14 headless `kinListEqual`
  change-detection checks** (identical / online-flip / group / name / id / add / remove / reorder / count / empty
  / nil edges) + LuaJ parse of `hello` under `Sandbox.create()`. `hello` **v0.26.0** (`readKin` at now/+3s +
  a `KinChanged` handler that names who just came online / went offline, the kin-alert pattern). Doc `a6-kin.md`.
  **In-game verified ✅. Committed `930cdf31`.** Deferred:
  add/remove/rename (gated Phase 4), the `online` tri-state / `seen`, a granular `KinOnline`/`KinOffline` event.

- **A7 ✅** — **`hafen.speed` (movement speed, read).** `hafen.speed.get()` → the current speed as **0..3**
  (0=crawl 1=walk 2=run 3=sprint), `hafen.speed.max()` → the highest currently-**selectable** speed (speeds
  0..max are enabled), `hafen.speed.name([n])` → a speed's **display name** (default = current; from the
  widget's own resource tooltips). All read live off the **`Speedget`** selector — the crawl/walk/run/sprint
  toggle the server places under the HUD. It has **no named `GameUI` field**, so it's located with the **1d-1
  Locator** (`gui().children(Speedget.class)`, the vitals-style recursive subtree walk); `Speedget.cur`/`max`
  are **public ints** → **zero `haven` edit** (like A6/A4/A2 — no `AddonWidgets` accessor needed, unlike
  vitals/buffs B5). **Read-only, no `SpeedChanged` event** — faithful to the api-reference (lists only
  get/set) and the read-only A2/A4 precedent; `hafen.speed.set` (change speed) is the **gated Phase-4 action
  tier** (`Speedget` sends `wdgmsg("set", n)`; the classic use is a speed-toggle keybind reading `get()` then,
  Phase 4, setting the next speed). The `"cur"`/`"max"` uimsgs do flow through the 1d-1 tap, so a `SpeedChanged`
  is a trivial future add. Only `AddonManager.java` changed (the `get`/`max`/`name` facade + helpers
  `speedget()` [Locator] / `speedName(int)` [tooltip lookup, bounds-checked] + one import `haven.Speedget`).
  Compile OK + **8 headless checks** (locator returns null with no HUD — no NPE; the `hafen.speed` table +
  get/max/name installed; each returns nil with no HUD) + LuaJ parse of `hello` under `Sandbox.create()`.
  (`speedName`'s in-range value reads the widget's resource tooltips → verified **in-game**; headless has no
  resource loader — `dolda/jglob/Loader` absent.) `hello` **v0.27.0** (`readSpeed` logs get/name/max at
  now/+3s; the load-line version string was still `v0.25.0` → resynced to v0.27.0). Doc `a7-speed.md`.
  **In-game verified ✅. Committed `e31f8787`.** Deferred: `speed.set` (Phase 4), a `SpeedChanged` event.

- **A8 ✅** — **`hafen.craft` (crafting read).** `hafen.craft.current()` → the **OPEN** recipe/craft window as
  `{recipe, inputs, outputs, qmod, tools}`, or **nil** when none is up. **inputs/outputs** are `{res, name,
  num, opt}` specs — `res`/`name` = the **displayed** resource's stable id / tooltip (the **constraint**
  category when the recipe accepts one, else the concrete item — mirrors `Makewindow.Spec.display()`), `num`
  = the required/produced count (**-1 = unspecified ≈ 1**, exposed faithfully), `opt` = an **optional**
  ingredient / chance byproduct (`Makewindow.Optional`, Loading-guarded → false). **qmod** (quality-affecting
  inputs) and **tools** (required tools) are `{res, name}` arrays. Backing **`Makewindow`** (`@RName("make")`),
  which has no named `GameUI` field (it's wrapped in the **private** `GameUI.makewnd`), so it's located with
  the **1d-1 Locator** (`gui().children(Makewindow.class)`, the vitals/A7-style recursive subtree walk).
  **Read-only, no `CraftChanged` event** — faithful to the api-reference (lists only current/make) and the
  read-only A2/A7 precedent; a recipe changes only when the player **opens** one (observe that via the 3a
  `hafen.ui.onWidgetCreate`, `place="craft"`); `hafen.craft.make([all])` (actually craft) is the **gated
  Phase-4 action tier** (`wdgmsg("make", 0|1)`). **Threading:** `inputs`/`outputs`/`qmod` are List references
  the `inpop`/`opop`/`qmod` uimsgs swap **wholesale** off the UI thread, and `tools` is mutated **in place**
  (`tools.add` on the `tool` uimsg) — so `readCraft` copies all four under `synchronized(ui)`, then snapshots
  **outside** the lock (resource `res.get()` may Loading), the marker "copy under the lock, snapshot outside"
  discipline. **Zero `haven` edit** — every backing is public (`Makewindow.rcpnm`/`inputs`/`outputs`/`qmod`/
  `tools`, `SpecWidget.spec`, `Spec.item`/`constraint`/`num`/`opt()`, `ResData.res`), reusing A4's
  `resIdent`/`resTipName`; only `AddonManager.java` changed (facade + `makewindow()` [Locator] + `readCraft`/
  `craftSpecs`/`craftSpec`/`craftReses`/`craftRes` + one import `haven.Makewindow`). Compile OK + **11 headless
  checks** (locator + `readCraft` return null/nil with no HUD; `craftRes` populated happy-path [name falls back
  to id with no tooltip layer] + Loading-omitted; `craftReses` 1-based + count + empty; `craftSpecs` empty —
  the live-`Spec` `craftSpec` shape test is a documented **headless resource skip** like 3a: instantiating
  `Makewindow` runs its `<clinit>`→`Text.render`→the `ui/fraktur` font, absent headless) + LuaJ parse of
  `hello` under `Sandbox.create()`. `hello` **v0.28.0** (`readCraft` at now/+3s logs "none open" — no recipe
  is open at login; a new **`:hello craft`** sub-command dumps the open recipe's inputs/outputs/qmod/tools).
  Doc `a8-craft.md`. **In-game verified ✅. Committed `fbbd564d`.** Deferred: input **fill-state**
  (`Input.using` vs `num`), per-item **quality**, a `constraint`/`item` split, a `CraftChanged` event.

- **A9-1 ✅** — **`hafen.quests` (quest log read).** `hafen.quests.list([filter])` → quest snapshots `{id,
  name (the quest title = `Quest.title()`), res (stable id), status ("pending"/"done"/"failed"/"disabled"),
  mtime}` for **BOTH** the Current (active: pending/disabled) and Completed (done/failed) tabs — the canonical
  nil/substring/predicate filter (so "only active" is a status predicate; the string form matches `name`, the
  shared snapshot key). `hafen.quests.selected()` → the quest currently **OPEN** in the log — the **only** one
  whose conditions the client loads — as a `list` snapshot **plus** `conds={{desc, status ("pending"/"done"/
  "failed"; no "disabled" for conds), text?}}`, or **nil** when nothing is selected (a faithful limitation, like
  A8's "the open recipe"). Backing **`QuestWnd`** (`@RName("quests")`, the character sheet's **Quest Log** tab)
  reached via the **public `CharWnd.quest`** field (no tree-walk, like FEP's `CharWnd.battr`; created hidden at
  login but live). Events **`QuestAdded`** (a new **active** quest appears; the completed **history** streaming
  in at login is recorded **silently** — no event) / **`QuestDone`** (a previously-active quest → **finished**,
  mirroring `QuestWnd`'s own completion trigger; `status` distinguishes done vs failed → one event) via a
  **uimsg-driven `QuestAdapter`** over the `"quests"` uimsg (like A6 kin) + a **pure static `questDiff(cache,
  fresh)`** (id→status maps in, `{event,id}` pairs out — no widget/Lua access, so the add/complete semantics are
  headless-testable). **Threading:** the quest lists + the selected box's `cond[]` are mutated off the UI thread
  (`QuestWnd.uimsg`/`Box.uimsg` under `synchronized(ui)`), so copy the list/array refs under the `ui` monitor,
  snapshot outside (names may Loading) — the A1/A8 discipline. **Zero `haven` edit** — every backing is public
  (`CharWnd.quest`, `QuestWnd.cqst`/`dqst`/`quest`, `QuestList.quests`/`get`, `Quest.id`/`res`/`title`/`done`/
  `mtime`, `Quest.Box.id`/`cond`, `Condition.desc`/`done`/`status`); the status ints (`QST_PEND`/`DONE`/`FAIL`/
  `DISABLED`) are `public static final` **constants → inlined**, so the status helpers never load `Quest`
  (whose `<clinit>` renders text, absent headless — the A8 skip reason, here **avoided**). Only
  `AddonManager.java` changed (facade + `QuestAdapter` + `questDiff` + `questwnd`/`questList`/`questSelected`/
  `questSnapshot`/`questConds`/`questCond`/`questActive`/`questStatus`/`questCondStatus` + one import
  `haven.QuestWnd`; reuses `matches`/`resIdent`/`resTipName`). Compile OK + **26 headless checks** (status/cond/
  active mapping incl. unknown fallback; the full `questDiff` decision matrix — new-active→Added, new-completed→
  silent, active→finished→Done, pending→disabled→none, removed→pruned, insertion order, disabled/failed
  transitions, reopen→none, streaming add-then-done, completed-stay-silent) + LuaJ parse of `hello` under
  `Sandbox.create()`. `hello` **v0.29.0** (`readQuests` at now/+3s, `QuestAdded`/`QuestDone` logs, a `:hello
  quest` sub-command dumping the selected quest's objectives). Doc `a9-1-quests.md`. **In-game verified ✅.
  Committed `db105520`.** Deferred: `QuestRemoved` / per-condition-progress event; instant-complete & reopen
  edges (no event, intentional); A9-2 wounds is next.

- **A9-2 ✅** — **`hafen.wounds` (wounds read).** Completes **A9**. `hafen.wounds.list([filter])` → wound
  snapshots `{id, name, res, severity, parentid, level}` — the canonical nil/substring/predicate filter (the
  string form matches `name`). Wounds are a **TREE**: `parentid` = the parent wound's id (**-1 = root**, e.g. an
  *Infection* nested under a *Swelling*), `level` = the client's `treesort` depth (indent). `severity` = the
  magnitude the client shows beside the wound — its highest-`qprio` **`WoundWnd.QuickInfo.qstr()`** (a
  content-defined string, usually a number, **NOT seconds**; nil while the wound's `ItemInfo` Loads, streams in a
  beat after the row). `name` = the resource tooltip, else the `ItemInfo.Name`. Also **`hafen.wounds.has(needle)`**
  (name/res substring → bool, the ergonomic presence test, mirroring `buffs.has`; wounds & buffs are both status
  items). Backing **`WoundWnd`** (`@RName("wounds")`, the character sheet's **Health & Wounds** tab) reached via
  the **public `CharWnd.wound`** field (no tree-walk, like A9-1's `CharWnd.quest`; hidden-at-login but live). Event
  **`WoundChanged`** (the wound analog of `KinChanged` — **one** event, payload = the new list) via a
  **poll-driven `WoundAdapter`** (like 1d-3 study — a wound add/heal IS a `"wounds"` uimsg, but its **severity**
  streams in a beat after the wound row, so a uimsg refresh would fire with `severity` nil and never re-fire; the
  per-tick poll catches the resolve too) + a **pure `woundListEqual`** snapshot diff (length + per-entry
  id/parentid/level/name/res/severity — `severity` in the key, so a wound **worsening** fires it; the whole
  change-detection is headless-testable). **Threading:** the wound list is mutated off the UI thread
  (`WoundWnd.uimsg("wounds")`→`decwound` under `synchronized(ui)`) and reassigned by `WoundList.tick`'s
  `treesort` on the UI thread, so `copyWounds()` copies the list ref under the `ui` monitor and snapshots outside
  (names/severity may Loading) — the A1/A8/A9-1 discipline. **Zero `haven` edit** — every backing is public
  (`CharWnd.wound`, `WoundWnd.wounds`, `WoundList.wounds`, `Wound.id`/`parentid`/`res`/`level`/`info()`,
  `WoundWnd.QuickInfo.qstr`/`qprio`, `ItemInfo.Name`). Only `AddonManager.java` changed (facade + `WoundAdapter`
  + `woundListEqual` + `woundwnd`/`copyWounds`/`woundList`/`woundSnapshot`/`woundName`/`woundSeverity` + one
  import `haven.WoundWnd`; reuses `matches`/`resIdent`/`resTipName`/`luaFieldEq`). Compile OK + **23 headless
  checks** (`woundListEqual`: severity/name/res/id/parentid/level change; add/remove/reorder; nil-field edges —
  severity/name still Loading; non-table & nil edges; locator/list null-safety with no session) + LuaJ parse of
  `hello` under `Sandbox.create()`. `hello` **v0.30.0** (`readWounds` at now/+3s, a `WoundChanged` subscription,
  a `:hello wound` sub-command dumping the wound tree indented by `level`). Doc `a9-2-wounds.md`. **In-game
  verified ✅. Committed `3258694e`.** Deferred: `selected()` (no selection-gated detail, unlike quests — a wound
  carries full `info()` for every entry); a `WoundAdded`/`WoundHealed` split; wound pagina text + icon; an
  absolute healing timer (client has none).

- **A10 ✅** — **`hafen.fight` (combat schools / deck read).** The OUT-OF-COMBAT maneuver-deck builder
  (`FightWnd`, `@RName("fmg")`, the char sheet's "Martial Arts & Combat Schools" tab via the public
  **`CharWnd.fight`** — distinct from the in-combat `hafen.combat.*` view). Three reads: **`maneuvers([filter])`**
  → every known maneuver/attack `{res, name, avail (`Action.a`), used (`Action.u`)}` (canonical filter);
  **`deck()`** → the current school's card LAYOUT `{slot (raw 0-based), key ("1".."5"/"⇧1".."⇧5" from
  `FightWnd.keys`), res, name, used}` (filled `order[]` slots, empties omitted; `slot` = the index a future gated
  `fight.use` takes, one canonical way like 1d-4's actionbar index); **`summary()`** → `{maxact, used (=Σ
  Action.u, mirrors the window's "Used: u/maxact"), nact (=order.length), nsave, usesave (0-based active school)}`
  or nil before the tab exists. **Read-only, no `FightChanged`** — a school changes only on explicit player
  action (like A4 skills / A8 craft → read on demand; observe the window open via 3a `onWidgetCreate`
  `type="fmg"`). **Zero `haven` edit** — all backings public (`CharWnd.fight`, `FightWnd.acts`/`order`/`keys`/
  `maxact`/`usesave`/`nsave`, `Action.res`/`a`/`u`); only `AddonManager.java` changed (facade + `fightwnd`/
  `fightManeuvers`/`maneuverSnapshot`/`fightDeck`/`deckKey`/`fightSummary`, reusing the shared `matches` filter +
  `resTipName`/`resIdent`). **Threading:** `FightWnd.uimsg` mutates off-thread under `synchronized(ui)` (`"avail"`
  replaces `acts` wholesale, `"used"`/`"max"` mutate `act.u`/`maxact`/`order[]`), so copy the acts list / order[]
  array + scalars under the `ui` monitor, resolve names outside (the marker discipline). Compile OK + **4 headless
  checks** (locator + the 3 facade helpers null-safe with no session; `deckKey`/`FightWnd.keys` = a **headless
  resource skip** — `FightWnd.<clinit>` loads `/res/ui/fraktur.res`, absent headless, exactly like A8's craft-spec
  test → verified in-game + by source, the key table is a literal) + LuaJ parse. `hello` **v0.31.0** (`readFight`
  now/+3s; `:hello fight` dumps the deck by hotkey + known maneuvers). Doc `a10-fight.md`. **In-game verification
  pending. This completes the A-series read subsystems** (A1–A11 all read now). Deferred: saved-school NAMES
  (private `FightWnd.saves[]` → a one-line `AddonWidgets` accessor; `usesave`/`nsave` identify the active slot by
  index), a `FightChanged` diff-event, per-maneuver pagina/icon, edit/switch verbs (Phase-4 gated:
  `fight.use`/`setCount`/`loadSchool`).

- **Phase 4a ✅** — **Write-actions PERMISSION (D-027) + `hafen.act.moveTo`.** The FIRST gated slice — the one
  surface that **drives** the character (sends player-action `wdgmsg`s), behind a **two-part permission model**
  (like app permissions), per D-010/D-025/**D-027** (write-actions act on your behalf, so they need explicit
  consent; server-authoritative, so not a client exploit). A verb is granted only when **BOTH**: (1) the **global
  master switch** is ON —
  `actionsEnabled()` = the `haven-config.properties` flag `addons.actions.enabled` (false; config/`-D` enables it,
  restart to apply — the persisted, panel-toggled pref that lets it flip at runtime is slice 4b; config-ONLY here
  so a stray pref can't strand it ON with no toggle UI); (2) the calling **addon DECLARED**
  `"permissions": ["actions"]` in its manifest. `requireActions(owner,
  verb)` throws a **distinct** `LuaError` per failure (didn't-declare vs. master-off); `actionsGranted(owner)` =
  both halves. **The `hafen.act` namespace** (always present, verbs gated): **`enabled()`** = is THIS addon
  granted now (never throws → feature-detect) + **`moveTo(x,y)`** — walk to a WORLD coord (the `hafen.gob.pos`
  space) via `MapView.wdgmsg("click", ui.mc, Coord2d(x,y).floor(posres), 1, 0)`: the screen `pc` is a **dummy**
  (current mouse), the exact `MiniMap.mvclick` pattern (MiniMap.java:1218), so an **off-screen destination is
  fine**; button 1=walk, mods 0. Manifest gained a **`permissions`** array (`Manifest.usesActions()`); the REPL
  owner declares it (trusted operator, still master-gated). The provisional `:addons actions` console command was
  **removed** (control moves to the panel — 4b). **Zero `haven` edit** — pure engine (`AddonManager.java` +
  `Manifest.java`); all backings public. Compile OK + **24 headless checks** (5 `moveClickCoord` math incl.
  negative flooring; 3 master-switch config-flag flip incl. default-OFF; 2 `usesActions` decl parse; 4
  `actionsGranted` (null/declaring×master/non-declaring); 3 `requireActions` distinct errors; 7 facade end-to-end
  in the REAL env — console owner declares → `enabled()` tracks master, `moveTo` throws "OFF"/off & "no map
  view"/granted; a non-declaring env → "did not declare" even master-ON) + LuaJ parse.
  `hello` **v0.32.0** (declares `"permissions":["actions"]`; `readActions` reads the grant; **`:hello walk`** = a
  deliberate ~2-tile move — no-ops with a hint while not granted). Doc `phase-4a-actions-gate-moveto.md`.
  **In-game verified ✅. Committed `d40378c0`.** (In-game finding: the master switch is config-ONLY for 4a — a
  first cut read a persisted pref, but the removed `:addons actions` test had left `addons/actions=true` stranded
  with no toggle UI; §8.) Deferred: the panel master checkbox + default-disabled for write addons (4b), the
  enable-time warning dialog (4c), the rest of `hafen.act` + folded-in `speed.set`/`craft.make`/`actionbar.use`
  (A3)/`kin.*` verbs (4d+).

- **Phase 4b ✅** — **AddOns-panel master switch + default-disabled for write addons (D-027).** The runtime USER
  control for the 4a write tier, plus its two enabled-set consequences. **(1)** The **master switch is now a
  persisted, panel-toggled pref**: `actionsEnabled()` = `Utils.getprefb("addons/actions.enabled", CFG_ACTIONS)`
  (the config flag is the default; the pref overrides — safe to honor now that a toggle UI exists; a **fresh key**
  so a 4a-era stray `addons/actions` pref can't strand it); `setActionsEnabled(on)` persists + flags
  `reloadNeeded` (apply on reload). The **AddOns panel** gained an **"Allow addon actions (writes)"** checkbox
  (voice-checkbox clone) with a notice tooltip + an `[actions]` row marker (new `AddonInfo.declaresActions`).
  **(2)** **Default-disabled for write addons** (D-027's narrowing of D-006): `scanAddonDefaults()` (run in
  `loadAll` + `describeAddons`) applies the pure `applyActionsDefaults(seen, disabled, declares)` — a write addon
  NOT in the persisted **seen set** (`addons/actions.seen`) is added to **both** the disabled set and the seen set
  (default-disabled exactly ONCE; a seen addon is left to the user's choice; read addons ignored; additions-only).
  **(3)** **Master OFF ⇒ write addons don't load**: `loadAll` skips a `usesActions()` addon while the switch is
  off (`liveStatus` → `blocked: actions off`; the read+write addon loses its reads too — simplicity/safety).
  **Because a write addon can't load with the switch off (the DEFAULT), the always-on harness can't BE a write
  addon** → **`hello` is now READ-ONLY** (dropped `permissions`, removed `readActions`/`walkDemo`/`:hello walk`;
  always loads regardless of the switch; **v0.33.0**), and the write demo moved to a **new dormant, opt-in
  `walker` addon** (declares `"actions"` → default-disabled; `:walker` = `moveTo` ~2 tiles south; only loads with
  the switch on, so `hafen.act.enabled()` is always true there; **v0.1.0**). **No grandfathering needed** — once
  `hello` is read-only, no pre-existing addon declares actions, so the new `walker` is the only default-disable.
  **Zero `haven` edit** — `AddonManager.java` + the `ui.AddonPanel` only. Compile OK + **12 headless checks**
  (`applyActionsDefaults`: read-ignored / new→disabled+seen / mixed / user-enabled-NOT-re-disabled / seen-disabled
  unchanged / `writeIds`=all / additions-only; master switch: default-OFF from config, set round-trip,
  `reloadNeeded`, idempotency) + LuaJ parse of `hello`/`walker`. Doc `phase-4b-actions-panel-default-disabled.md`.
  **In-game verified ✅** (panel checkbox + notice; `walker` unchecked-by-default → enabled + switch-on + Reload UI
  → `:walker` walked; switch-off + reload → `walker` not loaded / `blocked: actions off`; `hello` loaded
  throughout). **Committed `9be7c13d`.** Deferred: enable-time warning dialog (4c), the action verbs (4d+).
  **⚠️ The master switch shipped here was later REMOVED by D-028 (slice 4c) — write-actions became a per-addon
  permission with no global switch. Still current from 4b: the default-disabled policy + the `[actions]` marker.**

- **Phase 4c ✅ (+ D-028) — Enable-time write-actions consent dialog, and the permission is now PER-ADDON ONLY.**
  Two coupled changes. **(A) 4c — the consent dialog:** when the user **enables a write-declaring addon** in the
  AddOns panel, a titled **consent dialog** appears FIRST ("'X' wants permission to act on your behalf … move your
  character, use items, interact with the world … enable only if you trust it — you are granting the permission to
  this addon alone"), and the addon is enabled only on confirm. New **`io.brodgar.addon.ui.ActionsConsentWnd`** — a
  `Window` of three wrapped `Label`s + **Enable**/**Cancel**, `pack()`ed, pure public-`haven`; **Enable** runs
  `destroy(); onConfirm.run()`, **Cancel**/✕ just `destroy()` (server-less `reqclose`→`destroy`, the 2a
  client-window handling; destroying from the button's own action is safe — `Button.mouseup` releases the grab
  before `click()`). In **`AddonPanel`**: the Row checkbox's `set(v)` branches on **`v && ai.declaresActions`** →
  `confirmEnableActions(id,name)` and **leaves the box unticked** until confirm (`setEnabled(id,true)` +
  `rebuild()`); disabling + read addons fall straight through. The dialog is a **top-level floating window**
  (`ui.root` child, centered + `raise()`d → drags freely like any window, not clipped in the panel); the panel's
  `tick()` closes it once the panel is `!tvisible()` (Back / Options hidden) — reliable because tick recurses
  regardless of visibility and `OptWnd` is only hidden, never destroyed. One-at-a-time guarded. **`enableAll` skips
  write addons** so bulk-enable can't bypass the gate. **(B) D-028 — drop the global
  master switch** (maintainer, 2026-07-25): "las actions están habilitadas siempre, pero hay que darle permisos
  individualmente a cada addon". Write-actions became a **PER-ADDON permission** — the action tier is always
  available at the system level; the user's control is entirely per-addon (declare `"actions"` + **enable with the
  4c consent** = grant; disable = revoke). **Removed** `actionsEnabled()`/`setActionsEnabled()`, the
  `addons.actions.enabled` config flag + `addons/actions.enabled` pref, `writeAddonIds`, the panel's "Allow addon
  actions (writes)" checkbox, `loadAll`'s master-switch load gate, and the `blocked: actions off` status.
  `actionsGranted`/`requireActions` are now **declaration-only**; a write addon **loads as soon as it's enabled**.
  **Kept:** the default-disabled policy (`scanAddonDefaults`/`applyActionsDefaults` + `addons/actions.seen`) + the
  `[actions]` marker — with the dialog, that IS the permission. **Zero `haven` edit** (new `ActionsConsentWnd` +
  `AddonPanel`/`AddonManager`/`Manifest` edits; every widget public, like 1f-3). Compile OK + **9 headless checks**
  (the D-028 gate: `actionsGranted`/`requireActions` declaration-only for walker-vs-hello + null; `applyActionsDefaults`
  still default-disables a new write addon / marks seen / leaves a user-enabled one) + LuaJ parse of `hello`/`walker`.
  `hello` **read-only + reworded** (stale master-switch comments); the write demo **`walker` v0.2.0** (reworded to
  the per-addon model) is the in-game trigger. Doc `phase-4c-enable-consent-dialog.md` (+ superseded-in-part notes on
  the 4a/4b docs; D-028 in decisions.md; specs 10/12/api-reference updated). **In-game DoD pending** (no "Allow addon
  actions" checkbox; tick `walker` → dialog; Cancel keeps it off; Enable + Reload UI → walker loads + `:walker` walks;
  "Enable all" skips it; Back/close leaves no floating dialog; read addons still instant). Deferred: per-category
  breakdown (needs finer `"actions.*"` perms), re-consent on a read→write manifest flip, true modality.

- **Phase 4d ✅ — the rest of the MapView action verbs (`clickGob`/`useItemOn`/`place`/`select`) + `raw`.** Completes
  the MapView half of the gated tier on top of 4a's `moveTo`. Each sends **literally what the matching mouse gesture
  sends** — a `Widget.wdgmsg` from the `MapView`, world coords floored the one canonical way, `requireActions`-gated
  like `moveTo`: **`clickGob(ref [,button [,mods]])`** (`"click"` = `{pc, mc, button, mods}` + `Gob.GobClick.clickargs`
  `{0,gobid,gobrc,0,-1}` — a **bare** click, faithful for world objects; `ref` = the read-API GobRef via `resolve()`;
  button 1=left/3=right; `mods` bitfield Shift=1/Ctrl=2/Alt=4), **`useItemOn(x,y [,mods])`** (`"itemact"`, ground
  target), **`place(x,y,angle [,button [,mods]])`** (`"place"`; `angle` in RADIANS → `round(angle*32768/PI)`),
  **`select(x1,y1,x2,y2 [,mods])`** (`"sel"`; WORLD corners → TILE via `worldToTile`/`Coord2d.floor(MCache.tilesz)`),
  and **`raw(target,msg,…)`** (the escape hatch — `wdgmsg` from a **bound** widget; `target` = a widget id number
  (`UI.getwidget`, e.g. `model:raw()`) or a `"mapview"`/`"gameui"` token reusing 2c's `hookTarget`; args via the shared
  `LuaMarshal`). Optional trailing `button`/`mods` default to a plain left-click (one canonical way — same fn, not a
  second style). Pure, headless-testable arg builders (`clickGobArgs`/`itemactArgs`/`placeAngle`/`placeArgs`/`selArgs`)
  reuse `moveClickCoord`; the senders grab the live `MapView`, fill the dummy `pc`, and `wdgmsg`. **Zero `haven` edit**
  (only `AddonManager.java`; no new imports). Compile OK + **33 headless checks** (builders' coord/angle/tile encodings
  incl. negative flooring + the 9-element gob-click order; the whole `hafen.act` facade gated end-to-end in the real
  installer — declaring owner passes each verb to `"no map view"`, reader blocked `"did not declare"`, `raw` rejects a
  missing `msg`, bad numeric args refused after the gate) + LuaJ parse of `walker`. `hello` stays the read-only harness;
  the write demo is **`walker` v0.3.0** — `:walker` became a sub-command dispatcher (`walk`=moveTo, `click`=clickGob
  right-click, `use`=useItemOn, `sel`=select, `place`=place, `raw`=the escape hatch), one deliberate verb each. Doc
  `phase-4d-mapview-verbs.md`. **In-game verified ✅. Committed `98885490`.** Deferred: composite sub-mesh targeting (`clickGob` sends mesh
  `-1` — faithful for objects, not a specific player/animal body part), `useItemOn` on a gob (ground-only ships; `raw`
  covers it), menu/flower (4e), item verbs (4f), the per-subsystem gated verbs (4g).

- **Phase 4e ✅ — menu + flower action verbs (`hafen.act.menu` / `hafen.act.flower`).** The two **menu** verbs of the
  gated tier (the last non-item MapView-adjacent player actions), both `requireActions`-gated like every `hafen.act.*`:
  **`menu(path…)`** → send the `"act"` menu-path message via **`GameUI.act(String...)`** (`wdgmsg("act", path…)` — the
  same message the action-bar menu grid sends; the client itself uses it, e.g. `act("lo","cs")` = log out to char
  select). Path tokens are strings (a number coerces, console-token style; nil/bool/table refused; ≥1 required). **⚠️
  Caveat (coverage-gaps C3):** paginae are server-fetched → names are content-defined/localized/versioned and resolve
  only if the page is loaded — **not a stable address space** (and some paths COMMIT, e.g. `"lo"` logs out); the addon
  supplies the tokens. **`flower(label)`** → **bool** — locate the single open `FlowerMenu` (recursive
  `ui.root.children(FlowerMenu.class)`; only one is ever open — it grabs input), match a petal whose `name` equals
  `label` **case-insensitively** (exact, NOT substring — an action commits an irreversible choice; first match wins),
  and drive the client's own **`FlowerMenu.choose`** (wrap-not-reimplement D-009 — so a client-side petal like the voice
  Mute/Unmute is handled right, not mis-sent). Returns true iff a petal matched; **never throws** for no-menu-open /
  no-match (an addon just tests the result — the gate error + a non-string `label` still throw). **Petals grab the
  mouse+keyboard while open**, so a petal can't be picked by hand-typing a command — `flower`'s intended use is
  automation (open a menu, then pick from a timer/event). **Zero `haven` edit** — only `AddonManager.java` (facade +
  `actMenu`/`actFlower`/`openFlower` + pure `menuPath`/`flowerPetalIndex`) + one import `haven.FlowerMenu`; all backings
  public (`GameUI.act`, `Widget.children(Class)`, `FlowerMenu.opts`/`Petal.name`/`choose`, the `gui()` locator).
  Compile OK + **26 headless checks** (21 on `menuPath` [single/multi-token, number-coerce, empty/nil/bool/trailing-nil
  reject] + `flowerPetalIndex` [exact/ci match, first-dup-wins, no-match, null-array/element/empty-name edges]; **5
  LuaJ-runtime in a real `Sandbox.create()` env** — `table.unpack` present + spreads a path, **NO** global `unpack`
  (Lua 5.2 / LuaJ 3.0.1), `walker`+`hello` parse) + LuaJ parse. `walker` **v0.4.0** (`:walker menu <t…>` = `menu`;
  `:walker flower <label>` = `clickGob(id,3)` → timed `flower`). Doc `phase-4e-menu-flower.md`. **In-game verified ✅. Committed `ea89c997`.**
  Deferred: `MenuOpened` event (fixed 0.5s timer used meanwhile), petal disambiguation by index/res, item verbs (4f),
  per-subsystem gated verbs (4g).

- **Phase 4f ✅ — item action verbs (`hafen.act.item`).** The item half of the gated tier — pick up / drop /
  transfer / activate an item, or apply the cursor item onto one — `requireActions`-gated like every
  `hafen.act.*` verb (D-027/D-028). `hafen.act.item(item, verb [, n])`: `verb` ∈ take/drop/transfer/iact/itemact
  → the **exact `GItem.wdgmsg`** the matching click sends (`WItem.mousedown`/`iteminteract`), so the client stays
  server-authoritative; the intra-item grab coord is a fixed `Coord.z`. **The item reference is a HANDLE = the
  item's server widget id** (`GItem.wdgid()`) — every server item IS a bound widget (the server sends a
  `GItem`, wrapped in a client-side `WItem`; the `GItem` carries the id + is what the verbs `wdgmsg` from), and
  items have no other stable id (**D-022 handle-only**, honoring D-013). So **`itemSnapshot` now sets a `handle`
  field**, and because `hafen.items.*` (inventory/equipment/hand/find) **and** `model:items()` share
  `itemSnapshot`, **both surfaces became actionable at once** — this is how the **`LuaModel` item verbs deferred
  from Phase 3** land, through the **one canonical flat verb** (no OO `model:item:take()`, D-013). `hafen.act.item`
  reads that `handle` (or a raw handle number) and **re-resolves the live `GItem` each call** (`UI.getwidget(id)`)
  — always fresh, like a GobRef; a moved/used item no longer maps to a `GItem` → a guiding "handle is stale"
  error instead of acting on the wrong item. `handle` is facade-safe (P1, only an int crosses) + leak-free (no
  bridge registry — the engine's own `UI.widgets` id↔widget map tracks it). `n` = the stack count for drop/
  transfer (default **-1 = all**); take/iact/itemact carry no count; iact/itemact send mods 0 (a MODIFIED
  interaction goes through `raw(item.handle, "iact", {x=0,y=0}, mods)`). Adding `handle` doesn't perturb the
  change diffs (`equipEqual`/`actionbarEqual` compare only slot/res/name/num; the model item poll is
  `WItem`-identity-keyed) → **`EquipChanged`**/model item events unaffected. **Zero `haven` edit** — all backings
  public (`GItem.wdgid`/`Widget.wdgmsg`/`UI.getwidget`, the `Inventory`/`Equipory` item structure); only
  `AddonManager.java` changed (facade `act.item` + pure `itemVerbArgs` + `resolveItemHandle`/`actItem` + the
  `handle` in `itemSnapshot`). Compile OK + **19 headless checks** (9 pure `itemVerbArgs`: the five verb arg
  shapes, `n` stack-count threading for drop/transfer, `n`-ignored for iact, unknown/empty→null; + 10 facade
  checks in a **real `Sandbox.create()` env via the actual `installHafen`** — a declaring owner passes the gate
  to verb-validation + resolution errors, a raw-number handle is accepted, bad-type / no-`handle` rejects fire,
  and a **non-declaring owner is blocked BEFORE verb validation**) + LuaJ parse of `walker`+`hello`. `hello`
  **v0.34.0** (read-only harness — logs the new `handle` on the first read item, read-side proof; no permission
  needed); the write demo is **`walker` v0.5.0** (`:walker item [verb]` = act on the first inventory item,
  default `take` = lift to cursor, reversible). Doc `phase-4f-item-verbs.md`. **In-game DoD pending** (enable
  walker + consent + Reload UI; `:walker item` takes the first item onto the cursor; `hello` logs a `handle`;
  a stale handle errors; a non-declaring addon is refused). **In-game verified ✅. Committed `2557e798`.**
  Deferred: item quality/contents / stack-split take,
  a bulk `Inventory "invxf"` verb (`raw` covers it), the per-subsystem gated verbs (4g).

- **Phase 4g ✅ — per-subsystem gated write verbs (completes Phase 4 + A3).** The write counterparts of the read
  subsystems, each in its OWN namespace but sharing the same `"actions"` gate (`requireActions`, D-027/D-028):
  **`hafen.speed.set(n)`** (0..3 crawl/walk/run/sprint → the client's own `Speedget.set` → `wdgmsg("set",n)`),
  **`hafen.craft.make([all])`** (press the OPEN recipe's Craft / Craft All button → `wdgmsg("make",0|1)`; CONSUMES
  ingredients; errors if no window open), **`hafen.actionbar.use(n [,mods])`** (activate belt slot n — the raw
  0-based index `slot(n)` reads — via `beltwdg.act(n, Interaction(1,mods))` = a LEFT-click on it → `wdgmsg("belt",
  n,…)`; a ground-targeted ability then enters targeting mode), and **`hafen.kin.add/remove/forget/rename/setGroup`**
  (`add(secret)` adds a kin by the other player's HEARTH SECRET via `wdgmsg("bypwd",secret)` — the Kin window's
  "Add kin" field; the ref-taking verbs take a `kin` snapshot/id/name). **`remove` + `forget` are the game's
  TWO-STEP drop** (a state machine): `remove` = "End kinship" (`Buddy.endkin`) ends the kinship but the kin STAYS
  memorized in the list; `forget` = "Forget" (`Buddy.forget`) then drops the memorized kin — both send `wdgmsg(
  "rm",id)` and the SERVER advances active→memorized→gone (so a full removal of an active kin is remove()→forget()).
  `rename`→`chname`=`nick`, `setGroup`→`chgrp`=`grp`. No add-by-NAME message exists (kinning needs a shared secret
  or the right-click "Add as kin" petal, `clickGob(id,3)`+`flower`); `setGroup` added over the original
  "add/remove/rename" sketch — a faithful map to the four real messages (`bypwd`/`rm`/`nick`/`grp`) across five
  verbs. **Wrap-not-reimplement (D-009)** throughout —
  every verb drives the client's own method, so it stays server-authoritative. **Zero `haven` edit** (all backings
  public: `Speedget.set`, `Makewindow.wdgmsg`, `GameUI.belt`/`beltwdg` + `Belt.act` + `MenuGrid.Interaction`,
  `BuddyWnd.find`/`gc`/`wdgmsg("bypwd")` + `Buddy.endkin`/`forget`/`chname`/`chgrp`); only `AddonManager.java` + one
  import (`haven.MenuGrid`). Compile OK + **25 headless checks** (the whole facade gated end-to-end in a real
  `Sandbox.create()` env via the actual `installHafen`: **declaring** → each verb reaches its arg-validation /
  no-live-widget error; **non-declaring** → refused up front with "did not declare").
  `hello` stays read-only (unchanged); write demo **`walker` v0.6.0** (`:walker speed|craft|bar|kin`). Doc
  `phase-4g-per-subsystem-verbs.md`. **In-game DoD pending** (enable walker + consent + Reload UI; `:walker speed 2`
  sets run; `:walker craft` crafts an open recipe; `:walker bar 0` fires a slot; `:walker kin <name> group 3`
  recolours a kin; each refused for a non-declaring addon). **This completes Phase 4** (the gated actions tier).
  Deferred: `kin.add` (no message), `actionbar` hotkey-at-cursor semantics (`Belt.keyact`), `speed.set`
  availability pre-check, a `CraftChanged`/`SpeedChanged` event.

- **V1 ✅ — Minimal client-only world ghosts (`hafen.ghost`).** First slice of the V-series (virtual entities):
  place **client-only virtual props** in the 3D world — a `Gob` with **no server id** (id -1 ⇒ `virtual`, invisible
  to OCache/reads/**server** → **SAFE-tier, NOT gated**, D-029) + a `ResDrawable`, added to the MapView `basic`
  scene, the [`Plob`](src/haven/MapView.java:1779) precedent. `hafen.ghost.new{res,x,y[,a]}` → a bridge-owned
  **handle** (D-030, not a GobRef — no id to re-resolve) with `:move(x,y[,a])`/`:pos()`/`:res()`/`:destroy()`;
  `hafen.ghost.list([filter])` → this addon's live ghosts (canonical filter adapted to handles: nil/string-on-res/
  fn-over-handle). **One `// addon:` core edit** (spec 16 §6 option A, D-011): the `MapView.addClientGob(Gob)→
  RenderTree.Slot` / `removeClientGob(Slot)` seam pair mirroring `Plob.place` (`removeClientGob` swallows
  `SlotRemoved` → teardown idempotent). **Deferred create** via `glob.loader.defer` (dodges `Loading` on
  `res.get()`, the Plob/`hafen.sound` pattern): the handle returns immediately, the prop streams in; the publish +
  destroy handoff is guarded by the ghost monitor so the loader-thread create never races a `:move`/`:destroy`
  (destroy-before-publish discards the un-added gob — no leak). **No global poll list** — the render tree ticks
  `gob.placed` itself; ghosts live only in `Addon.ghosts`, torn down (slot removed + sprite disposed) on reload/
  disable/relogin (P2). Compile OK + **35 headless checks** (`ghostMatches` trichotomy incl. fn-gets-handle +
  error-drops; handle `:move`/`:pos`/`:res` round-trip incl. keep-facing + bad-args→LuaError; `list` stable-handle
  + string filter; `destroyGhost` idempotent + owner-drop + dead-inert; `teardownGhosts`; `newGhost` validation +
  no-world nil-guard) + LuaJ parse. `hello` **v0.35.0** (OnEnterWorld spawns a cabin 3 tiles E, reads list/pos,
  `:move`s it, auto-destroys after 8s; `:hello ghost` toggles one at the player). Doc `v1-ghosts.md`. **The first
  in-game run surfaced TWO render bugs, both FIXED (§8): (1)** a client-only gob is **not in OCache**, so nothing
  `ctick`/`gtick`s its sprite → **nothing rendered** — the seam now makes MapView own a `clientGobs` list and
  `ctick`/`gtick` each ghost beside the `Plob` (so `removeClientGob` takes `(Gob,Slot)`); **(2)** game resources
  load via **`Resource.remote()`** (server pool + `local()` fallback), not `local()` alone — a terobj was never
  found. **In-game verified ✅ (the cabin renders at the player). Committed `8a9f36eb`.** Deferred:
  `sdt`/alpha/tint/rotate (V3), clickability + `GhostClicked` (V2, the second `// addon:` MapView edit at
  `Click.hit`), layouts (V4), gizmo (V5/V6).

- **V2 ✅ — Clickable ghosts + `GhostClicked` (`hafen.ghost`, D-032).** Second V-series slice: opt-in **clickable**
  ghosts. `clickable=true` at `new` / `g:clickable(bool)` + per-ghost `onClick(g,button,x,y)` + the **owner-scoped**
  `GhostClicked{ghost,button,x,y}` event. **The mechanism is the real work:** a virtual gob's own `GobState` OMITS
  the `GobClick` (`if(!virtual)` at [Gob.java:716](src/haven/Gob.java:716)), so a plain V1 ghost is unpickable — new
  **`GhostGob extends Gob`** overrides the per-gob `obstate(Pipe)` hook (which `GobState.apply` calls regardless of
  `virtual`) to prep a `GobClick` **when `clickable`**, giving a virtual ghost a pick surface WITHOUT flipping
  `virtual` (so it stays OCache/server-invisible, and the `Click.hit` `cg.virtual` fast-path still identifies it).
  **Toggle = remove+re-add** (`setGhostClickable`): `Clicklist` fixes membership at slot-add time and never re-runs
  its `Clickable` filter on a later ancestor-state change, so a live toggle re-adds the gob (obstate re-applied
  fresh); a `clickable`-at-create ghost needs no re-add (the deferred create sets the flag before `addClientGob`,
  so it is tracked from frame one). **One `haven` core edit** (the SECOND V-series edit, D-011): a 3-line `// addon:`
  intercept at the TOP of [`MapView.Click.hit`](src/haven/MapView.java:2065), beside the voice hooks — `cg.virtual`
  fast-path → `AddonManager.onGhostClick(cg,button,mc)` finds the owning **clickable** ghost, fires `onClick` + the
  owner-scoped `GhostClicked` (a ghost is private to its addon ⇒ the handle must not leak cross-addon, so `fireTo`
  the owner, not a global `fire`), and **returns before `wdgmsg`** (consume — client-only detection ⇒ no server
  contact ⇒ still SAFE-tier). Consume is UNCONDITIONAL for a clickable ghost (the DoD: no server click / no walk);
  a non-clickable ghost has no `GobClick`, never wins a pick, stays click-through. The V1 `addClientGob`/
  `removeClientGob` seam is reused unchanged. Compile OK + **27 headless checks** (`GhostGob.obstate` gates the
  `GobClick` via a `BufPipe`, incl. GobClick.gob identity + live flag read; `onGhostClick` dispatch —
  null/unregistered/non-clickable/dead → false, clickable+registered → fires onClick (self=handle, button, world
  x,y) + the owner GhostClicked event + returns true, consumes even with no onClick, and does NOT fire when
  non-clickable; `setGhostClickable` flag mirror on a not-yet-live ghost + unchanged/dead no-ops — same-package
  reflection, a real `Sandbox.create()` env) + LuaJ parse. `hello` **v0.36.0** (`:hello ghost` = a CLICKABLE cabin
  with an onClick; the V1 auto-demo cabin stays non-clickable = click-through; a `GhostClicked` logger). Doc
  `v2-clickable-ghosts.md`. **In-game verified ✅. Committed `7d759f6f`.** Deferred:
  consume-vs-pass-through routing (V2 consumes unconditionally; forwarding to the gob behind the ghost needs a
  re-pick — use `:clickable(false)` for a normal click), an `iteminteract` held-item guard (flagged in the devlog
  — a 3-line follow-up if wanted), V3 look/orientation.

- **V3 ✅ — Ghost look & orientation (`hafen.ghost`).** Third V-series slice: a ghost gains a **look** and a live
  **orientation**. New handle verbs `g:rotate(a)` (just `Gob.move(rc,a)`, position kept), `g:setRes(res[,sdt])`
  (swap the visual), `g:alpha(0..1)` + `g:tint{r,g,b[,a]}` (the translucent "ghost" look + a colour overlay), and
  `g:show()`/`g:hide()` (drop/re-add the scene slot, keeping the ghost); plus the `new{a,sdt,alpha,tint}` options.
  **The look states live in `GhostGob.obstate`** (extends V2's per-gob hook): `tint`→`MixColor` (the exact state
  `GobHealth` uses for the damage tint), `alpha<1`→`BaseColor(1,1,1,α)`+`FragColor.blend(new BlendMode())`+
  `States.maskdepth` — the engine's own translucent-overlay recipe (the tile-grid `gridmat` / drag-select rect in
  MapView). Because `GobState.equals` compares only the SetupMod mods (NOT `obstate`'s output — same as V2's
  clickable), a **live** alpha/tint/clickable change is applied by **remove+re-add of the scene slot** (factored
  into `refreshGhostScene`, shared with the refactored `setGhostClickable`); `:rotate`/`:move` instead ride the
  render tree's `Placed.autotick`. **`:setRes`** records the desired res/sdt (so a swap before the prop streams in
  is honoured) then **defers** building the new `ResDrawable` (dodging `Loading`, like `new`) and `setattr`s it
  under **`synchronized(gob)`** — the exact lock the engine's own live res-swap holds (`ResDrawable.$cres.apply`
  inside `OCache.GobInfo.apply`; the gob's `slots` is a plain `ArrayList` shared with the ghost `ctick` path); a
  newer swap wins (stale task drops its drawable). The deferred create now reads the ghost's **current** res/sdt and
  applies alpha/tint/hidden **before** the first `addClientGob`, so a verb in the streaming-in window takes effect on
  appearance. **Colour = named-key `{r=,g=,b=[,a=]}`** reusing the shipped `luaColor` (markers/party/kin), NOT the
  spec's illustrative positional `{80,160,255,180}` — one canonical colour form (§1). **ZERO core edit** — reuses
  the V1 `addClientGob`/`removeClientGob` seam; only `io.brodgar.addon` (`GhostGob`/`LuaGhost`/`AddonManager`).
  Compile OK + **33 headless checks** (`GhostGob.obstate` state-gating via a `BufPipe`: plain→nothing, clickable→
  GobClick, alpha<1→BaseColor(a=α)+blend, alpha==1 boundary→no blend, tint→MixColor, all-composed; the pure parsers
  `clampAlpha`/`luaAlpha`/`luaTint`(named-key + a-default-255)/`luaSdt`(byte round-trip) — same-package for the
  protected `obstate`, reflection for the private statics) + LuaJ parse. `hello` **v0.37.0** (OnEnterWorld cabin now
  spawns rotated 45° + translucent + tinted, `:move`s, then live res-swaps + rotates at +3s, `:hide`/`:show` at
  +5/6s, destroys +8s; `:hello ghost` = a clickable translucent cabin whose `onClick` live-cycles `:rotate`+`:alpha`).
  Doc `v3-look-orientation.md`. **In-game DoD pending** (rotated translucent cabin; res-swap morphs it; `:reload`
  leaks nothing). *(Java engine change ⇒ `ant` rebuild + restart.)* Deferred: `:scale` (→V6), grid-anchored layouts
  + the `planner` addon (→V4), the transform gizmo (→V5/V6).

- **V4 ✅ — Grid-anchored layouts + the `planner` example addon (`hafen.ghost`/`hafen.map`).** Fourth V-series
  slice: turn a **set** of ghosts into a **persistent layout** that reloads at the same physical spot after a relog.
  New primitive **`hafen.map.fromGridPos(anchor)`** — the exact **inverse** of `gridPos` (`fromGridPos(gridPos(x,y))`
  round-trips): a saved `{gridId, x, y}` (stable grid id + within-grid offset) → a login-relative world coord in
  *this* session, or nil if that grid isn't loaded (world coords are login-relative; grid ids are the cross-session
  anchor — [[hafen-positioning]] / coverage-gaps C4). It resolves a grid **by stable id** via **one new
  `haven`-package accessor** `AddonWidgets.gridWorldUL(mc,id)` (scans `MCache.grids` — package-private — for `g.id`,
  returns `g.ul·tilesz`, the same basis `gridPos` subtracts, so the round-trip is exact) — the "SpeakerIcon trick"
  since 1d-1, keeping reflection out of Lua (D-017). **ZERO `MCache`/core edit** — the one package-private read lives
  in the addon-owned `AddonWidgets`, not the engine; `AddonManager.fromGridPos` just parses + calls it. New
  **`planner`** example addon (v0.1.0, **no permissions** — safe-tier, D-029): a base planner — `:planner place`
  spawns a clickable translucent blueprint ghost at the player, anchored via `gridPos`; `OnEnterWorld` rebuilds the
  layout from the per-char store and re-resolves each anchor via `fromGridPos`, **retrying** (`timer.every(1)`, ~15s)
  as grids stream in; **click-to-select** (V2 `onClick`/`GhostClicked` → look swap), `:planner rotate` persists a
  second field (facing), plus `list`/`select`/`remove`/`clear`/`blueprint`. One runtime `items` list is the source of
  truth; `persist()` writes only `{res,a,anchor}` (the handle never hits disk). `hello` **untouched** (stays the
  read-only harness; `planner` is the V-series example, D-031). Compile OK + `ant bin` packages `planner`; **headless:
  LuaJ parse of `planner` + a JSON round-trip of the exact layout shape through the real store writer/reader — a
  19-digit `gridId` survives as an EXACT string (no double-loss), nested `items[]`/`anchor{}` + all fields preserved,
  empty→`[]`; + the `fromGridPos` arithmetic round-trip.** Doc `v4-layouts-planner.md`. **In-game verified ✅.
  Committed `186b23b9`** (placed several, click-selected, relog → reloaded at the same grid position). *(Java engine
  change ⇒ `ant` rebuild + restart.)* Deferred: `screenToWorld`/`snapPlace`/gizmo (→V5/V6), `:scale` (→V6),
  account-scope layouts.

- **V5a ✅ — Gizmo primitives + `planner` move-mode (`hafen.map`/`hafen.hook`).** V5 was split into V5a (the Java
  primitives) + V5b (the arrow gizmo) — the D-031 seam (primitives in Java, gizmo behaviour in a bundled Lua library).
  V5a ships three primitives: **`hafen.map.screenToWorld(sx,sy,fn)`** — the raycast inverse of `worldToScreen`, via the
  engine's own `Maptest` GPU pass (subclassed inline — the class is public, **zero core edit**); it is **ASYNC by
  necessity** (a GPU→CPU readback, like the placement Plob), so `fn` is called a frame later with `{x,y}` (or nil for no
  terrain). **`hafen.map.snapPlace(x,y[,fine])`** + **`placeGrid()`** — snap a world coord **identically to placing a
  building** (D-033), reusing the client's placegrid snapper: **one `// addon:` refactor** factors `StdPlace`'s snap
  math **verbatim** into a shared static **`MapView.placeSnap(Coord2d,int)`** that both the client and the bridge call
  (no drift, the preferred D-033 option); `fine`→SHIFT sub-tile grid, else tile centre; `placeGrid()` reads
  `plobpgran`. **`hafen.hook.grab{move,up}`** — the drag-capture primitive: a new **visible** `LuaMouseGrab extends
  Widget` on `ui.root` (a `MouseMoveEvent` is broadcast to every VISIBLE widget — so it gets moves; the invisible
  `AddonRoot` would not) + `ui.grabmouse` (captures the terminating up + down/wheel → the `MapView` neither pans nor
  clicks = **camera stays put**, the `Window`-drag pattern, zero core edit); callbacks get `mods={shift,ctrl,alt}` (no
  Lua bit ops); bridge-owned (`Addon.mouseGrabs`) with a **deferred self-unlink** (so a `:release()` from inside `move`
  never mutates the tree mid-broadcast); handle `{ :release() }`. **Threading:** input dispatch (`UILoop.Frame.tick`)
  AND the `Maptest` readback both hold `synchronized(ui)`, so all addon Lua stays serialized (the same guarantee V2
  click / L3 rely on); `Maptest.run()` doesn't block (submits + returns; callback lands after the frame releases `ui`).
  **One `// addon:` core edit** (`MapView.placeSnap`); the rest is `io.brodgar.addon` (new `LuaMouseGrab.java` +
  `AddonManager` + `Addon.mouseGrabs`). Compile OK + **9 headless `placeSnap` checks** (tile-centre incl. negatives /
  sub-tile placegrid / free at `plobpgran=0`, on the real `Coord2d` — `MapView.<clinit>` needs GL so the static itself
  is in-game-verified) + LuaJ parse. **`planner` v0.2.0** proves the stack end-to-end with a **move-mode**: `:planner
  grab` drags the selected ghost — each mouse move raycasts the ground (`screenToWorld`) → snaps to the placegrid
  (`snapPlace`, SHIFT=fine) → `:move`s the ghost (raycasts **coalesced**, one in flight); click drops it (re-anchor
  `gridPos` + persist); the camera stays put throughout. `hello` untouched. Doc `v5a-gizmo-primitives.md`. **In-game
  verified ✅. Committed `b8526302`.** (Post-verify tweak: `planner` ghosts made **opaque** — `LOOK.*.alpha` 0.45/0.85
  → 1.0 — the translucent blueprint look was too faint to read against the terrain; selection still shows via the
  idle-blue/selected-warm tint.) *(Java engine change ⇒ rebuild + restart.)* Deferred: the arrow-handle gizmo + axis
  constraint (→V5b), rotate/scale (→V6).

- **V5b ✅ — The transform gizmo (Unity-style, drawn with `g:draw`; `hafen.ghost` gizmo).** Sixth V-series slice: the
  gizmo BEHAVIOUR (D-031's Lua half) as a new **`planner/gizmo.lua`** installing a `gizmo(target, opts)` global
  (mirrors the api-reference `hafen.ghost.gizmo` shape; a **planner-shipped Lua library, NOT a `hafen.*` global** —
  promotable to a shared one via a thin Java shim later). **Maintainer chose spec §4's "2D-projected" handle path**
  over 3D arrow-mesh ghosts (no arrow resource ships in the jar). The handles are **drawn**: red **X** / green **Y**
  arrow shafts (`g:line`) with **filled-triangle** heads + a yellow free **centre** (`g:frect`), painted on a
  `hafen.ui.overlay` and **re-projected from the world axes every frame** (`hafen.player.worldToScreen`), so they
  foreshorten with the camera and read as "in the 3D world"; the arrow-head is a fixed **screen** size so it stays
  grabbable at any zoom. **Pick** = `hafen.hook.input("mapview","mousedown")` screen-space hit-test (cursor is
  mapview-local, the same space `worldToScreen` returns — exact) → `ev:preventDefault()` (no map click / camera / V2
  select) → arm `hafen.hook.grab` **on the real press** (a true press-drag-release; the FIRST up IS the drop, so none
  of the mousedown-vs-async-pick timing ambiguity a "click an arrow-ghost to arm" model would have). **Drag** =
  `screenToWorld` → **axis-constrain** (X arrow varies world-X and pins the start-Y line; Y arrow the mirror; centre
  = free — clean because `MapView.placeSnap` snaps each component **independently**) → `snapPlace` (SHIFT=fine, D-033)
  → `target:move`; camera fixed via the grab; `onCommit` re-anchors (`gridPos`) + persists. A second (non-preventing)
  mousemove hook drives the hover highlight. **Zero `haven` core edit** — the only new Java is a **`g:poly`**
  filled-convex-polygon primitive added to our own **`LuaGOut`** (via the public `GOut.drawp(TRIANGLE_FAN)` + public
  `GOut.tx`; reusable by any addon). Bridge-owned teardown (overlay/hooks/grab) + `planner` detaches on
  select-change / grab (mutually exclusive) / remove / clear / relog / disable. Compile OK + headless (a real
  `Sandbox.create()` loads `gizmo.lua` → `gizmo` is a `function`; the constructor's target-validation rejects
  nil/`{}`/pos-only **before** touching `hafen`; `main.lua` parses) + `ant bin` packaged. **`planner` v0.3.0**
  (`:planner gizmo` toggle; `hello` untouched). Doc `v5b-gizmo.md`. **In-game DoD pending** (drag by the arrows,
  placegrid-snapped, camera stays; SHIFT=fine; `:reload`/detach leaks nothing). *(Java engine change ⇒ rebuild +
  restart.)* Deferred: rotate ring + `g:scale` + draw-on-top/constant-size polish (→V6); promote to a shared
  `hafen.ghost.gizmo` when a 2nd addon needs it.

- **V6 ✅ — Gizmo: rotate (+ placeangle) + scale + polish.** Seventh (final) V-series slice — completes the transform
  gizmo. **Rotate:** two new bridge helpers `hafen.map.snapAngle(a[,fine])` + `placeAngle()` — the **absolute** analog
  of the engine's **wheel-relative** `StdPlace.rotate`: `45°` (π/4) coarse, `π/plobagran` fine, normalized to
  `(-π,π]`. There is no verbatim StdPlace expression to share (unlike position's `MapView.placeSnap`), so this is the
  §4.1 **zero-`haven`-edit mirror** reading the **public** `MapView.plobagran` (so `:placeangle` still applies). (A
  pre-existing unrelated `AddonManager.placeAngle(double)` — the 4d place-verb *encoding* — does not clash; the new
  one is a `hafen.map` facade entry.) **Scale (the least-native piece):** `g:scale(s)` preps a `Location.scale` in
  `GhostGob.obstate`, which runs on the gob's **child** render slot (below the `Placed` translate+rotate) → the model
  matrix is **T·R·S**, i.e. **in-place** uniform scaling around the gob's local origin; pick surface scales with it.
  Mirrored like alpha/tint (a live change re-adds the slot via `refreshGhostScene`, since `GobState.equals` ignores
  `obstate`), applied at deferred-create publish, clamped `0.01..100`. **`g:pos()` now returns `{x,y,a,scale}`** (the
  full client transform, so a layout/gizmo can read scale back). Caveat: a `goback("gobx")` sprite (`resutil.CSprite`)
  drops both facing AND scale — those resources already ignore ghost rotation. **`gizmo.lua`** grows a cyan **rotate
  ring** (relative drag anchored by an offset → `screenToWorld` world-angle → `snapAngle`, SHIFT fine), a magenta
  **scale box** (pure screen-distance drag → `g:scale`), a **`mode`** (`move`/`rotate`/`scale`/`all`, default all;
  `:setMode`/`:mode`), and a **pure `atan2`** built from `math.atan` (no dependency on the optional `math.atan2`).
  **Polish is free from the 2D-projected path:** the HUD overlay draws **on top** (no depth occlusion) and every grab
  handle is a **constant screen size** (only the axis shafts foreshorten — anchoring the arrows in the world). **Zero
  `haven` core edit** (only `io.brodgar.addon` + planner Lua). Compile OK + **14 headless checks** (a real
  `Sandbox.create()` loads `gizmo.lua` → `gizmo` is a function, target-validation still rejects nil/`{}`/pos-only
  before `hafen`, quadrant-correct `atan2`, `main.lua` parses; + sandbox math deps) + a separate `snapPlaceAngle`
  math check (45°/15°/range) + `ant bin`. **`planner` v0.4.0** (`:planner gizmo [move|rotate|scale|all]`, `:planner
  scale <s>`, the gizmo `onCommit` persists facing+scale, all **grid-anchored** so a relog restores the full
  transform; `hello` untouched). Doc `v6-gizmo-rotate-scale.md`. **In-game verified ✅. Committed `9d13b6e7`**
  (rotate ring snaps on the `:placeangle`, scale box grows/shrinks, move still snaps, relog restores facing+scale).
  *(Java engine change ⇒ rebuild + restart.)* **This completes the V-series** (client-only world ghosts + the full
  transform gizmo). Deferred: promote to a shared `hafen.ghost.gizmo`; multi-select/group transform; non-uniform/snapped scale.

- **R1 — 2D image on screen (`hafen.render.image` + `g:image`/`g:aimage`).** ✅ The first R-series slice (custom
  non-`.res` rendering): an addon draws its **own PNG** on screen. `hafen.render.image(path)` decodes a PNG from the
  addon's **own folder** (`ImageIO.read` → `new TexI(img)` — the exact substrate `Resource.Image` runs on) into a
  **cached, bridge-owned** handle (`:size()`→`{w,h}` / `:dispose()`; one per (addon,path)); the new `resolveAddonAsset`
  sandboxes the path — resolve under `Addon.dir` then require `startsWith(base)`, **one containment check that rejects
  both absolute paths and `..`-escape** while allowing internal `a/../b` (D-017). Draw via the shared `g` wrapper:
  `g:image(img,x,y[,w,h])` (native/scaled → `GOut.image`) + `g:aimage(img,x,y,ax,ay)` (anchored → `GOut.aimage`) —
  lit up on **all** draw surfaces at once (widgets/HUD/gob overlays share `LuaGOut`); a nil/typo/disposed handle draws
  nothing (forgiving). The handle carries its `LuaImage` as an **opaque userdata** (the `LuaMarshal` facade-safe
  pattern, P1 — no Java method reachable, unforgeable without `luajava`) so the draw verbs `resolve` it back to the
  `TexI`; a `volatile dead` guard makes `:dispose()` final (no lazy `TexI.st()` re-upload). **ZERO `haven` core edit**
  (all backings public). New `LuaImage.java` + `Addon.images` owned list + `AddonManager` (facade + `newImage`/
  `imageHandle`/`disposeImage`/`teardownImages`, wired into `teardown` beside ghosts). Compile OK + `ant bin` packages
  the asset + **33 headless checks** (`resolveAddonAsset` containment; `LuaImage.resolve` userdata round-trip +
  foreign reject; `newImage` end-to-end decode→handle→`:size`→cache-same→`:dispose` dead+drop+idempotent→post-dispose
  fresh; validation) + LuaJ parse. `hello` **v0.38.0** (loads `icon.png` — a 32×32 RGBA green-"H" disc — at OnLoad;
  draws it native+scaled in the 2a window and anchored in the 2b HUD overlay). Doc `r1-images-screen.md`. **In-game
  verified ✅. Committed `45d851b9`.** *(Java engine change ⇒ rebuild + restart)*. Deferred: async decode (large
  assets), image-from-bytes/data-URI, `TexI` filter control; R2 (world sprite) + R3 (glTF model) next.

- **R2a — 2D image in the world, fixed quad (`hafen.render.sprite`).** ✅ Stand an addon's **own PNG** upright in the
  3D world as a fixed textured quad — the non-`.res` sibling of a ghost. `hafen.render.sprite{image, x, y [, a]
  [, scale] [, alpha] [, tint]}` → a transform handle (`:move`/`:rotate`/`:scale`/`:alpha`/`:tint`/`:show`/`:hide`/
  `:pos`→`{x,y,a,scale}`/`:image`/`:destroy`), gizmo-compatible. **This is the "one real refactor" — the V-series core
  is generalized** (D-013): a new base **`LuaWorldEntity`** holds the transform/look/scene/lifecycle + the gizmo;
  **`LuaGhost`** (now `extends` it) keeps only the `.res` specifics, new **`LuaSprite`** only the image; the
  `AddonManager` scene helpers were renamed `*Ghost`→`*Entity` + widened (a pure rename of verified logic — the ghost
  auto-demo is the regression), and the common handle verbs / filter factored into `addEntityHandle`/`entityMatches`.
  The **fixed quad** is a resource-free **`SpriteQuad`** — a 4-vert `TRIANGLE_STRIP` `Model` (`Homo3D.vertex` VEC3 +
  `Tex2D.texc` VEC2, upright at the feet, `t`-inverted so the image top is up, aspect-sized to ~1 tile) wrapped by
  the engine's OWN textured-surface states `Material(tr.draw, tr.clip, Material.nofacecull)` (a `TexRender` over the
  `TexI` sampler: sample + **alpha-CLIP/discard**, NOT blend — the `.res` `$tex` matpart, so it renders **solid** like
  the client's own art; the first cut used the translucent-overlay blend recipe and looked like a 1% ghost — §8) on a
  `SprDrawable` — reusing the `GhostGob` `obstate` (tint/alpha/scale) and the V1 `addClientGob` seam, so the whole
  transform + look + gizmo come for free. **Synchronous create** (the `TexI` is already decoded → no
  `Loading`, unlike a ghost's deferred Plob dance); **click-through** in R2a (the `GhostGob.clickable` flag stays
  false; the V2 click dispatch stays ghost-only). **ANCHOR-to-a-gob (the world-space `gobOverlay` analog):**
  `follow=<gobref>` / `:follow(gob[,{x=,y=,z=}])` / `:offset{…}` attach a new **`FollowMoving extends Moving`** whose
  `getc()` = `target.getc() + offset`, so the render tree's per-frame `Placed.autotick` tracks the gob automatically
  (no Lua polling; NOT a `Following` subclass → keeps its own facing; re-resolves the id each frame → survives
  unload/reload; a plain `:move` detaches). On the shared core → ghosts get it too. **ZERO `haven` core edit** (every
  render + follow primitive public; reuses the V1 seam). New `LuaWorldEntity.java`/`LuaSprite.java`/`SpriteQuad.java`/
  `FollowMoving.java` + `Addon.sprites` + `AddonManager`
  (`newSprite`/`spriteHandle`/`resolveSpriteImage`/`spriteWorldDims`/`teardownSprites` + the anchor helpers). Compile
  OK + `ant bin` + **40 headless checks** (`spriteWorldDims` aspect + 1-tile height + degenerate/null fallback;
  `SpriteQuad.quadVerts` upright geometry + texcoords + the real `Model` builds without GL; the generalized
  `entityMatches` filter; the anchor `luaOffset`/`followTargetId`/`entityWorldPos`) + LuaJ parse. `hello` **v0.40.0**
  (`:hello sprite` stands `icon.png` upright + live-transforms it; **`:hello follow`** floats it above the player's
  head and follows). Doc `r2a-sprites-world.md`. **In-game verified ✅ (renders SOLID + anchor follows the gob).
  Committed `abf2bf6d`.** — the first run showed the sprite ~1% translucent (fixed: the material now uses the engine's
  `TexRender.draw`/`clip` alpha-discard states, not the translucent-overlay blend recipe — see §8). *(Java engine
  change ⇒ rebuild + restart.)* Deferred to R2b: the camera-facing billboard (`billboard=true`), sprite
  click/gizmo-select, planner integration.

- **R2b — 2D image in the world, camera-facing billboard (`hafen.render.sprite{billboard=true}`).** ✅ Completes R2 —
  the **second visual on the R2a shared core**: `billboard=true` → a new resource-free **`LuaSpriteBillboard extends
  Drawable implements PView.Render2D`** (the `SpeakerIcon`/`LuaGobOverlay` pattern), whose `draw` projects the gob
  origin (`Homo3D.obj2view`, the `state` carries the `Placed` world transform) and blits the `TexI` **bottom-centred**
  on that screen point — so it **faces the camera** and is **screen-sized** (constant px at any zoom), on **top** of
  the 3D scene (`ScreenList`, no depth). Position/gizmo-move apply; world-rotate/scale do not (it is a flat 2D image).
  It reads the `GhostGob`'s live `alpha`/`tint`/`scale` itself (alpha→opacity, tint→a `chcolor` lerp-toward-tint,
  scale→a **screen-size** ×; obstate applies to a 3D mesh, which a billboard lacks). Crucially it is the gob's
  **`Drawable`** (not a bare `GAttrib`): `getattr(Drawable.class)!=null` dodges `Gob.ctick`'s `virtual && no-drawable
  ⇒ oc.remove(this)` per-tick cleanup, and `Gob.added`'s `slot.add(drawable)` gets the `Render2D` registered by the
  tree adapter (membership by slot-object type — the same reason `SpeakerIcon` renders). `newSprite` just branches
  the visual (`LuaSpriteBillboard` vs R2a's `SpriteQuad`); the `GhostGob`, synchronous create, `follow` anchor,
  teardown, and gizmo are all shared. **V2 click dispatch generalized to sprites**: `findGhostByGob`→`findEntityByGob`
  (scans `ghosts`+`sprites`, returns `LuaWorldEntity`), `onGhostClick` (same `MapView.Click.hit` entry, **no new core
  edit**) fires the subclass-named event via new abstract `clickEvent()`/`clickKey()` — a **fixed** sprite is now
  `clickable`/`onClick` (its quad renders into the clickmap) and fires the owner-scoped **`SpriteClicked{sprite,
  button,x,y}`**; billboards have no mesh → never picked (flag is a no-op). **Zero `haven` core edit** (reuses the V1
  `addClientGob` + V2 `Click.hit` seams; every billboard primitive — `Homo3D.obj2view`, `GOut.image`/`chcolor`,
  `UI.scale`, `Drawable`, `PView.Render2D`, `TexI` — is public); only `io.brodgar.addon` (new `LuaSpriteBillboard` +
  `AddonManager`/`LuaWorldEntity`/`LuaGhost`/`LuaSprite`). Compile OK + `ant bin` + **LuaJ parse** of hello/planner/
  gizmo + **pure billboard colour-math checks** (`clampByte`/`lerpByte` via reflection; the class loads headlessly).
  `hello` **v0.41.0** (`:hello billboard`); **`planner` v0.5.0** — records generalized to a ghost **or** a sprite
  (`kind`/`img`/`billboard`, `it.ghost`→`it.entity`, one kind-agnostic path selects/gizmos/grid-anchor-persists both),
  `:planner sprite [billboard]`, ships `planner/icon.png`. Doc `r2b-billboard-sprite.md`. **In-game DoD pending**
  (billboard faces camera; both gizmo-move; relog restores; `:reload` leaks nothing). *(Java engine change ⇒ rebuild +
  restart.)* **This completes R2** (2D image in the world — fixed quad + camera-facing billboard). Deferred: a
  billboard **pick** (screen-space hit-test so billboards click-select too); glTF model (**R3**).

- **R3a — custom 3D model in the world, glTF static mesh (`hafen.render.model` / `object`).** ✅ The first R3 slice:
  stand an addon's **own glTF model** (`.glb`/`.gltf`) in the world — the **mesh** sibling of a sprite/ghost, on the
  same R2 world-entity core. **New pure-Java parser [`Gltf`](src/io/brodgar/addon/Gltf.java)** (over our `Json`, no
  native deps): reads the `.glb` 12-byte header + `JSON`/`BIN` chunks (little-endian, by hand) and `.gltf` +
  **base64 data-URI**/external buffers; decodes accessors (6 componentTypes 5120–5126 + `byteStride` + integer
  normalization) + indices (ubyte/ushort/uint→`int[]`); walks the default scene's node tree (cycle-guarded),
  composing each node's `matrix`-or-`T·R·S` down the tree and **baking** every primitive's positions by
  `BASIS·nodeWorld` at parse time. **The basis conversion (spec §4):** glTF is right-handed +Y-up metres, H&H is
  Z-up tiles → `BASIS = (x,y,z)→(x,-z,y)` (a +90° turn about X, **det +1** so winding survives for R3b) × a fixed
  **`MODEL_UNIT` = 11 world units/metre (1 metre = 1 tile)**; the glTF origin maps to the gob position (author base
  at `Y=0`). Caps (`MAX_PRIMS`/`VERTS`/`BYTES`) + **named errors** for unsupported features (sparse/no-POSITION/
  non-triangle/external-without-loader — never a crash, D-018). **The visual [`MeshSprite`](src/io/brodgar/addon/MeshSprite.java)**
  (resource-free `Sprite`, `StaticSprite` multi-part pattern) builds one `POSITION`-only `Homo3D.vertex` `Model`
  (UINT16/UINT32 indices) + a flat **`BaseColor`** (`baseColorFactor`) **unlit** `Material` (`nofacecull`
  double-sided) per glTF primitive; each object owns its own `Model`s (like `SpriteQuad`). **`LuaObject extends
  LuaWorldEntity`** (+ the **`LuaMesh`** asset handle) reuses the shared transform/look/`follow`/gizmo/teardown; V2
  pick generalized (`findEntityIn` scans `Addon.objects`) → owner-scoped **`ObjectClicked`**. **Synchronous** create
  (geometry already decoded — no `Loading`). **Zero `haven` core edit** (reuses V1 `addClientGob` + V2 `Click.hit`;
  render primitives + `Matrix4f`/`Coord3f` all public); only `AddonManager.java` + `Addon.java` changed + 4 new addon
  classes. Compile OK + `ant bin` (ships `addons/hello/cube.glb`) + **27 headless parser checks** (`.glb`/`.gltf`+
  data-URI; indexed+non-indexed; TRS + parent→child baking; the basis round-trip — a real cube out upright, 1 tile
  tall, `x/y` centred; baseColorFactor + default white; doubleSided; the 6 error paths) + LuaJ parse of `hello`/
  `planner`/`gizmo`. `hello` **v0.42.0** (ships `cube.glb`, loads it at `OnLoad`, `:hello object` stands + live-
  transforms a glTF cube). Doc `r3a-models-world.md`. **In-game verified ✅. Committed `203a2622` (bundled with R3b-1).** Deferred: textures + `TEXCOORD_0` +
  multi-material + alpha modes (**R3b**); `NORMAL` + engine lighting + sRGB (**R3c**); skins/animation, Draco/meshopt,
  async decode (later).

- **R3b-1 — textured, multi-material glTF (`baseColorTexture` + `TEXCOORD_0` + alpha modes).** ✅ Makes R3a's meshes
  render **textured** with one material per primitive — the maintainer's own **`tank.glb`** (53 prims, 4 embedded
  PNGs) goes from a grey blob to a textured tank. **[`Gltf`](src/io/brodgar/addon/Gltf.java)** now decodes
  **`TEXCOORD_0`** (via the existing `readVecs`, **not** basis-baked — 2D UVs) + the full material
  (`pbrMetallicRoughness.baseColorTexture`, `alphaMode` OPAQUE/MASK/BLEND, `alphaCutoff`, `doubleSided`) and
  **extracts each referenced image to a raw byte blob** (`Gltf.Image{bytes,mime}`) from a **`bufferView` slice**
  (embedded — `tank.glb`), a **`data:` base64 URI**, or an **external file** via the R3a `Loader`; extraction is
  **lazy + deduped** (`imgRemap`, so 53 materials → **4** images) and capped (`MAX_IMAGES`/`MAX_IMAGE_BYTES`). `Gltf`
  stays **pure** (no GL/`ImageIO` — bytes only), so it is fully headless-testable. **[`LuaMesh`](src/io/brodgar/addon/LuaMesh.java)**
  now owns the **shared `TexI[]`** (decoded in `newMesh`'s **`buildMeshTextures`** via `ImageIO` → **`new
  TexI(img,false)`** — *no POT rounding* so glTF `[0,1]` UVs sample the whole image, NPOT-safe), freed in
  `disposeMesh` (the first GPU state a mesh owns; teardown frees objects before meshes, so a live object never
  dangles). **[`MeshSprite`](src/io/brodgar/addon/MeshSprite.java)** `mill(LuaMesh)` builds, per primitive, a
  `POSITION`+`TEXCOORD_0` **interleaved** `Model` (stride 20, the R2a quad layout; untextured → `POSITION`-only) + a
  per-material `Material`: **`TexRender.TexDraw` × `BaseColor`** (both `mul` into the fragment at priority 0 → texture
  × `baseColorFactor`), `MASK`→`TexClip` (0.5 cutoff) / `BLEND`→`FragColor.blend`+`States.maskdepth`,
  `doubleSided`→`Material.nofacecull` else back-face `States.Facecull` — sharing one `TexRender` per image. Still
  **unlit** (lighting → R3c). New mesh-handle **`:info()`** → `{prims,textured,textures,verts,tris}`; `mesh:dispose()`
  frees textures too. **Zero `haven` core edit** (all texture/material primitives public; reuses V1 `addClientGob` +
  V2 `Click.hit`); only `io.brodgar.addon`. Compile + `ant bin` + **43 headless parser checks** + LuaJ parse. `hello`
  **v0.43.0** (`:hello object` stands the tank **textured**, scaled from `:bounds().size.z` to ~2 tiles; `OnLoad` logs
  `:info()`). Doc `r3b1-textures-materials.md`. **In-game verified ✅. Committed `203a2622` (bundled with R3a).** (The
  tank renders textured; UV `v`-orientation confirmed correct — `TEXV_FLIP` stays false.) Deferred: **R3b-2**
  (`planner` `:planner object`); `NORMAL`/lighting/sRGB/emissive (**R3c**); sampler wrap/filter, custom `alphaCutoff`,
  `TEXCOORD_1`, async decode.

- **R3b-2 — `planner` integration (`:planner object`).** ✅ Completes **R3b** — the object analog of R2b (which did
  this for sprites): the **`planner`** example addon now places **glTF models** too, on the same kind-agnostic code
  path as its ghosts/sprites. A third record `kind="object"`; a `spawn` branch builds `hafen.render.object{model,x,y,
  a,scale,clickable=true,onClick}`; **`:planner object`** stands a shipped **`cube.glb`** (the 940-byte R3a test cube,
  1 tile at `scale 1`) at your feet, auto-selected. It is **click-selectable** (the mesh is in the clickmap → the
  per-object `onClick` selects + the owner-scoped **`ObjectClicked`** logs), **gizmo-driven** (the same
  `:move`/`:rotate`/`:scale` handle `:hello object` exercises live — `gizmo.lua` is already kind-agnostic), and
  **grid-anchor-persisted** (a **`model`** path stored beside `res`/`img`; the loader accepts a `kind=="object"` record;
  re-resolved via `hafen.map.gridPos`/`fromGridPos` on relog — position, facing, scale all restored). Selection
  **highlights by alpha** (idle 0.7 / sel 1.0), like a sprite — a colour tint would recolour the model's texture. The
  planner passes the **path string** to `render.object` (auto-load + cache), so no preloaded handle / `OnLoad` hook is
  needed. **Lua-only, ZERO `haven` core edit, no `io.brodgar.addon` change** — the render + transform handle + V2
  pick/`ObjectClicked` + gizmo-compatibility all shipped in R3a/R3b-1; ONLY `addons/planner/` changed. `ant hafen-client`
  still **BUILD SUCCESSFUL** (nothing broke) + `ant bin` packages `cube.glb` + **LuaJ parse** (planner/gizmo/hello all
  clean). `planner` **v0.6.0** (ships `cube.glb`; `:planner object` + `ObjectClicked` listener; records carry `kind`
  ghost/sprite/**object** + `model`). Doc `r3b2-planner-object.md`. **In-game DoD pending** (place → click-select →
  gizmo-move → relog restores; `:reload` leaks nothing). **No rebuild — Lua reload: `ant bin` + `:reload`/relog.**
  Deferred: a planner **model palette** (`:planner object <name>`); billboard-style pick; per-object `:setModel`.

- **R3c — lighting polish (glTF `NORMAL` + engine light state → models shade with the world).** ✅ **Completes R3 +
  the whole R-series.** glTF models rendered **unlit/fullbright** through R3a/R3b; R3c makes them **shade with the world
  lights** like game geometry. `Gltf` gains two per-`Prim` fields, both baked H&H-local, parser still 100% pure/headless:
  **`nrm`** (never null) = the glTF **`NORMAL`** attribute transformed by the **inverse-transpose** of the `basis·node`
  matrix (`trim3(transpose(invert(fin)))` — so a non-uniform node scale shears the surface normal correctly, not skewed),
  OR, when the mesh has no `NORMAL`, **smooth area-weighted normals computed from the baked triangle geometry** (`e1×e2`
  accumulated per vertex → normalize; degenerate → +Z; the det-+1 basis keeps winding outward, so they match the
  transformed attribute exactly); + **`emissive`** (`emissiveFactor`, default black). **`MeshSprite.buildModel`** became a
  **generic interleaver** — `POSITION` + `NORMAL`(when lit) + `TEXCOORD_0`(when textured), stride 12/20/24/32 — feeding
  **`Homo3D.normal`**; each lit material adds a **`Light.PhongLight`** state (the same one a `.res` `col` layer adds), so
  the engine `Phong` shader multiplies the MapView scene's world lights (`Lighting.lights`, already applied to every gob
  in the `basic` scene our ghost gobs live in) into the fragment: albedo = R3b's texture × `baseColorFactor`,
  `emissiveFactor`→Phong `emi` (glows in shadow), reflectance = the engine's **neutral defaults** (amb 0.2 / dif 0.8 / no
  spec / matte, per-fragment). New mesh-handle **`:info().lit`**. **sRGB = a deliberate no-op** — the engine never
  `.srgb()`s a model texture (game textures load `UNORM8`), so our `UNORM8` `TexI`s already match; forcing it would make
  ours the outlier. **Zero `haven` core edit** (reuses V1 `addClientGob` + R3b material path; `Homo3D.normal` +
  `Light.PhongLight` public; only `Gltf`/`MeshSprite`/`AddonManager` changed). Compile OK + **10 headless parser checks**
  (a synthetic **with-`NORMAL`** triangle + `emissiveFactor` → baked normal `(0,-1,0)` [+Z through the inv-transpose
  basis, unit-length, NOT scaled by the unit-basis], emissive `[1,0.5,0]`, pos baked to `(0,0,11)`; a **without-`NORMAL`**
  triangle → the smooth fallback gives the *same* `(0,-1,0)`; they agree; the real **`tank.glb`** — all 53 prims carry
  unit normals) + LuaJ parse of every addon. `hello` **v0.44.0** (`:hello object` now stands the tank **lit**; the load
  log reports `53 LIT`). Doc `r3c-lighting.md`. **In-game DoD pending** (the tank stands **shaded** — clear light/dark
  sides — not fullbright; rotate/relocate and the shading turns with the world sun; `:reload` leaks nothing; `hello`
  regression intact). **Java engine change ⇒ `ant hafen-client` rebuild + a full client restart.** Deferred:
  `emissiveTexture`, `TEXCOORD_1`, sampler wrap/filter, full PBR maps, a tunable per-object reflectance/shine, cel-shading.

- **N1 — `hafen.json` (parse/encode).** ✅ First slice of the **N-series** (data & networking). Exposes the
  client's existing dependency-free JSON reader+writer to Lua as **`hafen.json.parse(str)`** (→ Lua value: objects →
  string-keyed tables, arrays → 1-based; JSON `null`→`nil` = an **absent key** / **array hole**, index still advances;
  integral numbers → Lua **ints**; malformed input or input over the `-D`-tunable **size (8 MB)** / **depth (256)**
  caps → a pcall-able `LuaError`) and **`hafen.json.encode(value)`** (→ compact JSON; **strict** —
  function/userdata/thread/reference-cycle/non-finite number → `LuaError`, so output is always valid JSON, unlike the
  `:lua` REPL echo's forgiving `"<cycle>"`/quoted-tostring/`null`). **Ungated, pure CPU** (no I/O, no permission), on
  the calling thread under the watchdog like any bridge call. **The one refactor (D-013):** the compact writer moved
  out of `AddonManager` into **`Json.write(LuaValue[, strict])`** (beside the reader it mirrors), so the REPL echo,
  `hafen.store` persistence, and `hafen.json.encode` now share **one** serializer (no drift); the JSON→Lua marshal
  centralized into **`LuaMarshal.jsonToLua`** (integer-preserving, explicit `null`→NIL), shared by `hafen.store`
  restore. Caps added to `Json` (depth guard in `object()`/`array()`; length cap at the bridge), `-D`-tunable
  (`haven.addon.json.maxdepth` / `.maxlen`), which also hardens the internal manifest/saved-var callers. **Zero
  `haven` core edit** — three files, all `io.brodgar.addon` (`Json`, `LuaMarshal`, `AddonManager`). Compile OK +
  **27 headless checks** (round-trip; int cleanliness; null→absent-key/hole; malformed pcall-able; depth cap trips /
  shallow passes; strict rejects userdata/inf/cycle; forgiving writer still emits `"<cycle>"`/quoted/`null`; empties;
  escapes; booleans+nesting) + LuaJ parse. `hello` **v0.45.0** (OnLoad self-check round-trips a mixed table). Doc
  `n1-json.md`. **In-game DoD pending** (round-trip from `:lua` + the `hello` OnLoad log; malformed is `pcall`-able).
  **Java engine change ⇒ `ant hafen-client` rebuild + a full client restart.** Deferred: `hafen.http` GET (N2a) +
  POST (N2b), which reuse this `Json.write` for JSON bodies.

- **N2a — `hafen.http.get` + the async/security substrate.** ✅ Second N-series slice — an addon's first network
  access (**GET only**; POST → N2b). **`hafen.http.get(url[,opts],cb)`** → a `{ :cancel() }` handle, **async**: it
  validates + gates synchronously and returns immediately, delivering the reply via **`cb(res)` on the tick**
  (`res={ok,status,body,headers(lower-cased),error}`; `ok`=a reply arrived at ANY status, `!ok`=a transport failure).
  **Threading = the gob-delta pattern:** a shared engine-lifetime bounded **daemon `ExecutorService`** runs the
  blocking `HttpURLConnection` off the UI thread; the worker enqueues an `HttpCompletion` onto a queue **drained on
  the tick** (new step **1a** `drainHttp`, beside `GobEvent`) → `callLua` (armed + isolated). A **non-blocking
  per-addon in-flight scheduler** (`maybeStartHttp`, limit 6) launches queued requests as running ones complete —
  no pool thread ever blocks on a per-addon permit. Handle owned in **`Addon.requests`**, cancelled on teardown/
  `:cancel()` (**callback never fires** — dead-flag discard on drain). **Security (D-037):** the new **`network`
  manifest block** (`Manifest.network`/`usesNetwork()`/`hostAllowed()` — exact ci + `*.domain`; a disk `"*"` is
  rejected, only the internal REPL owner is allow-all) is gated at call by **`requireNetwork`** (synchronous
  `LuaError`); **private/loopback/link-local IP block** on the resolved address (`LuaHttp.isBlockedAddress` via
  `InetAddress` classifiers + a manual `fc00::/7`); caps (size 8 MB / timeout 10 s cap 60 s / in-flight 6 excess
  queued, hard cap 64 / pool 8, all `-D`-tunable); generic UA, no cookies, hop-by-hop request headers stripped
  (`headerAllowed`), TLS verified, **no redirects** (3xx raw). AddOns panel shows a **`[net]` badge + the declared
  hosts** (tooltip) so the user sees them before enabling. **Zero `haven` core edit** — new `LuaHttp` (worker +
  IP/header checks) + `LuaHttpRequest` (handle); edits to `Manifest`/`Addon`/`AddonManager`/`ui.AddonPanel`. Compile
  OK + `ant bin` + **38 headless checks** (manifest network parse; host allowlist exact/wildcard/apex/ci; private-IP
  block across the v4+v6 ranges + public negatives; header hygiene) + LuaJ parse. New dedicated **`netdemo`** example
  addon (`:netdemo get|bad|lan` — allowlisted GET+parse / disallowed-host refuse-at-call / private-IP block). Doc
  `n2a-http-get.md`. **In-game DoD pending.** **Java engine change ⇒ rebuild + full restart.** Deferred → N2b: POST
  (string + table→JSON body), rich request/response headers, redirect-follow with per-hop re-validation; and (§9)
  DNS-rebinding hardening, generic `request{method=}`, non-default ports, streaming.

- **N2b — `hafen.http.post` + redirect-follow.** ✅ Final N-series slice — completes `hafen.http` with the **write**
  verb + real redirect-following, a thin add on the N2a substrate (no new fields/threads/manifest). **`hafen.http.post(
  url, body[,opts], cb)`** → the same `{ :cancel() }` handle: `body` = a **string** (verbatim, UTF-8) or a **table**
  (encoded by the shared strict `Json.write(v,true)` + tagged `Content-Type: application/json` unless the addon set its
  own); nil→empty POST; a non-serializable table → `LuaError` at call. **Redirect-following for BOTH verbs:**
  `LuaHttp.perform` became a `while` hop-loop following ≤5 `3xx` (`301`/`302`/`303`/`307`/`308`; `MAX_REDIRECTS`
  `-D`-tunable), and a new **`validateHop(r,u,redirect)`** **re-checks the allowlist + the private/loopback-IP block on
  every hop** — a redirect to a non-allowlisted or private host aborts (`ok=false`), so a `3xx` can't escape the declared
  hosts; `303`/POST-`301`/`302` demote to `GET`+drop-body, `307`/`308` preserve method+body. `AddonManager` gained the
  `post` facade (arg-parsing mirrors `get`, reuses `httpHost`/`requireNetwork`/`httpHeaders`/`httpTimeout`) + `httpBody`/
  `hasContentType`. **Zero `haven` core edit** — only `LuaHttp` (hop-loop + `validateHop`/`isRedirect`/`MAX_REDIRECTS`)
  + `AddonManager` (facade + body encoder) + a comment in `LuaHttpRequest`. Compile OK + `ant bin` + LuaJ parse; the live
  POST/redirect paths are **in-game-only** (no headless session to drive the tick drain, and redirects need a real
  server 3xx — like N2a). **`netdemo` v0.2.0** (`:netdemo post` POSTs a JSON table to `httpbin.org` + reads the echo;
  `redirect` follows a 3xx to an allowlisted host; `escape` shows a redirect off the allowlist blocked mid-hop; hosts
  list gains `httpbin.org`). Doc `n2b-http-post.md`. **In-game DoD pending.** **Completes the N-series.** **Java engine
  change ⇒ rebuild + full restart.** Deferred (§9): DNS-rebinding hardening, generic `request{method=}`/PUT·DELETE·PATCH,
  non-default ports, streaming/download.

- **U1 — Widget `onDrop` + `g:resource` + mouse `mods`.** ✅ First slice of the **U-series** (UI-API extensions) —
  three additive UI primitives in one build, **zero `haven` core edit**, all ungated. **(a) `onDrop`** (D-038):
  [`LuaWidget`](src/io/brodgar/addon/LuaWidget.java) now `implements DropTarget`; the engine's own generic drop
  dispatch (`DropTarget.Drop` walked by `PointerEvent.propagation`) delivers a menu-grid action to the widget under
  the cursor as `onDrop(x,y,{kind="pagina",res="<name>"})` (widget-local px; truthy consumes) — a **neutral,
  facade-safe descriptor** (a resource name is plain data, so ungated; D-017); `res` is present only for a
  **resource-based** pagina (`pag.id instanceof Indir`, `Loading`-guarded) — an **id-only** pagina carries `kind`
  alone (usable in-session, not reliably persistable across relogs). **(b) `g:resource(name,x,y[,w,h])`** (D-039) on
  the shared [`LuaGOut`](src/io/brodgar/addon/LuaGOut.java) — the `.res` sibling of `g:image`: blits an engine
  resource's **default image layer** (`Resource.imgc` → `Image.tex()`) **by name**, resolved **async + name-cached**
  (a static `LuaGOut` map, cleared on `:reload` via `clearResourceCache()`) + **`Loading`-guarded** (draws nothing
  until ready, then blits; a bad name / load error draws nothing, never throws into the render thread); **static icon
  only** (no live sprite/cooldown — that's the deferred `g:ability`). **(c) mouse `mods`** (D-040): every widget mouse
  callback (`onClick`/`onMouseUp`/`onMouseMove`/`onWheel`) gains a trailing `{shift,ctrl,alt}` boolean table from
  `ui.modflags()` (shared `AddonManager.modsTable`, mirrors `hook.grab`) — branch on the modifier at press time.
  **Zero `haven` core edit** — `LuaWidget`/`LuaGOut` + one line in `AddonManager.reload()`. Compile OK + LuaJ parse of
  `hello`. **`hello` v0.46.0** (a borderless drop-target box below the 2a window: drop a menu-grid action → its icon
  draws via `g:resource` + the `res` logs; Shift+click → `shift=true`). Doc `u1-widget-drops-resource-mods.md`.
  **In-game DoD pending.** **Java engine change ⇒ rebuild + full restart.** Deferred: the menu-ability primitive
  (activate a dropped action — resolvable handle + gated `use`), item drops (`DTarget.drop`/`iteminteract`),
  `g:resource` live sprites (`g:ability`), the `Inventory.invsq` empty-slot `TexI`.

- **W1 — `hafen.ui.root()`/`node(id)` + the `WidgetNode` handle.** ✅ First slice of the **W-series** (widget
  introspection) — a **generic, read-only** walk of *any* widget's children to arbitrary depth from Lua, **zero
  `haven` core edit**, ungated (D-041). **`hafen.ui.root()`** (top of the whole client tree) / **`hafen.ui.node(id)`**
  (by server widget id — a `desc.id`/`model:raw()`/another node's `:id()`; nil if unresolved) + **`model:node()`**
  sugar return an opaque, facade-safe **`WidgetNode`** (new [`LuaWidgetNode`](src/io/brodgar/addon/LuaWidgetNode.java)).
  Handle: `:type()`/**`:id()`** ([`Widget.wdgid()`](src/haven/Widget.java:560), `-1`→nil = client-only — the pivot for
  `hafen.act.raw`)/`:children()` (copy-under-`ui`)/`:parent()`/`:pos()`/`:size()`/`:visible()`/`:text()` (best-effort
  over Label/Button/Window/TextEntry, one localized `nodeText` switch — unknown → nil, never throws)/`:walk(fn)`
  (depth-first, `fn(node,depth)`, return `false` prunes)/`:same(other)` (reference identity — the per-frame guard W2
  needs; fresh handles + no-`:id()` leaves make `==`/`:id()` unusable). A **`GobRef`-style lazy handle**, NOT an
  owned-registry entry (a deep tree mints thousands): `nodeLive` checks liveness per access via
  [`Widget.hasparent(ui.root)`](src/haven/Widget.java:1666) and **nulls the ref once stale** (no pin, no teardown, no
  leak → `:reload` leaks nothing by construction). **Facade-safe** (P1/D-017): no `haven.Widget` crosses to Lua; the
  handle carries the node as an **opaque userdata** (the `LuaImage`/`LuaMarshal` round-trip) so `:same` resolves the
  other handle. **Read-only** — to act, pass a server-bound `:id()` to the gated `hafen.act.raw` (D-025), no new gate.
  All reads on the UI thread under the `ui` monitor. **Zero `haven` core edit** — all backings public; only
  `AddonManager.java` (+ imports Label/Button/Text/TextEntry) + the new `LuaWidgetNode.java`. Compile OK + **7 headless
  facade-safe round-trip checks** (`LuaWidgetNode.resolve`) + LuaJ parse of all addons. **NO example addon**
  (maintainer's request — deviation from §6); verify from the `:lua` REPL. Doc `w1-widget-node.md`. **In-game DoD
  pending.** **Java engine change ⇒ rebuild + full restart.** Deferred to W2: hit-testing (`hafen.ui.at`/`mouse`/
  `node:rootpos`/`node:at`) + the `widgetstack` example addon.

- **W2 — hit-testing: `hafen.ui.at`/`mouse` + `node:rootpos` (the WoW `/framestack` enabler).** ✅ The second and
  final W-series slice (D-042), **zero `haven` core edit**, ungated. **`hafen.ui.mouse()`** → `{x,y}` cursor in root
  coords (public [`UI.mc`](src/haven/UI.java:54)); **`hafen.ui.at(x,y)`** + **`node:at(coord)`** → the **deepest**
  `WidgetNode` under a point (or nil); **`node:rootpos()`** → `{x,y}` top-left in root coords (with `:size()` = a
  highlight box). The core is `AddonManager.hitTest`, a faithful mirror of the engine's own pointer dispatch
  [`PointerEvent.propagation`](src/haven/Widget.java:981) + the leaf `checkhit` of the tooltip walk: iterate children
  `lchild→prev` (**topmost-first**), skip `!visible()`, descend by `xlate(child.c,true)` (so **scroll** offsets
  resolve) + rect-intersect, honour [`checkhit`](src/haven/Widget.java:794) at the leaf (non-rectangular hit areas) —
  so it returns exactly the widget a real click would hit (a naïve `pos..pos+size` test is wrong under scroll /
  custom hit shapes). `hafen.ui.at` starts at `ui.root`; `node:at` converts the root-coord point to node-local via
  [`rootxlate`](src/haven/Widget.java:504) and starts at the node. `onMouseOver` deliberately NOT added (fires only
  on the addon's own widgets; hover = poll `ui.mc` on `OnUpdate`). Read-only/ungated — to act, pass a server-bound
  `:id()` to the gated `hafen.act.raw` (D-025), no new gate. All under the `ui` monitor. **Zero `haven` core edit** —
  all backings public (`UI.mc`, `Widget.lchild/prev/c/sz/visible()/xlate/checkhit/rootpos()/rootxlate`); only
  `AddonManager.java` changed (+ `nodeMouse`/`nodeAt`/`hitTest`/`coordArg` + `:at`/`:rootpos` on the handle). Compile
  OK + **12 headless `hitTest` checks** (topmost-first, deepest-descent, parent-fallback, root-fallback,
  invisible-skip, `checkhit`-fall-through, scroll-via-`xlate`, subtree-miss — via reflection over a hand-built
  `Widget` tree) + LuaJ parse of all 8 addons. Ships the **`widgetstack`** example addon (a dedicated addon, D-031,
  not folded into `hello`) — the `/framestack` clone: on `OnUpdate` it reads `mouse()`+`at()`, applies the **`:same`
  efficiency guard** (rebuild only on hover *change*, a per-rebuild counter that does NOT tick while the cursor sits
  still), walks `:parent()` to the root, shows the stack (type/#id/'text'/WxH, root at top, leaf tinted) in a window
  + outlines the hovered widget via a HUD overlay (`:rootpos()`+`:size()`); `:widgetstack` toggles it, Ctrl+Shift+F
  freezes it. **In-game verified ✅** (stack + highlight render; the maintainer confirmed on a Barter Stand). Then,
  per maintainer request, **widgetstack v0.2.0 added a click-to-inspect INSPECTOR** (pure Lua, no new API): clicking
  any stack row opens an Inspector window with that widget's type/id/pos/size/rootpos/visible/text + a clickable
  parent link + a clickable child list (`:children()`); clicking a child descends / the parent ascends → cascaded
  inspector windows = a fully browsable widget tree. Doc `w2-hit-testing.md`. **In-game verified ✅** (inspector
  browses the tree; maintainer confirmed). **Java engine change ⇒ rebuild + full restart.**
  **This completes the W-series** (and, with it, the current task queue). Deferred: a generic native `onMouseOver`
  (out of scope, D-042); a built-in `:inspect` helper (`widgetstack` covers it in pure Lua).

- **F1 — `hafen.font.*` foundation: registry + provider + the `"default"` scope.** ✅ First slice of the **F-series**
  (per-addon typography, D-043) — an addon loads a **private font handle** and installs an **owned override** on the
  global default surface, restyling most UI text **live** and reverting on `:reload`/disable. **`hafen.font.load(
  source[,opts])`** → an opaque, facade-safe **`FontHandle`** (built-in `sans`/`serif`/`mono`/`fraktur`, or a
  sandboxed addon-folder `.ttf`/`.otf` via `Font.createFont` + AWT `registerFont` for `$font` in F2; opts
  `size`/`aa`/`bold`/`italic`/`color`; `:derive`/`:family`/`:size`). New **`haven.Fonts` provider** holds the
  **owner-tagged override registry** (owner = an opaque `Object` = the `Addon`, so `Text`/`Label` gain **no**
  `io.brodgar` dependency — a small deliberate deviation from the "FontApi owns the registry" sketch, kept the core
  clean) + a **`gen`** counter + a lock-free `active` fast path; **`foundry(scope, stock)`** resolves
  scope-override → `"default"` cascade → `stock` (**last-wins**), caching the built foundry per stock. Routed the
  **`"default"` consumers** — [`Text.render`](src/haven/Text.java:359)/`renderf` statics + [`Label`](src/haven/Label.java:61)
  default (its `f` made **non-final** + a `draw()`-time `restyle()` that re-renders on a `gen` bump, wrap/colour
  preserved) — through `Fonts.foundry("default", std)`. New `io.brodgar.addon.{FontApi, FontHandle}` (opaque handle
  like `LuaImage`; reuses `RenderApi.resolveAddonAsset` + `luaColor`); `setFont`/`reset`/`scopes` + an owned
  `Addon.fontOverrides` list reverted on teardown (`Fonts.removeOwner` bumps `gen`). **3 tagged core edits**
  (`Text.java` ×2 statics, `Label.java`). Clean compile + **24 headless provider checks** (stock identity / scope
  enum / `gen` / family resolution / foundry cache / cascade / last-wins / per-scope refine / `reset` resurface +
  false-for-unset / `removeOwner` all-scopes / empty→fast-path) + LuaJ parse. `hello` **v0.47.0** (loads
  `fonts/demo.ttf` if bundled else built-in `serif`; `:hello font` flips `"default"` + a mono last-wins demo). Doc
  `f1-fonts.md`. **Committed `521fe32b`.** **⚠ Coverage decision (maintainer):** F1's `"default"` reaches
  `Text.render` callers (incl. addon `g:text` via `GOut.text`) + default `Label`s ONLY — the native chrome
  (buttons `Button.tf`, tooltips `RichText.stdf`, window titles fraktur, menus/chat/textentry) uses **dedicated
  foundries** and does NOT change until F3/F4 route each site (they then cascade to `"default"` when their scope is
  unset). Accepted as-is; broad native coverage is F3/F4's job. Deferred: bundling a real licensed `.ttf` (code path
  ready — drop one at `addons/hello/fonts/demo.ttf`); F2–F5.

- **F2 — own-widget fonts + draw wrapper + `$font` custom families.** ✅ The **isolated** half of the F-series
  (spec 21 "Apply to YOUR OWN drawing", D-043): apply a loaded `FontHandle` to the addon's OWN drawing — no
  global state, no override stack, nothing to revert (unlike F1's `setFont`). **(a)** a **`font =` opt** on
  `hafen.ui.window`/`widget` = the default font for that widget's `g:text`/`g:atext` draws (NOT the title bar →
  F3's `window.title`). **(b)** a per-call **`g:text(str, x, y [, {font=h, color=…}])`** / `g:atext(…, {…})`
  option. **Kept POSITIONAL coords** (the shipped 2a canon + ~30 call sites across all addons; the trailing opts
  are additive, zero breakage) — a deliberate deviation from the spec's `pos`-table sketch, one-canonical-way
  (D-012) preserved. **(c)** a custom TTF in the engine's existing **`$font[h:family(),sz]{…}`** tag — the family
  was AWT-registered at `load` (F1), so **zero `RichText` edit**. Mechanism: `g:text`/`atext` take the **exact
  stock path** for plain text with no font/markup (verified: no shipped addon draws `$`/`{`/`}`/`\`), and a
  **`RichText.Foundry`** path when a font handle OR `$`-markup is present (so `$font`/`$col`/`$b`/`$i`/`$u`/`$size`
  all work); glyphs render WHITE and the colour (per-call `color`, else the handle's, else none) tints on blit
  (composes with `g:color` unchanged), so foundries stay colour-agnostic and cache (`FontHandle.rich(px)` per-px
  + a lazy static `stockRich`). Malformed markup falls back to the literal string — never throws into the render
  thread. **ZERO `haven` core edit** — only `io.brodgar.addon` (`FontHandle` +`rich`; `LuaGOut` default-font
  `bind`/`drawText`/`blitText`/`stockRich`; one line in `LuaWidget`), all over public `GOut`/`Text`/`RichText`
  API. Clean compile + `ant bin` + LuaJ parse of all addons; the text-render path is a **headless resource skip**
  (`ui/fraktur` absent → `Text`/`RichText` `<clinit>` can't run, like A8/A10/R2a) → verified in-game. `hello`
  **v0.48.0** (a new "F2 (fonts)" window in its own font + one line mixing two fonts via `$font`). Doc
  `f2-fonts.md`. **In-game verified ✅. Committed `0e96ac09`.**

- **F3a — the `"window.title"` font scope (window captions).** ✅ First of the F3 chrome-scope split (F3a…F3d).
  Routes `Window.DefaultDeco`'s caption furnaces through the F1 provider: `cf`/`ncf`
  (`BlurFurn(TexFurn(Text.Foundry(fraktur,15), ctex), …)`) are no longer `static final` — a new
  **`checktitlefont()`** rebuilds them from **`Fonts.foundry("window.title", titlefnd)`** (new stock
  `Text.Foundry titlefnd`) whenever `Fonts.gen()` moves, and a per-instance **`capgen`** invalidates each window's
  cached `cap` on the same check → `setFont("window.title", h)` restyles captions **live**, `:reload`/`reset`
  restores stock. Reuses F1's resolution unchanged (a `window.title` override refines ONLY captions;
  `setFont("default", h)` restyles captions TOO via the cascade). **2 tagged core edits, both in `Window.java`**
  (no new class, no `io.brodgar` edit). Compile OK + **8 headless provider-resolution checks** (no-override→stock
  / default-cascade / scope-refine / last-wins / gen-bump / teardown-fallback→stock) + LuaJ parse; the caption
  render is a **headless resource skip** (needs `ctex` + a `Text` toolkit, like A8/A10/R2a/F2) → verified in-game.
  `hello` **v0.49.0** (`:hello title` toggles the scope independently; `:hello font` now also restyles captions
  via cascade). Doc `f3a-window-title-font.md`. **In-game DoD pending.**

**Core files touched so far (haven):** `MapView.java` (Phase 0 attach/detach; **V1 the `addClientGob`/
`removeClientGob` client-gob scene seam; V2 the `Click.hit` ghost-click consume-before-`wdgmsg` intercept**),
`RemoteUI.java`, `Console.java`, `build.xml`
(unchanged since 1b), **`UI.java`** (1d-1 inbound-`uimsg` tap; 2d outbound-`wdgmsg` action hook + `rawWdgmsg`;
**2e-1 inbound-`uimsg` message hook** in `UiMessage.run`; **3a widget-create seams** — `onWidgetCreated` in
`NewWidget.run` + `onWidgetPlaced` in `AddWidget.run`), **`AddonWidgets.java`** (1d-1 new, `haven`-package
accessor; +`buffDest` in 1d-2; **+`gridWorldUL` in V4** — grid-by-stable-id read for `map.fromGridPos`, zero `MCache` edit), **`OptWnd.java`** (1f-3 — ONE `// addon:` line: the AddOns-panel button; **2e-3
— a second `// addon:` block: the per-addon hotkey sections in `BindingPanel`**), **`KeyBinding.java`** (**2e-3 —
one `// addon:` block: keybinding exclusivity in `set()`**, a client-wide fix), **`Text.java`** (**F1 — two
`// addon:` one-liners routing the `render`/`renderf` statics through `Fonts.foundry("default", std)`**),
**`Label.java`** (**F1 — `// addon:` default ctors follow the `"default"` scope; `f` made non-final + a `draw()`
`restyle()` on a `gen` bump**), **`Fonts.java`** (**F1 new — the `haven`-reachable font provider: owner-tagged
override registry + `gen` + `foundry(scope, stock)`; owner tokens opaque so no `io.brodgar` dep**),
**`Window.java`** (**F3a — two `// addon:` edits: `DefaultDeco.cf`/`ncf` caption furnaces rebuilt from
`Fonts.foundry("window.title", titlefnd)` via `checktitlefont()`; per-instance `capgen` re-renders the cached
`cap` on a `gen` bump**).
**1d-3, 1d-4, 1e, 1f-1, 1f-2, 2a, 2b, 2c, 2e-2, 3b, 3c, A1, A4, A2, A11, A6, A7, A8, A9-1, A9-2, A10, 4a, 4b, 4c, 4d, 4e, 4f, 4g, V3–V6, R1, R2a, R2b, R3a, R3b-1, R3b-2, R3c, U1, W1, W2 and F2 added no `haven` edit** (all engine-package; **F2 = own-widget fonts (`font=` +
`g:text{font=,color=}` + `$font` custom families) entirely over public `GOut`/`Text`/`RichText` API**; **R1 = `hafen.render.image` PNG→`TexI` + `g:image`/`g:aimage`, all backings public — `GOut.image`/`aimage`, `new TexI`, `ImageIO`**; **R2a/R2b/R3a/R3b-1/R3c stand a PNG quad / camera-facing billboard / glTF mesh on the shared world-entity core, all render primitives public — `Homo3D.vertex`/`Homo3D.normal`/`Tex2D.texc`, `Model`/`VertexArray`/`Model.Indices`, `Material`/`BaseColor`/`TexRender`/`Light.PhongLight`, `SprDrawable`, `PView.Render2D`; R3a's `Gltf` parser is pure `Json`+`Matrix4f`/`Coord3f` math, no native deps; R3c bakes `NORMAL` (inverse-transpose) + `emissiveFactor` in that same pure parser and adds `Light.PhongLight` so the scene's world lights shade the mesh; R3b-2 is Lua-only — `addons/planner/` gains `:planner object` on the shared handle**; **4f addresses items by a HANDLE = `GItem.wdgid()`, re-resolved via public `UI.getwidget`; all item backings public**; **3c reuses
3a's `UI.java` widget-create seams**; **A1 reads the map DB entirely through public `MapFile`/`MapWnd`/`MiniMap` members**;
**A4 reads `SkillWnd` entirely through public `skg`/`credos`/`exps` members**; **A2 reads+writes `GobIcon.Settings`
entirely through public `GameUI.iconconf`/`settings`/`dsave`/`Setting` members**; **A11 reuses the public
`Console.setscmd`/`findcmd` seam — one engine-lifetime dispatcher per name, C1**; **A6 reads `BuddyWnd`
(`GameUI.buddies`) via public `iterator()`/`find`/`Buddy` fields/`gc`, uimsg-driven over the 1d-1 tap**;
**A9-1 reads `QuestWnd` (`CharWnd.quest`) via public `cqst`/`dqst`/`quest`/`Quest`/`Box`/`Condition` members,
uimsg-driven over the 1d-1 tap + a pure `questDiff`**; **A9-2 reads `WoundWnd` (`CharWnd.wound`) via public
`wounds`/`WoundList.wounds`/`Wound`/`QuickInfo` members, poll-driven (severity streams in) + a pure `woundListEqual`**;
**A10 reads `FightWnd` (`CharWnd.fight`) via public `acts`/`order`/`keys`/`maxact`/`usesave`/`nsave`/`Action` members,
read-on-demand (no event), copy-under-`ui`-lock**);
**2d added the second `UI.java` edit region, 2e-1 added a third, 3a a fourth
(the `NewWidget.run` + `AddWidget.run` widget-create seams), 2e-3 added the second `OptWnd.java` edit + the first
`KeyBinding.java` edit, and V1 added the first `MapView.java` edit since Phase 0** (the `addClientGob`/
`removeClientGob` client-gob seam; V2 will add a second at `Click.hit`) (all D-011, all minimal + `// addon:`).
**Engine package:** `io.brodgar.addon.{AddonManager, Addon, Manifest, Json, AddonRoot,
Sandbox, LuaWidget, LuaGOut, LuaGobOverlay, LuaInputHook, LuaActionHook, LuaMarshal, LuaMessageHook, LuaKeyBind, LuaWidgetObserver, LuaModel, LuaReplacer, LuaSlashCommand, LuaGhost}`
(`Sandbox` new in 1f-1, `LuaWidget` new in 2a, **`LuaGOut`** [shared `g` wrapper; **+`g:poly` filled-triangle in
V5b**, zero core edit via public `GOut.drawp`/`tx`] + **`LuaGobOverlay`**
[gob-overlay attrib] new in 2b, **`LuaInputHook`** [L1 input-hook listener] new in 2c, **`LuaActionHook`** [L2
action-hook] new in 2d, **`LuaMarshal`** [shared arg marshalling] + **`LuaMessageHook`** [L3 message-hook] new
in 2e-1, **`LuaKeyBind`** [global-hotkey binding] new in 2e-2, **`LuaWidgetObserver`** [widget-create observer]
new in 3a, **`LuaModel`** [adopted-widget model] new in 3b, **`LuaReplacer`** [widget replacer] new in 3c;
`AddonRoot` gained a `globtype` override in 2e-2;
`AddonManager` gained the read-only `describeKeyBinds()` + `KeyBindGroup`/`KeyBindEntry` for the panel in 2e-3;
**`LuaSlashCommand`** [addon slash command] new in A11; **`LuaGhost`** [client-only world-ghost handle] new in V1;
**`LuaMouseGrab`** [drag-capture widget] new in V5a; **`LuaImage`** [custom-image handle, `hafen.render.image`] new in R1
— **`LuaGOut` gained `g:image`/`g:aimage`, zero core edit**; **`LuaWidgetNode`** [generic widget-tree node,
`hafen.ui.root`/`node`] new in W1 — **facade-safe opaque handle, zero core edit**) +
**`io.brodgar.addon.ui.{AddonPanel, ActionsConsentWnd}`** (1f-3 — the options panel; **`ActionsConsentWnd`** — the
4c enable-time write-actions consent dialog).
**Example addons:** `hello` (the standing **read-only** regression harness, **v0.38.0** — write demo moved out in 4b;
**4f: logs the new item `handle`**; **V1: spawns/moves/destroys a client-only ghost cabin**; **R1: loads `icon.png`
and draws it in the 2a window (native+scaled) + 2b HUD overlay (anchored)**), `hogtest` (dormant CPU-budget demo, 1f-3), **`bags`** (dormant inventory-
replacement demo, 3c), **`walker`** (dormant, opt-in **write-actions** demo, 4b/4d/4e/4f/4g — declares `"actions"`,
default-disabled; **v0.6.0** `:walker` sub-commands `walk`/`click`/`use`/`sel`/`place`/`raw` (gated `hafen.act`
MapView verbs) + `menu`/`flower` (4e) + `item` (4f) + **`speed`/`craft`/`bar`/`kin` (4g per-subsystem verbs)**),
**`planner`** (the V-series ghost example, default-enabled, no permissions; **v0.4.0** — place/select/persist
grid-anchored blueprint ghosts (V4) + `:planner grab` body-move (V5a) + **`:planner gizmo [mode]`** the Unity-style
transform gizmo, `gizmo.lua` bundled library — **move (V5b) + rotate ring + scale box (V6, `mode`
move/rotate/scale/all)**; `:planner rotate`/`scale` set facing/scale directly, both **persisted** grid-anchored).

---

## 6. Per-task procedure (do this EVERY prompt)

1. **Read this PLAN.md.** Identify the **first unchecked task** in §7.
2. **Read the specs it names** (+ `code-map.md` for exact backings; verify class/method names still
   exist before using them).
3. **Implement.** New code in `io.brodgar.addon`; core edits minimal and tagged `// addon:`. Follow
   the API decisions (§1). Reuse the voice-integration pattern.
4. **Verify:** `ant hafen-client` → `BUILD SUCCESSFUL`; add `jshell`/logic checks where feasible.
   **Extend the `hello` addon** (`addons/hello/`) to exercise the new feature — it is our standing
   **test + regression harness** and grows every task, so one in-game login re-checks that *all*
   prior features still work. If a feature is too big/distinct to fold into `hello` cleanly,
   **propose a dedicated example addon** instead of bloating it.
5. **Document (TWO tiers, before any commit — never mix them):**
   - **Devlog** — a per-task note in **`docs/addons/devlog/<task>.md`** (history: rationale, threading,
     exact code changes), styled like the existing `phase-*`/`a*` entries; add it to `devlog/README.md`.
   - **Real API reference** — create/update **`docs/addons/api/*.md`** for the shipped surface (+ the
     `api/README.md` section index and the top `docs/addons/README.md` "API at a glance" table the first
     time a new section ships). `api/` = the living reference of what's built; `devlog/` = history.
   A pure-infra slice with no public surface may get only a devlog note.
6. **Update THIS file:** tick the task in §7, move a summary to §5 (STATUS), append any learnings to
   §8, and refine the next task if you discovered something.
7. **STOP and report** to the maintainer: what changed, **how to test it in-game**, and a **proposed
   commit message**. **Do NOT commit. Do NOT push. Do NOT start a second task.** Wait.

---

## 7. TASK QUEUE — do the FIRST unchecked task, then update

Order follows `15-implementation-plan.md` + `decisions.md` D-026. Each task references its spec.

- [x] **1b — Tick pump + core events + timers.** ✅ (see STATUS §5; doc `phase-1b-events-timers.md`)
  Invisible `AddonRoot` widget on `ui.root` drives `AddonManager.tick(dt)` each frame (UI thread,
  zero core edit). `hafen.events.on/​:off` fires `OnLoad`/`OnEnterWorld`/`OnUpdate`/`OnDisable`/
  `GobAdded`/`GobRemoved` (gob deltas marshalled off the network thread via a queue drained on tick).
  `hafen.timer.after/every`→`:cancel()`. Per-handler error isolation; per-addon owned-resource
  registry (`Addon.subs`/`timers`). Headless test passed. **In-game DoD check still pending.**

- **1c — Full Glob-backed read API.** *(Split into 3 slices — too big for one prompt/verification.)*
  Respect threading (`synchronized(oc)`+copy, per-gob lock, swallow `Loading`). Specs:
  `api-reference.md`, `code-map.md`. **DoD (per slice):** read examples work from `:lua` and an addon.

  - [x] **1c-1 — gob + world reads.** ✅ `hafen.gob.*(ref)` (exists/info/pos/facing/name/health/
    moving/speed/speech/icon/distance) + `hafen.world.*` (gobs/count/nearest/within, string- or
    function-filter). Centralized GobRef `resolve` (id/"player"/"me"/nil; unknown tokens → nil), full
    `gobSnapshot`, Loading-guarded per-attribute readers; `GobAdded`/`GobRemoved` now carry the full
    snapshot. **Zero core edit** (OCache/Gob via existing session hooks). Compile + 20 headless checks
    passed. Doc `phase-1c-read-gobs.md`. **In-game verified ✅** (+ `:lua` REPL now echoes to stdout).
  - [x] **1c-2 — map + player + time + sound.** ✅ `hafen.map` (tile/height/grid/gridPos +
    worldToTile/tileToWorld/tileToGrid — MCache; grid ids are exact **strings**; world-unit args),
    `hafen.player` (exists/id/name via `GameUI.chrid`; worldToScreen via `MapView.screenxf`),
    `hafen.time` (clock/dayFraction/isNight/season/moon/yearFraction — `Glob.globtime`+`Astronomy`,
    `ast`-nil-guarded), `hafen.sound.play` + `hafen.music.play` (resource resolve/defer to dodge
    `Loading`, mirroring `GobIcon.resnotif`). **Zero core edit.** Compile + 13 headless coord-math
    checks passed. **In-game verified ✅**: `map.tile`→`gfx/tiles/grass`, `gridPos().gridId`→exact
    64-bit string, `map.height`→number, `player.name()`→char name (resolves inside `OnEnterWorld`),
    `worldToScreen(player)`→~screen-centre, `time.isNight()`→true, sound ping OK. **`OnEnterWorld`
    retimed** to fire once the HUD (`GameUI`) is up (so GameUI-backed reads work in-handler; also
    de-risks 1c-3). Doc `phase-1c2-map-player-time-sound.md`. Deferred: `player.vitals` (→1d, private
    meters), `grid().seg` (→A1, MapFile).
  - [x] **1c-3 — items + char + party.** ✅ `hafen.items.*` (inventory/equipment/hand/find — item
    data as **snapshots**: `{res,name,num,wear,pos,slot}`; reads walk the `WItem` children of the
    `Inventory`/`Equipory` widgets, NOT their package-private `wmap` → **zero core edit**),
    `hafen.char.*` (attr/attrs via `Glob.getcattr` treating zero-info as nil; **lp/weight now done
    too** via public live `CharWnd.exp`/`enc` — no widget-tree needed), `hafen.party.*`
    (members/leader/member — `Glob.party`, ordered by `Member.seq`, color `{r,g,b,a}`, no name field).
    Also wired the **`"partyN"` GobRef token** into `resolve()`. Compile OK + LuaJ parse.
    **In-game verified ✅** (inventory/equipment/find/hand/attrs/lp/weight/party/`gob.pos("party1")` all
    correct; char + inventory **stream in after `OnEnterWorld`** — `hello` re-reads at +3s). Doc
    `phase-1c3-items-char-party.md`. Deferred: item `quality`/`contents`, per-item accessor fns (→ item
    handles, UI phase), FEP/food/skills (→1d).

- **1d — Widget-tree read mechanism (vitals/buffs/char sheet/FEP/action bar/equip).** *(Split by adapter —
  too big for one prompt/verification, like 1c.)* Implement `14-widget-tree-reads.md`: Locator +
  per-type Adapters + inbound-`uimsg` hook → semantic events (`VitalsChanged`, `BuffAdded/Removed`,
  `FepChanged`, …). Needs the inbound `uimsg` core tap and (for private/protected fields) a small
  `haven`-package accessor. Specs: `14-widget-tree-reads.md`, `coverage-gaps.md` B1/B5/C2.

  - [x] **1d-1 — Foundation + vitals.** ✅ The mechanism itself (Locator via `gui()` + `children(Class)`,
    a `TreeAdapter` abstraction, the **inbound-`uimsg` core tap** in `UI.UiMessage.run` → marshalled to
    the tick → semantic event, and the **`haven`-package accessor** `AddonWidgets` for protected
    fields) + the first adapter: **`hafen.player.vitals()`** (`{hp,stamina,energy}` 0..1 from the HUD
    `IMeter`s via `AddonWidgets.meters`, positional mapping) + the **`VitalsChanged`** event (change-
    detected). **Two core edits** (first non-zero-edit reads, per B5): `UI.java` uimsg tap + new
    `AddonWidgets.java`. Compile OK + 8 headless change-detection checks + LuaJ parse. Doc
    `phase-1d1-vitals-widget-tree.md`. **In-game verified ✅** (positional mapping correct; `VitalsChanged`
    fires on stream-in + live drain). Deferred to later slices: buffs, FEP/food, study, skills, action bar, equip events.
  - [x] **1d-2 — Buffs + FEP/food/hunger.** ✅ `hafen.buffs.list/has` (`GameUI.buffs` → `children(
    Buff.class)`; snapshot `{res,name,amount,cooldown,number}` — amount/cooldown/number via
    `ItemInfo.find` over `Buff.info()`, 0..1/int, often nil) + `BuffAdded`/`BuffRemoved`/`BuffChanged`,
    and `hafen.char.food()` (`{fep={cap,total,entries},hunger={level,label,efficacy}}` — `BAttrWnd`
    located via **public `CharWnd.battr`**, `feps`/`glut` all public fields) + `FepChanged`. New
    mechanism piece: a **per-tick `poll()`** (default no-op) on `TreeAdapter` — buff **add/remove** is
    a widget create/`cdestroy`, NOT a uimsg, so `BuffsAdapter` diffs `children(Buff.class)` each tick;
    buff **content** ("ch"/"tt") + FEP ("food"/"glut") still ride the 1d-1 uimsg tap. **One 3-line
    core edit** (`AddonWidgets.buffDest` — the `protected Buff.dest` fade flag, so removed buffs are
    omitted/timely); FEP is **zero haven-edit** (all public). Compile OK + 11 headless change-detect
    checks + LuaJ parse. Doc `phase-1d2-buffs-food.md`. **In-game DoD check pending.** Deferred:
    seconds buff timers (don't exist), rawinfo-rich buff names.
  - [x] **1d-3 — Study/curiosity + skills.** ✅ `hafen.study.slots()` (curiosity snapshots `{res,name,
    lp,attention,cost,time,progress?}` from the study inventory's `GItem` children + their
    `resutil.Curiosity` info) + `hafen.study.summary()` (`{lp,attention,cost}` live totals from
    `SAttrWnd.StudyInfo`) + **`StudyChanged`** (poll-driven, like buffs — study add/remove is a widget
    create/`cdestroy`, not a uimsg), and `hafen.char.skills()`/`skill(name)` (known skills `{name,res}`
    from `SkillWnd.skg.csk`; `skill` = substring membership). **Zero core edit** — all reads are public
    (`CharWnd.sattr`/`skill`, `SAttrWnd.StudyInfo.study/texp/tw/tenc`, `SkillWnd.skg.csk.items`,
    `Skill.nm/res`, `Curiosity.exp/mw/enc/time`, `GItem.res/meter/info()`), so 1d-1's `UI.java` tap +
    `AddonWidgets` are untouched; only `AddonManager.java` changed. Compile OK + 15 headless
    change-detection checks (`studySlotsEqual`) + LuaJ parse. `hello` bumped to v0.8.0. Doc
    `phase-1d3-study-skills.md`. **In-game verified ✅** (3 slots, `StudyChanged` streamed `0→1→3`,
    `summary` `lp=25567 att=8 cost=1`, 40 skills, `skill("Alchemy")`→true; two "A Bond of Blood & Soil"
    bonds carry no `Curiosity` → `{res,name}` only, contribute 0 to totals — faithful). Deferred:
    per-item "time left" (client has none — only total `time`), `SkillsChanged` (skills change rarely),
    credos/experiences (other `SkillWnd` tabs).
  - [x] **1d-4 — Action bar (read) + equip-change event.** ✅ **API = `hafen.actionbar`** (the engine
    calls it the "belt" — `GameUI.belt`; renamed for the addon API to avoid the worn-belt confusion).
    `hafen.actionbar.slot(n)` (`GameUI.belt` `BeltSlot[144]` → `{res,name,cooldown}`; **raw 0-based game
    index 0..143**, the index `actionbar.use` takes in Phase 4; `cooldown` = pagina `PagButton.meter`
    0..1, present only on ability slots, **not seconds**) → **`ActionbarChanged{n}`**, and an
    **`EquipChanged`** event (payload = the equipment array) over the 1c-3 equipment read. **Both
    poll-driven** (like buffs/study): a slot set/clear mutates `belt[]` on a **deferred loader task**
    (racing a uimsg refresh) and equip/unequip is a widget create/`cdestroy` — neither is a trustworthy
    targeted uimsg, so `ActionbarAdapter`/`EquipAdapter` diff each tick. Change-detection excludes
    `cooldown` (action bar) / `wear` (equip) so a live meter / durability drift doesn't spam. **Zero
    `haven` edit** — all reads public (`GameUI.belt`, `ResBeltSlot.getres`/`PagBeltSlot.pag`,
    `Pagina.res/button`, `PagButton.name/meter`, `Equipory.children`); only `AddonManager.java` changed
    (`hafen.items.equipment` refactored onto a shared `readEquipment`). Compile OK + 19 headless
    change-detection checks (`actionbarEqual`/`equipEqual`) + LuaJ parse. `hello` bumped to v0.9.0. Doc
    `phase-1d4-actionbar-equip.md`. **In-game DoD check pending** (maintainer's first run already showed
    `ActionbarChanged` on stream-in + a manual slot clear). Deferred: `actionbar.use` (Phase 4), per-slot
    EquipChanged granularity. **This completes Phase 1d** (widget-tree read surfaces).

- [x] **1e — Saved variables (`hafen.store`).** ✅ (see STATUS §5; doc `phase-1e-saved-variables.md`)
  `hafen.store.<name>` proxy tables (manifest `saved_variables`) + `hafen.store.flush()`, persisted as
  compact JSON under `savedata/<genus>_<char>/<addon>.json` (account scope → `savedata/account/`), reusing
  the REPL `json()` writer + the `Json` reader. Account vars load before `OnLoad`; **per-char vars load at
  OnEnterWorld** (the `<genus>_<char>` folder is unknown at `RemoteUI.init`); flush on `OnDisable`/teardown
  (relog) + 30 s throttled auto-save (write-skip on unchanged). **Zero `haven` edit.** Compile + 19 headless
  end-to-end checks (write→relog→read→increment→relog, array round-trip, write-skip, scopeKey) + LuaJ parse.
  `hello` v0.10.0. **In-game DoD check pending** (relog → counter increments).

- **1f — Sandbox + Reload UI + AddOns options panel.** *(Split into 3 slices — three distinct pieces,
  like 1c/1d; too big for one prompt + one in-game verification.)* Specs:
  `12-security-and-permissions.md`, `05-lifecycle-and-reload.md`, `10-options-panel.md`, `04-engine.md`.

  - [x] **1f-1 — Lua sandbox (strict env + instruction watchdog).** ✅ New `io.brodgar.addon.Sandbox`:
    a **constructive whitelist** env (D-017) — `Sandbox.create()` loads only safe libs (`string/table/
    math`, trimmed `os`, safe base fns) so `io`/`luajava`(Java-reflection escape hatch)/`debug`/`require`/
    `package`/`load*` are **absent by construction**; `os.execute/exit/getenv/remove/rename/tmpname/
    setlocale` + base `load*` stripped — plus the **instruction hard-stop watchdog** (D-018 layer 1): a
    `DebugLib` **assigned** to `Globals.debuglib` (not `load()`-ed, so no `debug` table) whose
    `onInstruction` enforces a per-call budget (`-Dhaven.addon.insncap`, default 10 M ≈ **~36 ms** to
    abort a tight loop; `onCall`/`onReturn`/`traceback` no-op'd to dodge the null-globals error-hook NPE).
    `Sandbox.arm(env)` resets the budget before **every** entry into Lua (`callLua`, `Addon.run`, REPL
    `eval`). The **`:lua` REPL stays full `standardGlobals()`** (trusted operator console) + watchdog.
    **Zero `haven` edit** (pure engine): edits `AddonManager` (loadAll/console/callLua/eval), `Addon.run`,
    new `Sandbox.java`. Compile OK + **49 headless checks** (withheld absent / whitelisted present /
    watchdog aborts loop in env+console / bounded loop no false-trip) + LuaJ parse of `hello`. `hello`
    v0.11.0 (self-checks the sandbox at OnLoad). Doc `phase-1f1-sandbox.md`. **In-game verified ✅**
    (log showed all withheld surfaces absent + `os.execute usable=false`; `:lua while true do end`
    aborted with the watchdog error, no freeze; manifest `version` synced to 0.11.0). Deferred: D-018 **soft
    per-tick budget + auto-disable** (→1f-3, pairs with the panel warning), controlled addon-folder
    `require`, per-env string metatable.
  - [x] **1f-2 — Reload UI + enabled-set.** ✅ **`:reload`** rebuilds the **addon layer only** (D-005):
    teardown all (reverse order — `OnDisable` → flush saved vars → drop subs/timers, reusing the relogin
    `teardown`) → re-scan `addons/` + enabled set → re-run enabled → `OnLoad` → (in-world) restore per-char
    vars + re-fire `OnEnterWorld` (WoW `PLAYER_LOGIN`). **Queued to the UI-thread tick** (`reloadPending`,
    like `enterWorldPending`) so it's thread-safe from either console (in-game UI thread / stdin thread);
    `reload()` is `synchronized` (serializes with `init`). The **enabled set** is a persisted **disabled
    set** (default-enabled, WoW) in client prefs (`Utils.getprefsl`, key `addons/disabled`); `loadAll`
    skips disabled. Console: `:addons` (list+status), `:addons enable/disable <id>` (pending until reload).
    Session infra (tick pump / OCache cb / uimsg tap) untouched. **Zero `haven` edit** (only
    `AddonManager.java`). Compile OK + 14 headless enabled-set checks (isolated prefs node) + LuaJ parse.
    `hello` v0.12.0 (reload marker + `acct.loads` counter). Doc `phase-1f2-reload-enabled-set.md`.
    **In-game DoD pending:** edit a `.lua`, `:reload`, change appears without relog; disable→reload skips it;
    no leaks. Deferred: `:reload <id>` / live enable-disable (→ later), the panel + `synchronized(ui)`
    widget teardown (→1f-3 / Phase 2).
  - [x] **1f-3 — AddOns options panel + watchdog soft-budget/auto-disable.** ✅ **AddOns panel** =
    new **`io.brodgar.addon.ui.AddonPanel`** (spec 10's intended home — clones the voice
    `OptWnd.VoiceChatPanel` pattern but lives in the addon package; extends `OptWnd.Panel` cross-package
    via `opt.super()`/`opt.new PButton(...)`, drives the all-static `AddonManager` facade, needs zero
    package-private `haven` access). Per-row: **enable/disable checkbox** (→ 1f-2 `setEnabled`, apply on
    reload D-006), name/version/author + description tooltip, and a **live status** (loaded/disabled/
    error/**auto-disabled**); global **Reload UI** / **Enable all** / **Open addons folder** + a "changes
    pending" hint. Polls the facade (no listener → no leak); rebuilds rows on `reloadGen()` change. **Soft
    CPU budget (D-018 layer 2):** `callLua` times each entry into `tickLuaNanos`; `tick` zeroes it, and
    `enforceSoftBudget()` auto-disables an addon over `Sandbox.SOFT_BUDGET_NANOS` (10ms) for
    `SOFT_STRIKE_LIMIT` (30) **consecutive** ticks (strict `>`; one under-budget tick resets — must be
    sustained) — session-only teardown (NOT the persisted set; cleared on reload), REPL exempt.
    **One `haven` edit** (one `// addon:` line in `OptWnd`); rest is engine + the new `ui` package + the
    new **`hogtest`** addon (dormant; account var `cfg.arm`, default false → arm+`:reload` to demo).
    Compile OK + **16 headless checks** + LuaJ parse of hogtest. Doc
    `phase-1f3-options-panel-soft-budget.md`. **In-game DoD pending.** **Completes Phase 1f.** Deferred:
    live enable/disable, per-addon config sub-panel (Phase 2), string-metatable hardening.

- **2 — Custom UI + hooks.** *(Split into slices — too big for one prompt/verification, like 1c/1d/1f.)*
  `hafen.ui` (`LuaWidget` + `GOut` wrapper + `overlay` + input) and `hafen.hook`
  (`input`/`action`/`message`, pre/post/replace, `preventDefault`). Specs: `07-ui-and-drawing.md`,
  `13-hooks-and-interception.md`. **DoD (overall):** a draggable custom window + a `hook.action("click")` demo.

  - [x] **2a — Custom widgets/windows + GOut draw wrapper.** ✅ `hafen.ui.window(opts)` (a draggable, titled
    `haven.Window` wrapping a content widget) + `hafen.ui.widget(opts)` (a bare content widget), returning a
    handle (`:move/:show/:hide/:visible/:pack/:size/:destroy`). New **`io.brodgar.addon.LuaWidget extends
    Widget`** forwards `tick`/`draw`/`mousedown`/`mouseup`/`mousemove`/`mousewheel` to Lua callbacks
    (`onDraw(g,w,h)`/`onTick(dt)`/`onClick(x,y,button)`→truthy consumes/`onMouseUp`/`onMouseMove`/`onWheel`/
    `onClose`) through `callLua` (watchdog + isolation + CPU-accounting). The **`g` GOut wrapper**
    (`text/atext/rect/frect/line/prect/color`) is bound only during `onDraw` (inert otherwise → can't corrupt
    the pipeline); `image` deferred. Windows are **composition** (a plain `Window` + a `LuaWidget` child) so
    forwarding lives in one class; `reqclose` redirected to `onClose`+destroy (client-side, no server). New
    owned-resource list `Addon.widgets` (torn down on reload/disable, `synchronized(ui)`); `callLua` now
    returns `Varargs` (for consume). **Zero `haven` edit** (all public). Compile OK + **13 headless
    input-plumbing checks** (arg order, consume, `dead` guard) + LuaJ parse. `hello` v0.13.0 (a draggable
    window drawing clock/vitals + click counter). Doc `phase-2a-custom-ui-gout.md`. **In-game DoD pending**
    (drag it, click the body, close it). Deferred: `g:image`/resources, UI.scale, keyboard/`onKey`,
    draw-time CPU budget.
  - [x] **2b — HUD overlays + world-space gob overlays.** ✅ `hafen.ui.overlay(fn)` (`fn(g,w,h)` painted on
    top of the HUD via a one-shot `UI.drawafter` **re-queued each tick** — tick precedes draw in the frame
    loop, so it lands above `root.draw`/GameUI) + `hafen.ui.gobOverlay(filter, fn)` (`fn(g,gob,sx,sy)` over each
    matching gob — a shared **`LuaGobOverlay` `GAttrib`+`PView.Render2D`** per gob, the `SpeakerIcon` pattern;
    a **throttled 5 Hz sweep** attaches, the per-frame `Render2D` pass re-filters + paints; filter = function
    or name-substring string). Extracted the 2a `g` wrapper into a shared **`LuaGOut`** (widgets/HUD/gob all
    use it — D-013). New owned lists `Addon.hudOverlays`/`gobOverlays` (auto-teardown). **Zero `haven` edit**.
    Compile OK + **21 headless checks** (register/remove lifecycle, string/function filter, error isolation,
    nil-guard, invalid-arg reject) + LuaJ parse. `hello` v0.14.0 (top-centre readout + centre crosshair HUD
    overlay + player head-tags). Doc `phase-2b-overlays.md`. **In-game DoD pending.** Deferred: draw-time CPU
    budget, per-overlay anchor, `g:image`.
  - [x] **2c — Input/gesture hooks (L1, zero core edit).** ✅ `hafen.hook.input(target, event, fn)` over the
    built-in `Widget.listen`/`handle` seam — a listener returning true IS `preventDefault` (and, per the audit,
    also blocks child dispatch), so **zero `haven` edit**. New `io.brodgar.addon.LuaInputHook` (an
    `EventHandler<Widget.Event>` forwarding to Lua via `callLua`). `target` = a string token (`"mapview"`/
    `"gameui"`/`"root"`); `event` = `mousedown`/`mouseup`/`mousemove`/`mousewheel`; `ev` = `{x,y,button?,
    amount?}` + `ev:preventDefault()` (the one canonical consume — no separate `stopPropagation`/`default` at
    L1). Handle `:remove()`; bridge-owned (`Addon.hooks`, deafened on reload/disable — engine widgets outlive a
    `:reload`). Compile OK + **20 headless checks** (preventDefault suppresses the default / passthrough runs it
    / ev fields / dead+deafen inert) + LuaJ parse. `hello` **v0.15.0** (a "map-lock" toggle: click the window
    to arm, then the MapView mousedown hook cancels map clicks — the DoD — with red HUD feedback). Doc
    `phase-2c-input-hooks.md`. **In-game DoD pending.** Deferred: widget-*type* targets (needs the 08 factory
    seam), key events + global hotkeys (2e), `ev:default()`/`resend()` (2d), hook priority/ordering (Q-012).
  - [x] **2d — Action hooks (L2, one core edit) — the `hook.action("click")` DoD.** ✅ `hafen.hook.action(msg,
    fn)` at the `UI.wdgmsg` outbound choke point. `fn(ev)` runs before the send with args **fully resolved**;
    `ev = { msg, sender, args (1-based; Coord→{x,y}, opaque objects round-trip), preventDefault(), resend()
    [original args, lossless], send(t) [new args] }`. resend/send bypass the hook chain (call the new public
    `UI.rawWdgmsg`), so re-issuing can't loop; both imply preventDefault. **One `haven` edit** (`UI.wdgmsg`
    split into a hook call + `rawWdgmsg`). Dispatch runs Lua **only while the caller holds the `ui` monitor**
    (`Thread.holdsLock` — the click send comes from the render thread but under `synchronized(ui)`, and tick/
    draw hold it too → no race, no new lock → no deadlock); near-zero fast path when unhooked; re-entrancy
    guard. New `io.brodgar.addon.LuaActionHook` (ev + Java↔Lua arg marshalling), `Addon.actionHooks`, facade +
    `onWdgmsg` + teardown in `AddonManager`. Compile OK + **33 headless checks** (marshalling round-trips incl.
    Coord↔{x,y} + opaque identity; ev/preventDefault/passthrough/isolation in a real sandbox env; the colon
    self=arg1 convention; the no-hook fast path) + LuaJ parse. `hello` **v0.16.0** (RIGHT-click the window to
    arm move-intercept: the "click" action hook logs the resolved destination, preventDefault + resend → still
    moves). Doc `phase-2d-action-hooks.md`. **In-game DoD pending.** Deferred: hook priority/ordering (Q-012),
    draw/action-hook CPU budget, post-hooks.
  - [x] **2e-1 — Message hooks (L3, one core edit).** ✅ `hafen.hook.message(msg, fn)` at the inbound
    `UI.uimsg` choke point (`UiMessage.run`, before the widget applies the update) — the mirror of 2d's
    outbound L2. `fn(ev)` runs with `ev = { msg, target (widget class simple name), args (1-based snapshot,
    same marshalling as L2), preventDefault() [SWALLOW the update], rewrite(t) [apply with new args] }`.
    preventDefault wins over rewrite; a swallowed message also skips the 1d post-apply read tap (no `*Changed`).
    **One `haven` edit** (`UiMessage.run`: call `onMessage` before dispatch + gate the read tap on applied —
    two `// addon:` lines). Runs on a Loader thread but always under `synchronized(ui)` (no `holdsLock` gate
    needed, unlike L2); near-zero fast path when unhooked. The 2d arg marshalling was **extracted into a shared
    `LuaMarshal`** (both hook levels use it — D-013). New `io.brodgar.addon.{LuaMarshal, LuaMessageHook}`,
    `Addon.messageHooks` (owned; unregistered on teardown, P2), facade + `onMessage` + register/teardown in
    `AddonManager`. Compile OK + **27 headless checks** (`LuaMarshal` round-trips; `ev`/preventDefault/rewrite/
    passthrough/isolation in a real sandbox env; the colon `self=arg1` convention `rewrite` needs; `onMessage`
    precedence incl. prevent-wins + dead-hook skip + the no-hook fast path) + LuaJ parse. `hello` **v0.17.0**
    (MIDDLE-click the window arms **vitals-freeze**: the `"set"` message hook swallows `IMeter` meter updates →
    the hp/stamina/energy bars freeze on the HUD until toggled off; observe-logs the first few while OFF). Doc
    `phase-2e1-message-hooks.md`. **In-game DoD pending.** Deferred: rewrite the message *name*, hook priority
    (Q-012), post-hooks, the message-hook/draw CPU-budget gap.
  - [x] **2e-2 — Global hotkeys (`hafen.key`).** ✅ `hafen.key.bind(name, defaultKey, fn)` → handle
    `{ :remove(), :key() }`, over `KeyBinding` (remappable + persisted). Backing: `KeyBinding.get("addon/<id>/
    <name>", KeyMatch)` + **`AddonRoot.globtype(GlobKeyEvent)`** (the invisible tick widget already on `ui.root`
    overrides `globtype` → `AddonManager.onGlobKey`, matching every registered hotkey) — **ZERO core edit** (like
    2c's `Widget.listen`): `UI.keydown` fires a `GlobKeyEvent` only after an **unconsumed focused `KeyDownEvent`**
    (so hotkeys never fire while typing), which walks the tree via `Widget.globtype`. AddonRoot is an early
    `ui.root` child → walked **last**, so a client binding on the same key wins (addon hotkeys = fallback). New
    `parseKeyMatch` (a key string `"F5"`/`"Ctrl+M"`/`"Shift+Alt+Left"`/`"None"` → `KeyMatch.forcode` for named
    keys via a `KEYCODES` table, `forchar` for single chars; exact modifier match) + the `KEYCODES` map. New
    `io.brodgar.addon.LuaKeyBind` (KeyBinding + fn + `matches(ev)`), `Addon.keybinds` (owned; teardown drops the
    Lua wrapper but KEEPS the persistent KeyBinding), facade + `newKeyBind`/`onGlobKey`/`teardownKeyBinds`.
    Runs on the UI thread (input dispatch) → `callLua` direct, no thread guard; near-zero fast path
    (`keyBinds.isEmpty()`). Compile OK + **31 headless checks** (parser incl. invalid input; `KeyMatch`
    modifier-exactness; `onGlobKey` fast-path/fire+consume/mod-mismatch/dead-skip/first-match-wins; `newKeyBind`
    register/handle/`:key()`/error paths — all in a real `Sandbox.create()` env) + LuaJ parse of the harness.
    `hello` **v0.18.0** (Ctrl+H toggles the 2a window — bound in the FILE BODY, showing a hotkey needs no live
    target). Doc `phase-2e2-global-hotkeys.md`. **In-game DoD pending** (Ctrl+H toggles the window; ordinary
    typing in a focused field never triggers a hotkey; re-mappable + persisted; `:reload` leaves no leak).
    **Committed** `55b71ecf`. Deferred: **shown in the client keybind panel → done in 2e-3**; `Super` modifier,
    key-up/repeat/chord bindings. (L4 method/hookable-subclass hooks fold into Phase 3.)
  - [x] **2e-3 — Addon hotkeys in the client keybind panel (WoW-style).** ✅ Completes the `hafen.key` contract
    ("shown in the client keybind panel"). When an addon registers ≥1 hotkey it now appears in **Options >
    Keybindings** under **its own section (the addon's name)** with the client's standard capture button per
    hotkey; an addon with no hotkey shows no section. Re-mapping **persists across restarts** for free — it rides
    the client's existing `KeyBinding` persistence (`SetButton`→`KeyBinding.set`→`Utils.setpref`; restored by
    `KeyBinding.get`/`KeyMatch.restore`). **One core edit** (D-011): a `// addon:` block in `OptWnd.BindingPanel`
    after "Voice chat" that loops the new **`AddonManager.describeKeyBinds()`** (addon hotkeys grouped by owner →
    `KeyBindGroup{addon, binds}`/`KeyBindEntry{name, binding}`; only live binds, first-registration order) and
    reuses the existing `addbtn` + `SetButton` — **no new capture/persistence code**. This is the **second**
    `OptWnd` addon edit (after 1f-3's panel button). **Plus a client-wide keybinding-EXCLUSIVITY fix** (the
    maintainer found the vanilla client lets the SAME key bind to several actions — `KeyBinding.set` had NO
    conflict check; not our bug, but patched at the source): `KeyBinding.set(key)` now unbinds a newly-assigned
    real key from every OTHER binding firing on the same key+mods (WoW-style; the panel's `SetButton` re-reads
    `key()` each frame → the stolen row shows `None` live). Char-vs-code reconciled via
    `getExtendedKeyCodeForChar`; different mods coexist; disable(nil)/revert(null) never steal; load bypasses
    `set` (no cascade). **Second `haven` core edit this slice** (`KeyBinding.java`, `// addon:`; benefits ALL
    bindings). Compile OK + **8 headless panel checks** (`describeKeyBinds`: empty→no-sections, per-addon
    grouping + order, real-`KeyBinding` identity, dead-bind exclusion, no-live-bind→no-section) **+ 9 exclusivity
    checks** (steal-on-assign incl. default-only + char/code; mods coexist; disable/revert don't steal) + LuaJ
    parse. `hello` **v0.19.0** (a second **`ping` hotkey, unbound by default** → the "Hello" section shows
    `toggle`=Ctrl+H + `ping`=None, demoing multi-row grouping + assign-from-panel). Doc
    `phase-2e3-keybind-panel.md`. **In-game DoD pending** (a "Hello" section appears; re-map persists across a
    restart; assign the unbound `ping`; **assigning a key steals it from the other row/section**; disable→reload
    removes the section). Deferred: per-binding display labels (uses the `name` arg), showing stored-but-inactive
    bindings, live panel refresh while open, exclusivity modign/revert edges.

- **3 — Widget replacement.** *(Split into 3 slices — too big for one prompt/verification, like 1c/1d/1f/2.)*
  Intercept server-widget creation and **wrap-not-reimplement** (model/view, D-009). First target: an
  inventory/bag reskin. Specs: `08-widget-replacement.md`, D-009/D-024. **Overall DoD:** replace the native
  inventory; disable restores it.

  - [x] **3a — Widget-creation interception + descriptor + observe (`hafen.ui.onWidgetCreate`).** ✅ Observe
    every SERVER widget as the client builds it, with the **targeting descriptor** `{id, type, place, caption,
    parentType}` (D-024) — `fn(desc)` runs per widget (return ignored; observe-only). **Two `// addon:` core
    edits**, both in `UI.java` (the **third `UI.java` edit region**): `NewWidget.run` records `id→typenm`
    (only while observed; in-flight set), `AddWidget.run` (after `pwdg.addchild`) fires `onWidgetPlaced` — the
    first moment the FULL descriptor exists (placement adds place/parent that creation lacks). Adopt-after-create
    (seam B), not the factory override (seam A, deferred). New `io.brodgar.addon.LuaWidgetObserver` (builds
    `desc`, null→nil, via `callLua`); `Addon.widgetObservers` owned list; flat global observer list + near-zero
    fast path; `widgetTypes` cleared per session. Runs under `AddWidget.run`'s `synchronized(ui)` (Loader
    thread, no race — like L3). **Zero `haven` edit beyond the 2 one-liners** (`Window.cap`/`Widget.getClass`
    public). Compile OK + **25 headless checks** (descriptor incl. nil-handling; `onWidgetPlaced` fast-path +
    extraction + type lookup/removal; `onWidgetCreated` records-only-when-observed + null-type ignore; Window
    caption via the direct test — headless GL skip) + LuaJ parse. `hello` **v0.20.0** (logs the descriptor of
    every HUD window + any titled container — open a cupboard/crafting window to see it). Doc
    `phase-3a-widget-interception.md`. **In-game DoD pending.** Deferred to 3b/3c: the model handle + replace.
  - [x] **3b — The `model` handle (wrap): adopt/hide/show + items + lifecycle events.** ✅ **`hafen.ui.adopt(id)`**
    adopts a live server widget (by the `desc.id` a 3a observer hands out) as a **`LuaModel`** → handle
    `:hide()`/`:show()`/`:visible()`/`:raw()` (the server id, a facade-safe WidgetRef — no Java object crosses to
    Lua, P1), **`:items()`** (Item **snapshots** `{res,name,num,wear,pos}` off the widget's `WItem` children,
    reusing the 1c-3 `itemSnapshot`/`cellPos`), and lifecycle **`:onItemAdded(fn)`/`:onItemRemoved(fn)`** (poll-
    diffed each tick, identity-keyed like `BuffsAdapter` — an item add/remove is a `WItem` create/`cdestroy`, not
    a `uimsg`) **/`:onDestroy(fn)`** (fires when `UI.getwidget(id) != wdg` — the server destroyed/reused the id).
    A hidden widget **stays server-bound** → `:items()` + the events keep working while hidden (the headless
    model, D-009 verified). **Teardown un-hides** anything the addon hid (restores the stock UI) — fires on
    `:reload`/disable/auto-disable (same session, widget alive), skips a relog (widget gone). **Item MUTATING
    verbs (`take`/`drop`/`transfer`/`use`) DEFERRED to the gated Phase-4 actions tier** (D-010/D-025 + security
    spec + this queue's Phase-4 "item verbs") — spec 08's model sketch listed them, but they are gameplay actions,
    so 3b ships the read+lifecycle surface only (the DoD needs exactly that). **Zero `haven` edit** — all backings
    public (`UI.getwidget`, `Widget.hide/show/visible/children`, the 1c-3 item helpers); only `AddonManager.java`
    (facade + `newModel`/`modelHandle`/`pollModels`/`teardownModels`, wired into tick + teardown + `init` session
    reset) + `Addon.models` + new `LuaModel.java`. Compile OK + **27 headless checks** (handle surface on a bare
    `Widget` incl. chaining/`fnOrNull`/dead no-ops; `newModel` arg-validation; `pollModels`/`teardownModels`
    ui-null safety) + LuaJ parse. `hello` **v0.21.0** (adopts the main inventory from the onWidgetCreate observer;
    **Ctrl+B** hides/shows its grid; logs items + add/remove/destroy; a 3rd "Hello" keybind row). Doc
    `phase-3b-model-handle.md`. **In-game verified ✅** (adopted at login; Ctrl+B hid/showed the grid; a ground
    pick-up **while the grid was hidden** fired `onItemAdded` — the headless-model claim confirmed; the `bagsReady`
    gate was added after a first run where the initial-fill log burst masked the pick-up). Deferred to 3c: re-finding
    an already-open window by descriptor (`replace`), hiding the wrapper window. Also deferred: item actions (Phase 4), `:remove()`.
  - [x] **3c — `hafen.ui.replace` + the bags example + reload un-hide (the Phase-3 DoD).** ✅ `hafen.ui.replace(
    type, opts, fn(model))` (spec 08's sugar over 3a+3b): find a server widget by descriptor → adopt+hide → hand
    `fn(model)` a chance to draw a custom view (returned, bridge-owned) → **un-hide on teardown**. **Two match
    paths:** the **creation** path (folded into 3a's `onWidgetPlaced` — a target opened after registration) AND a
    one-time **scan** at registration for an **already-open** target (the `:reload` gap 3b flagged — keyed by Java
    class since the server type isn't stored for a live widget; `context="main"`→`GameUI.maininv`). `opts` =
    `context`("main")/`caption`(exact)/`match`(desc-predicate). **Hides the WRAPPER window** (`nativeWindowOf` =
    nearest enclosing `Window` — the "Inventory" `Hidewnd`), restoring its **original** visibility on teardown
    (`LuaModel.hideTarget`+`hideTargetOrigVisible`; a plain 3b `adopt` still targets the widget → 3b unchanged).
    `:remove()` fully undoes (restore native + destroy view). Item verbs stay **gated Phase-4** → the view is
    read-only. **Zero new `haven` edit** (reuses 3a's two `UI.java` one-liners). New `LuaReplacer.java`; edits to
    `LuaModel`/`AddonManager`/`Addon`/`LuaWidgetObserver` (shared `descTable`, DRY). Compile OK + **36 headless
    checks** (match gating incl. container-inv reject / caption / match-fn / scan criteria / `nativeWindowOf` /
    `handled` / hide-target routing + origVisible capture for visible-grid AND hidden-default-wrapper) + LuaJ parse
    of `bags`. New dedicated **`bags`** addon (`addons/bags/`, dormant via a **Ctrl+Shift+I** toggle so it never
    disturbs `hello`): press it → the inventory is replaced by a custom "Bags" window drawing the real items at
    their grid cells; press again / disable / `:reload` → restored. Doc `phase-3c-replace-bags.md`. **In-game
    verified ✅** (Ctrl+Shift+I replaced the open inventory with the custom view — the scan path; toggle-off / X /
    disable+`:reload` all restored the stock inventory; `hello` regression intact). Committed. **This completes
    Phase 3** (widget replacement). Deferred: item verbs (Phase 4), `g:image` icons,
    intercepting the client `Tab` toggle, live-grid sizing (`Inventory.isz`), the factory-override seam A.

- **Gap subsystems** (after the above; order D-026). Specs: `coverage-gaps.md`, `api-reference.md`
  "Gap subsystems". Each = adapter/facade + Lua surface + events + example. **Split each into its own
  task/prompt when reached.**

  - [x] **A1 — `hafen.markers` (map markers).** ✅ (see STATUS §5; doc `a1-markers.md`) `list([filter])`/
    `nearest([filter])`/`add(name,x,y[,opts])`/`remove(ref)` over the **client-side** map DB (`MapFile`
    via `MapWnd`/`MiniMap` — the same instance) + **`MarkersChanged`** (poll `MapFile.markerseq`; a marker
    add/remove is not a uimsg). Snapshot `{id,name,type("player"|"system"),seg(id string),tc,color|icon,
    x,y,dist}`; **persistent anchor = seg+tc** (survives relog), **x,y/dist session-local** (only in the
    player's segment — C4). `add()` takes **WORLD** coords (like `hafen.gob.pos`), converted to the segment
    anchor at add time via the minimap's `sessloc` (world→seg = `sessloc.tc + floor(world/tilesz)`, mirrors
    `MapWnd.FindMark.hit`); creates a **PMarker** (SMarker/icon add deferred — server-owned). Reads
    copy-under-`file.lock` then snapshot outside it (OCache discipline; markers mutate on loader threads).
    **Zero `haven` edit** — all backings public (`GameUI.mapfile`/`mmap`, `MapWnd`/`MiniMap.file`,
    `MiniMap.sessloc`, `MapFile.markers`/`markerseq`/`lock`/`add`/`remove`, `Marker`/`PMarker`/`SMarker`
    fields). Compile OK + **64 headless checks** (world↔segment round-trip incl. negatives + non-zero
    origin; marker-ref map assign/resolve/reset/stale; `luaColor`/`clampByte`) + LuaJ parse of `hello`.
    `hello` **v0.22.0** (Ctrl+Shift+M drops/removes a "Hello marker" at the player; reads markers at now/+3s;
    logs `MarkersChanged`; OnDisable cleanup so the harness never pollutes the map). Doc `a1-markers.md`.
    **In-game verified ✅. Committed `72d42277`.** Deferred: SMarker/icon add, marker edit (`MapFile.update`), a per-marker
    grid-anchor field (derive via `hafen.map.gridPos(m.x,m.y)`), map/minimap overhaul (B3, client-side).
  - [x] **A4 — buyable skills + credos + lore/experiences (completes A4).** ✅ (see STATUS §5; doc
    `a4-skills-credos-lore.md`) The headline A4 trackers already shipped in 1d (study slots + `StudyChanged`
    1d-3, FEP/food + `FepChanged` 1d-2, **known** skills 1d-3); this adds the rest of `SkillWnd`:
    `hafen.char.skillsAvailable()` (buyable skills `{name,res,cost}` from `skg.nsk`), `hafen.char.credos()`
    (Credos tab — `{acquired, available, pursuing={name,res,level,levelTotal,quest,questTotal,questId}|nil,
    cost}` from `SkillWnd.credos`), `hafen.char.experiences()` (Lore tab `{name,res,score,mtime}` from
    `exps.seen`). **Read-only, no `*Changed`** (these change only on explicit buy/pursue/quest actions →
    read on demand, like the deferred `SkillsChanged`). **Zero `haven` edit** — all public (`SkillWnd.skg`/
    `credos`/`exps`); only `AddonManager.java` (+ generic `resTipName`/`resIdent` helpers, extracted from
    `skillName`/`skillRes`, DRY). Compile OK + 5 headless guard checks (`resTipName`/`resIdent` Loading/null)
    + LuaJ parse. `hello` **v0.23.0** (`readLore` at now/+3s). **In-game verified ✅. Committed `df6705b2`.** Deferred: a
    credo-progress event, skill buy / credo pursue (Phase-4 gated actions).
  - [x] **A2 — `hafen.radar` (radar / minimap icon categories).** ✅ (see STATUS §5; doc `a2-radar.md`)
    `hafen.radar.categories([filter])` reads the per-char gob-icon registry (`GobIcon.Settings` /
    `GameUI.iconconf` — the same one the in-client "Icon settings" window edits) as snapshots
    `{name (icon tooltip), res (stable id), show, notify}`; `setVisible(filter,on)` / `setNotify(filter,
    on)` flip a category's **minimap-display** / **spawn-notify** flag over the **canonical filter**
    (nil=all / string=name-substring / function=predicate-over-snapshot) and **persist** it (`dsave`,
    exactly as the settings-window checkboxes), returning the **#matched**. **Zero `haven` edit** — every
    backing public (`GameUI.iconconf`, `Settings.settings`/`dsave`, `Setting.id.res`/`show`/`notify`/
    `icon.name()`); only `AddonManager.java` changed (facade + `iconconf`/`radarSnapshot(s)`/`radarName`/
    `radarSet`/testable `radarSetIn`; reuses the shared `matches` filter). Compile OK + **16 headless
    checks** (match-count / show-vs-notify routing / snapshot shape + name fallback / function-filter
    isolation / null-safety, via a no-op-`save()` `Settings` subclass so the test writes no disk) + LuaJ
    parse. `hello` **v0.24.0** (a **read-only** `readRadar` at now/+3s — the setters persist to the user's
    real icon config, so the harness never mutates them; mutation is a documented `:lua` DoD step). Doc
    `a2-radar.md`. **In-game verified ✅. Committed `8e40c8b1`.** (The first run's `:lua categories()` crashed the
    client — the REPL renders its result as ONE in-game text texture and the ~40 KB one-line dump blew
    `GL_MAX_TEXTURE_SIZE`; fixed in the same commit by `clampMsg` on all in-game notice sinks — see STATUS §5.)
    Deferred: per-category permanent-marker + notification-sound picker + global "new-icon" notify, custom
    addon icon registration, a `RadarChanged` event (read-only).
  - [x] **A11 — `hafen.slash` (console / slash commands).** ✅ (see STATUS §5; doc `a11-slash-commands.md`)
    `hafen.slash.register(name, fn)` → handle `{ :remove() }`; routes `:name args…` to `fn(args)` (args =
    a 1-based table of the whitespace-split words after the name, name excluded; `"quoted"` groups via
    `Utils.splitwords`). **Reload-safe by construction (coverage-gaps C1):** a SINGLE engine-lifetime
    `Console` dispatcher per name routes to the CURRENT live handler (`slashHandlers`), never re-registered
    — reload/disable only swaps/drops the handler; a dropped name replies `no addon handles :name`. Reserved
    (`lua`/`addons`/`reload`) + already-a-client-command + whitespace/empty/non-function names are refused.
    **Zero `haven` edit** (reuses `Console.setscmd`) — new `LuaSlashCommand.java` + `Addon.slashCommands` +
    `AddonManager` facade/dispatch/teardown. Compile OK + **41 headless checks** (invoke marshalling;
    register/dispatch/remove/teardown; one-dispatcher reload round-trip; cross-addon takeover identity-safe;
    refusals) + LuaJ parse. `hello` **v0.25.0** (a `:hello` command with `toggle`/`ping`/`echo` sub-commands).
    **In-game verified ✅. Committed `e8065754`.** Deferred: raw-remainder arg (`cons.rawcmd`), tab-completion/help, `:reload <id>`.
  - [x] **A6 — `hafen.kin` (kin/buddy roster read).** ✅ (see STATUS §5; doc `a6-kin.md`) `list([filter])`
    → kin `{id,name,group(0..7),color={r,g,b,a},online(bool)}` (canonical filter; window sort order) +
    `find(nameOrId)` (number→id via `BuddyWnd.find`, string→exact ci-name) + **`KinChanged`** (uimsg-driven
    `KinAdapter` over `BuddyWnd` `add`/`rm`/`upd`/`chst`, **snapshot-diff not `serial`** — `serial` misses
    `chst`, an online flip; payload = the new list). `online` = **bool** (`Buddy.online==1`; the `-1`
    tri-state / `seen` deferred). **Zero `haven` edit** — all public (`GameUI.buddies`, `BuddyWnd.iterator`
    [copies under lock] / `find`, `Buddy.id`/`name`/`online`/`group`, `BuddyWnd.gc` palette). Compile OK +
    **14 headless `kinListEqual` checks** (identical / online-flip / group / name / id / add / remove /
    reorder / count / nil edges) + LuaJ parse. `hello` **v0.26.0** (`readKin` now/+3s; `KinChanged` names who
    came online/went offline). Doc `a6-kin.md`. **In-game verified ✅. Committed `930cdf31`.** Deferred:
    add/remove/rename (Phase 4), the `online` tri-state / `seen`, a granular `KinOnline`/`KinOffline` event.
  - [x] **A7 — `hafen.speed` (movement speed, read).** ✅ (see STATUS §5; doc `a7-speed.md`) `get()` → the
    current speed 0..3 (0=crawl 1=walk 2=run 3=sprint), `max()` → the highest currently-selectable speed,
    `name([n])` → a speed's display name (default = current), read live off the **`Speedget`** selector.
    No named `GameUI` field → located with the **1d-1 Locator** (`gui().children(Speedget.class)`, the
    vitals-style subtree walk); `cur`/`max` public ints → **zero `haven` edit** (like A6/A4/A2). **Read-only,
    no `SpeedChanged`** — the api-reference lists only get/set and A2/A4 precedent is read-only; `set` is the
    gated Phase-4 tier (`Speedget` `wdgmsg("set",n)`). Only `AddonManager.java` changed (facade + `speedget()`/
    `speedName()` + import `haven.Speedget`). Compile OK + **8 headless checks** (locator null-safety / facade
    wiring / nil-with-no-HUD) + LuaJ parse (`name()`'s in-range value reads resource tooltips → verified
    in-game). `hello` **v0.27.0** (`readSpeed` at now/+3s; load-line resynced from v0.25.0). **In-game verified
    ✅. Committed `e31f8787`.**
  - [x] **A8 — `hafen.craft` (crafting read).** ✅ (see STATUS §5; doc `a8-craft.md`) `hafen.craft.current()`
    → the OPEN recipe/craft window as `{recipe, inputs, outputs, qmod, tools}`, or nil when none is up.
    inputs/outputs = `{res,name,num,opt}` specs (`res`/`name` = the DISPLAYED resource — the constraint
    category when the recipe accepts one, else the concrete item, mirroring `Spec.display()`; `num` =
    required/produced, **-1=unspecified≈1** faithful; `opt` = optional ingredient / chance byproduct);
    `qmod`/`tools` = `{res,name}` arrays. Backing [`Makewindow`](src/haven/Makewindow.java) (`@RName("make")`),
    located via the 1d-1 Locator (`gui().children(Makewindow.class)` — it's wrapped in the private
    `GameUI.makewnd`). Read-only — `craft.make` is the gated Phase-4 tier; no `CraftChanged` (read on demand;
    observe a recipe opening via 3a `onWidgetCreate`, `place="craft"`). **Threading:** `inputs`/`outputs`/`qmod`
    are swapped wholesale off-thread (`inpop`/`opop`/`qmod` uimsg), `tools` is mutated **in-place** (`tools.add`,
    `tool` uimsg) → copy all four under `synchronized(ui)`, snapshot outside (the marker discipline). **Zero
    `haven` edit** — all backings public (reuses A4's `resIdent`/`resTipName`); only `AddonManager.java` changed.
    Compile OK + **11 headless checks** (locator/`readCraft` null-safety; `craftRes`/`craftReses` resolved +
    Loading-omitted + 1-based + empty; the `craftSpec` shape test = a headless **resource** skip like 3a —
    building a live `Makewindow.Spec` triggers `Makewindow.<clinit>`→`Text.render`→the `ui/fraktur` font,
    absent headless) + LuaJ parse. `hello` **v0.28.0** (`readCraft` at now/+3s = "none open"; `:hello craft`
    dumps the open recipe's inputs/outputs/qmod/tools). **In-game verified ✅. Committed `fbbd564d`.**
    Deferred: input fill-state (`Input.using`), per-item quality, a `constraint`/`item` split, `CraftChanged`.
  - **A9** `hafen.quests` / `hafen.wounds` (read). *(Split into 2 slices — quests + wounds are distinct
    widgets/shapes, like every other A-task "split when reached".)*
    - [x] **A9-1 — `hafen.quests` (quest log read).** ✅ (see STATUS §5; doc `a9-1-quests.md`)
      `list([filter])` → quest snapshots `{id, name (title), res, status ("pending"/"done"/"failed"/
      "disabled"), mtime}` for BOTH the Current + Completed tabs (canonical filter), `selected()` → the
      OPEN quest (the only one whose conditions load) + `conds={{desc, status, text?}}` or nil, and
      **`QuestAdded`** (new active quest) / **`QuestDone`** (active→finished) via a uimsg-driven
      `QuestAdapter` over `QuestWnd` (`CharWnd.quest`) + a **pure `questDiff`** (headless-testable).
      **Zero `haven` edit** (all public; status ints inlined so the helpers don't load `Quest`). Compile
      OK + **26 headless checks** + LuaJ parse. `hello` **v0.29.0** (`readQuests` now/+3s, `QuestAdded`/
      `QuestDone` logs, `:hello quest`). **In-game verified ✅. Committed `db105520`.** Deferred:
      `QuestRemoved` / per-condition event; instant-complete & reopen edges (no event, intentional).
    - [x] **A9-2 — `hafen.wounds` (wounds read).** ✅ (see STATUS §5; doc `a9-2-wounds.md`)
      `list([filter])` → wound snapshots `{id, name, res, severity, parentid, level}` (wounds form a TREE
      via `parentid`[-1=root]/`level`; `severity` = the highest-`qprio` `WoundWnd.QuickInfo.qstr()` the
      client shows beside the wound — a content string, usually a number, **NOT seconds**, nil while
      Loading) + `has(needle)` (name/res substring, like `buffs.has`), over `WoundWnd` (via the public
      `CharWnd.wound`), plus **`WoundChanged`** (poll-driven `WoundAdapter` + a pure snapshot diff
      `woundListEqual`, payload = the new list, like `KinChanged` — severity is in the key, so a wound
      worsening fires it; **poll not uimsg** because severity streams in a beat after the wound row, like
      study's Curiosity info). **Zero `haven` edit** (all backings public). Compile OK + **23 headless checks**
      (`woundListEqual`: severity/name/res/id/parentid/level change, add/remove/reorder, nil-field &
      non-table edges, locator null-safety) + LuaJ parse. `hello` **v0.30.0** (`readWounds` now/+3s,
      `WoundChanged`, `:hello wound` dumps the tree). Doc `a9-2-wounds.md`. **In-game verified ✅. Committed
      `3258694e`.** **This completes A9.** Deferred: `selected()` (no selection-gated detail, unlike quests), a
      `WoundAdded`/`WoundHealed` split, wound pagina/icon, absolute healing timer (client has none).
  - [x] **A10 — `hafen.fight` (combat schools / deck read).** ✅ (see STATUS §5; doc `a10-fight.md`) The
    OUT-OF-COMBAT maneuver-deck builder (`FightWnd`, `@RName("fmg")`, the char sheet's "Martial Arts &
    Combat Schools" tab via the public **`CharWnd.fight`** — distinct from the in-combat `hafen.combat.*`
    view). `maneuvers([filter])` → every known maneuver/attack `{res, name, avail(`Action.a`), used(`Action.u`)}`
    (canonical filter); `deck()` → the current school's card LAYOUT `{slot(raw 0-based), key("1".."5"/"⇧1".."⇧5"
    from `FightWnd.keys`), res, name, used}` (filled `order[]` slots only, empties omitted); `summary()` →
    `{maxact, used(=Σ Action.u), nact(=order.length), nsave, usesave(0-based active school)}` or nil before the
    tab exists. **Read-only, no `FightChanged`** (a school changes only on explicit action — like A4/A8, read on
    demand). **Zero `haven` edit** — all backings public (`CharWnd.fight`, `FightWnd.acts`/`order`/`keys`/`maxact`/
    `usesave`/`nsave`, `Action.res`/`a`/`u`); only `AddonManager.java` changed (facade + `fightwnd`/`fightManeuvers`/
    `maneuverSnapshot`/`fightDeck`/`deckKey`/`fightSummary`, reusing `matches`/`resTipName`/`resIdent`). Copy the
    acts list / order[] array + scalars under `synchronized(ui)` (uimsg mutates off-thread), resolve names outside
    (the marker discipline). Compile OK + **4 headless checks** (locator + 3 facade helpers null-safe with no
    session; `deckKey`/`keys` = a **headless resource skip** — `FightWnd.<clinit>` needs `/res/ui/fraktur.res`,
    like A8's spec test → verified in-game) + LuaJ parse. `hello` **v0.31.0** (`readFight` now/+3s; `:hello fight`
    dumps the deck by hotkey + maneuvers). Doc `a10-fight.md`. **In-game verification pending.** **This completes
    the A-series read subsystems.** Deferred: saved-school NAMES (private `FightWnd.saves[]` → a one-line
    `AddonWidgets` accessor; `usesave`/`nsave` identify the active slot), a `FightChanged` diff-event, per-maneuver
    pagina/icon, edit/switch verbs (Phase-4 gated: `fight.use`/`setCount`/`loadSchool`).
  - [x] **A3** `hafen.actionbar` gated `use` (read + events already done in 1d-4). ✅ **Shipped in 4g** below
    (`hafen.actionbar.use(n[,mods])`).

- **4 — Actions tier (GATED — a declared write PERMISSION, D-027).** *(Split into slices, like 1c/1d/1f/2/3.)*
  `hafen.act.*` (and the per-subsystem *(gated action)* verbs) behind the **two-part permission** (D-027): a
  global master switch (config `addons.actions.enabled` for now; a persisted, panel-toggled pref is added in 4b)
  **AND** a per-addon manifest declaration (`"permissions": ["actions"]`). Specs: `12-security-and-permissions.md`, `10-options-panel.md`,
  `09-events-catalog.md` (action-message reference), `api-reference.md`, D-010/D-025/**D-027**. **Overall DoD:**
  a click-macro works only when an addon declares the permission AND the master switch is on.

  - [x] **4a — Write-actions permission (D-027) + `hafen.act.moveTo`.** ✅ (see STATUS §5; doc
    `phase-4a-actions-gate-moveto.md`) The permission model: `actionsGranted(owner)` = master switch
    (`actionsEnabled()` = config `addons.actions.enabled`, config-only for 4a; pref+panel toggle is 4b) AND
    `owner.manifest.usesActions()` (the new manifest `permissions` array). `requireActions(owner, verb)` throws a **distinct** LuaError per
    failure; the provisional `:addons actions` console command was **removed** (control → the panel, 4b). The
    `hafen.act` namespace: `enabled()` (= granted, never throws) + `moveTo(x,y)` (walk to a WORLD coord via the
    `MiniMap.mvclick` "click" encoding — off-screen dest fine). **Zero `haven` edit** (`AddonManager.java` +
    `Manifest.java`). Compile OK + **24 headless checks** (coord math / master config-flag flip / `usesActions`
    parse / `actionsGranted` / `requireActions` distinct errors / facade end-to-end declaring-vs-not × master
    on/off) + LuaJ parse. `hello` **v0.32.0** (declares the permission; `readActions`; `:hello walk`).
    **In-game verified ✅. Committed `d40378c0`.** (Master switch is config-ONLY for 4a; the pref+panel toggle is 4b — §8.)
  - [x] **4b — AddOns-panel master checkbox + default-disabled for write addons.** ✅ (see STATUS §5; doc
    `phase-4b-actions-panel-default-disabled.md`) The panel's **"Allow addon actions (writes)"** checkbox drives
    `setActionsEnabled` (a persisted pref layered over the config flag, with a notice tooltip + an `[actions]` row
    marker); newly-discovered addons that declare `"actions"` **default to disabled** via a persisted **seen set**
    (`scanAddonDefaults` + the pure `applyActionsDefaults`), and while the master switch is OFF a write-declaring
    addon does not load at all (`loadAll` gate → `liveStatus` `blocked: actions off`). Because a write addon can't
    load with the switch off (the default), **`hello` went READ-ONLY** (v0.33.0 — always loads, the harness) and
    the write demo moved to the new dormant, opt-in **`walker`** addon (declares `"actions"` → default-disabled;
    `:walker` = `moveTo` ~2 tiles south). **Zero `haven` edit** (`AddonManager` + `ui.AddonPanel`); 12 headless
    checks + LuaJ parse. **In-game verified ✅. Committed `9be7c13d`.** (panel checkbox; walker default-off →
    enable+switch-on+reload → `:walker` walked; switch-off+reload → walker not loaded; hello loaded throughout).
    **⚠️ The master switch was later REMOVED by D-028 (4c); the default-disabled policy + `[actions]` marker remain.**
  - [x] **4c — Enable-time consent dialog + D-028 (permission is now PER-ADDON ONLY).** ✅ (see STATUS §5; doc
    `phase-4c-enable-consent-dialog.md`) **(A)** Ticking the enable checkbox of a **write-declaring** addon raises a
    titled **consent dialog** (`io.brodgar.addon.ui.ActionsConsentWnd`) first — "'X' wants permission to act on your
    behalf … you are granting the permission to this addon alone" — and it is enabled (persisted, apply-on-reload
    D-006) **only** on **Enable**; **Cancel**/✕ leaves it disabled. The box stays unticked until confirm (`set(v)`
    branches on `v && declaresActions`); the dialog is the panel's **own child** (auto hide/destroy, no orphan),
    one-at-a-time guarded; **`enableAll` skips write addons**. **(B) D-028** (maintainer): **dropped the global
    master switch** — write-actions are a **per-addon** permission (declare + enable-with-consent = grant; the tier
    is always available system-wide). Removed `actionsEnabled`/`setActionsEnabled`, the config flag + pref,
    `writeAddonIds`, the panel checkbox, `loadAll`'s master gate, `blocked: actions off`; `actionsGranted`/
    `requireActions` are declaration-only; a write addon loads as soon as enabled. **Kept** the default-disabled
    policy + `[actions]` marker. **Zero `haven` edit**. Compile OK + **9 headless checks** (the D-028 gate +
    `applyActionsDefaults` unchanged) + LuaJ parse. `hello` read-only + reworded; **`walker` v0.2.0** reworded is the
    in-game trigger. Doc + superseded notes on 4a/4b docs; D-028 in decisions.md; specs 10/12/api-reference updated.
    **In-game DoD pending** (no "Allow addon actions" checkbox; tick walker → dialog; Cancel off; Enable + Reload UI
    → walker loads + `:walker` walks; "Enable all" skips it; Back/close no floating dialog; read addons instant).
    Deferred: per-category breakdown (finer `"actions.*"` perms), re-consent on a read→write manifest flip, true
    modality.
  - [x] **4d — MapView action verbs.** ✅ (see STATUS §5; doc `phase-4d-mapview-verbs.md`) Completes the
    MapView half of the gated tier on top of 4a's `moveTo`: `hafen.act.clickGob(ref [,button [,mods]])` (the
    `MapView "click"` = `{pc, mc, button, mods}` + `Gob.GobClick.clickargs` `{0,gobid,gobrc,0,-1}` — bare click,
    `ref` = the read-API GobRef via `resolve()`; button 1=left/3=right), `useItemOn(x,y [,mods])` (`"itemact"`,
    ground target), `place(x,y,angle [,button [,mods]])` (`"place"`, angle RADIANS → `round(angle*32768/PI)`),
    `select(x1,y1,x2,y2 [,mods])` (`"sel"`, WORLD corners → TILE via `worldToTile`), and `raw(target,msg,…)`
    (escape hatch — `wdgmsg` from a bound widget; `target` = a widget id or `"mapview"`/`"gameui"` reusing 2c's
    `hookTarget`; args via the shared `LuaMarshal`). All `requireActions`-gated; world coords throughout; pure
    arg builders (`clickGobArgs`/`itemactArgs`/`placeAngle`/`placeArgs`/`selArgs`) reuse `moveClickCoord`.
    **Zero `haven` edit** (only `AddonManager.java`, no new imports). Compile OK + **33 headless checks** (the
    builders' coord/angle/tile encodings incl. negatives + the whole facade gated end-to-end: declaring passes
    to `"no map view"`, reader blocked `"did not declare"`, arg + raw-target validation) + LuaJ parse. `hello`
    stays read-only; the write demo moved to **`walker` v0.3.0** (`:walker walk|click|use|sel|place|raw`, one
    deliberate verb each). **In-game verified ✅. Committed `98885490`.** Deferred: composite sub-mesh targeting (clickGob sends mesh
    `-1`), `useItemOn` on a gob (ground-only ships; `raw` covers it), menu/flower (4e), item verbs (4f).
  - [x] **4e — Menu + flower.** ✅ (see STATUS §5; doc `phase-4e-menu-flower.md`) `hafen.act.menu(path…)`
    (via `GameUI.act(String...)` → `wdgmsg("act", path…)`; the client itself uses it, e.g. `act("lo","cs")`
    = log out to char select) + `hafen.act.flower(label)` → **bool** (locate the open `FlowerMenu` via the
    recursive `ui.root.children(FlowerMenu.class)`, match a petal by `name` **case-insensitively** — exact,
    not substring, since it commits a choice — and drive the client's own `FlowerMenu.choose`, wrap-not-
    reimplement D-009; returns true iff matched, **never throws** for no-menu/no-match). Both `requireActions`-
    gated (D-027/D-028). **Zero `haven` edit** (only `AddonManager.java` + import `haven.FlowerMenu`; pure
    helpers `menuPath`/`flowerPetalIndex`). Compile OK + **26 headless checks** (21 on `menuPath`/`flowerPetalIndex`
    + 5 LuaJ-runtime in a real `Sandbox.create()` env) + LuaJ parse. `walker` **v0.4.0** (`:walker menu`/`flower`).
    **In-game verified ✅. Committed `ea89c997`.** Menu-path caveat (coverage-gaps C3): paginae are content-defined/localized/versioned
    — not a stable address space. Deferred: `MenuOpened` event, petal disambiguation by index/res.
  - [x] **4f — Item verbs.** ✅ (see STATUS §5; doc `phase-4f-item-verbs.md`) `hafen.act.item(item, verb[, n])`
    — the gated item half. `item` = an **Item snapshot** (or its `handle`) from any read; `verb` = take/drop/
    transfer/iact/itemact → the exact `GItem.wdgmsg` a click sends. **Item reference = a HANDLE = the item's
    server widget id** (`GItem.wdgid()`, D-022 handle-only): `itemSnapshot` now carries a **`handle`** field, so
    `hafen.items.*` AND `model:items()` (shared `itemSnapshot`) became actionable at once — **this is how the
    Phase-3 `LuaModel` item verbs land**, via the one canonical flat verb (no OO `:take()`, D-013). Re-resolves
    the live `GItem` via `UI.getwidget(id)` each call (stale/used → guiding error, like a GobRef); facade-safe
    (P1, just an int) + leak-free (engine's `UI.widgets`). `n` = stack count for drop/transfer (default **-1 =
    all**); iact/itemact send mods 0 (modified interaction via `raw(handle,"iact",{x=0,y=0},mods)`).
    `requireActions`-gated like every verb (D-027/D-028). **Zero `haven` edit** (all public; only
    `AddonManager.java` — facade + `itemVerbArgs`/`resolveItemHandle`/`actItem` + the `handle` in `itemSnapshot`).
    Compile OK + **19 headless checks** (`itemVerbArgs` shapes/`n`-threading/unknown→null + the facade gated
    end-to-end in the real installer: declaring→verb/resolve errors, raw-number handle, bad-type/no-handle
    rejects, non-declaring blocked before verb-validation) + LuaJ parse of `walker`+`hello`. `hello` **v0.34.0**
    (read-only: logs the new `handle` on read items); write demo **`walker` v0.5.0** (`:walker item [verb]` =
    act on the first inventory item, default `take`). **In-game verified ✅. Committed `2557e798`.** Deferred:
    quality/contents/stack-split take, a bulk `invxf` verb (`raw` covers it), the 4g per-subsystem gated verbs.
  - [x] **4g — Folded-in per-subsystem gated verbs.** ✅ (see STATUS §5; doc `phase-4g-per-subsystem-verbs.md`)
    All behind the same `"actions"` gate but in their OWN namespaces: `hafen.speed.set(n)` (A7 — `Speedget.set`),
    `hafen.craft.make([all])` (A8 — `wdgmsg("make",0|1)`, consumes ingredients), `hafen.actionbar.use(n[,mods])`
    (**A3** — a left-click on belt slot n via `Belt.act`), and `hafen.kin.add/remove/forget/rename/setGroup` (A6 —
    `add(secret)` = add by HEARTH SECRET via `wdgmsg("bypwd",secret)`; **`remove`+`forget` = the game's two-step
    drop** [`Buddy.endkin` "End kinship" → kin stays memorized, then `Buddy.forget` "Forget" → drop it; both `rm`,
    server advances the state]; `rename`/`setGroup` → `chname`/`chgrp`; `kin` = a snapshot/id/name).
    Wrap-not-reimplement (D-009) throughout; each
    `requireActions`-gated. **Zero `haven` edit** (only `AddonManager.java` + import `haven.MenuGrid`). Compile OK
    + **25 headless checks** (the whole facade gated end-to-end in a real `Sandbox.create()` env: declaring → each
    verb's arg-validation / no-live-widget error; non-declaring → "did not declare") + LuaJ parse. `walker`
    **v0.6.0** (`:walker speed|craft|bar|kin`).
    **In-game DoD pending.** **This completes Phase 4** (the gated actions tier).

- **V — Virtual entities (world ghosts) + transform gizmo (SAFE-tier, client-only).** *(Split into
  slices V1..V6, like 1c/1d/4.)* ✅ **Design CLOSED** — [16-virtual-entities.md](16-virtual-entities.md)
  ratified (decisions [D-029](decisions.md)…[D-033](decisions.md); namespace `hafen.ghost.*`). Client-only
  ghosts (a `Gob` with no server id, the [`Plob`](src/haven/MapView.java:1779) template) placed on the
  MapView scene — **NOT gated** (N1/N2 preserved; nothing reaches the server), so no `"actions"`
  permission. Specs: `16-virtual-entities.md`, `code-map.md` (V-series seams), `api-reference.md`
  (`hafen.ghost.*`). **Overall DoD:** an addon places movable ghost props over the terrain and (V5+)
  drags them with a gizmo, all client-side; `:reload`/disable leaks nothing.

  - [x] **V1 — Minimal ghost (create / move / destroy).** ✅ (see STATUS §5; doc `v1-ghosts.md`)
    `hafen.ghost.new{res,x,y[,a]}` + `hafen.ghost.list([filter])` → a bridge-owned handle with
    `:move(x,y[,a])`/`:pos()`/`:res()`/`:destroy()`. A ghost is a **virtual `Gob`** (id -1 ⇒ `virtual`, invisible
    to OCache/reads/server — **SAFE-tier, NOT gated**, D-029) with a `ResDrawable`, added to the MapView `basic`
    scene — the [`Plob`](src/haven/MapView.java:1779) precedent. **One `// addon:` core edit** (spec §6 option A):
    the `MapView.addClientGob(Gob)→RenderTree.Slot` / `removeClientGob(Slot)` seam pair (mirrors `Plob.place`;
    `removeClientGob` swallows `SlotRemoved` → teardown idempotent). **Deferred create** (`glob.loader.defer`,
    dodging `Loading` on `res.get()` — the Plob/`hafen.sound` pattern): the handle returns immediately, the prop
    streams in; publish/destroy handoff guarded by the ghost monitor so the loader-thread create never races a
    `:move`/`:destroy` (destroy-before-publish discards the un-added gob; no leak). No global poll list — the
    render tree ticks `gob.placed` itself; ghosts live only in `Addon.ghosts` (teardown removes the slot + disposes
    the sprite, P2). Compile OK + **35 headless checks** (`ghostMatches` filter trichotomy incl. fn-gets-handle +
    error-drops; handle `:move`/`:pos`/`:res` round-trip incl. keep-facing + bad-args→LuaError; `list` stable-handle
    + string filter; `destroyGhost` idempotent + owner-drop + dead-inert; `teardownGhosts`; `newGhost` validation +
    no-world nil-guard) + LuaJ parse. `hello` **v0.35.0** (OnEnterWorld spawns a cabin 3 tiles E, reads list/pos,
    `:move`s it, auto-destroys after 8s; `:hello ghost` toggles one at the player). Doc `v1-ghosts.md`. **First
    in-game run surfaced TWO render bugs (both FIXED, re-verify pending — §8):** (1) a client-only gob is **not in
    OCache**, so nothing `ctick`/`gtick`s its sprite → **nothing rendered**; the seam now makes MapView own a
    `clientGobs` list + `ctick`/`gtick` each ghost beside the `Plob` (`removeClientGob` now takes `(Gob,Slot)`);
    (2) game resources load via **`Resource.remote()`** (server pool), not `local()` (client jar only), so a terobj
    never resolved. **In-game verified ✅ (the cabin renders at the player). Committed `8a9f36eb`.**
    Deferred: `sdt`/alpha/tint/rotate (V3), clickability + `GhostClicked` (V2), layouts (V4), gizmo (V5/V6).
  - [x] **V2 — Clickable ghosts + `GhostClicked` (SAFE-tier, [D-032](decisions.md)).** ✅ (see STATUS §5; doc
    `v2-clickable-ghosts.md`) Opt-in clickable ghosts: `clickable=true` at `new` / `g:clickable(bool)` + per-ghost
    `onClick(g,button,x,y)` + the **owner-scoped** `GhostClicked{ghost,button,x,y}` event. **Mechanism (the real
    work):** a virtual gob's own `GobState` OMITS the `GobClick` (`if(!virtual)`), so a plain V1 ghost is unpickable
    — new **`GhostGob extends Gob`** overrides the `obstate(Pipe)` hook (called for every gob) to prep a `GobClick`
    **when `clickable`**, giving a virtual ghost a pick surface WITHOUT flipping `virtual` (so it stays OCache/
    server-invisible AND the `cg.virtual` fast-path keeps working). **Toggle = remove+re-add** (`setGhostClickable`):
    the `Clicklist` decides membership at slot-add time and never re-runs its filter on a later ancestor-state
    change, so a live toggle re-adds the gob (obstate re-applied fresh) — a `clickable`-at-create ghost needs no
    re-add (the deferred create sets the flag before `addClientGob`). **The second core edit** — a 3-line `// addon:`
    intercept at the TOP of [`MapView.Click.hit`](src/haven/MapView.java:2065) (beside the voice hooks): `cg.virtual`
    fast-path → `AddonManager.onGhostClick(cg,button,mc)` finds the owning clickable ghost, fires `onClick` + the
    owner-scoped `GhostClicked` (a ghost is private to its addon → the handle must not leak cross-addon), and
    **returns before `wdgmsg`** (consume — client-only ⇒ no server contact, stays safe-tier). Consume is
    UNCONDITIONAL for a clickable ghost (the DoD); a non-clickable ghost carries no `GobClick`, never wins a pick,
    stays click-through. **One `haven` edit** (the `Click.hit` intercept; the V1 `addClientGob` seam is reused).
    Compile OK + **27 headless checks** (`obstate` gates the `GobClick` via a `BufPipe`; `onGhostClick` dispatch
    null/unregistered/non-clickable/dead→false, clickable→fires onClick+event+consumes, consumes even with no
    onClick; `setGhostClickable` mirror + no-op edges — real `Sandbox.create()` env) + LuaJ parse. `hello` **v0.36.0**
    (`:hello ghost` = a CLICKABLE cabin with onClick; the V1 auto-demo stays non-clickable = click-through; a
    `GhostClicked` logger). Doc `v2-clickable-ghosts.md`. **In-game verified ✅. Committed `7d759f6f`.** Deferred:
    consume-vs-pass-through routing (V2 consumes unconditionally — forwarding to the gob behind needs a re-pick;
    use `:clickable(false)` for a normal click); an `iteminteract` held-item guard (flagged in the devlog).
  - [x] **V3 — Look & orientation.** ✅ (see STATUS §5; doc `v3-look-orientation.md`) `g:rotate(a)` (just
    `Gob.move(rc,a)`), `g:setRes(res[,sdt])` (deferred res-swap → `setattr(new ResDrawable)` under
    `synchronized(gob)` — the engine's own `$cres.apply` live-swap lock; a newer swap wins), `g:alpha(0..1)` +
    `g:tint{r,g,b[,a]}` (the "ghost" look) + `g:show()`/`g:hide()`, plus the `new{a,sdt,alpha,tint}` options. **The
    look states live in `GhostGob.obstate`** (extends V2's hook): `tint`→`MixColor` (GobHealth's tint pattern),
    `alpha<1`→`BaseColor(1,1,1,α)`+`FragColor.blend(BlendMode)`+`States.maskdepth` (the engine's translucent-overlay
    recipe — gridmat/selrect). Since `GobState.equals` ignores `obstate`'s output (like V2's clickable), a **live**
    alpha/tint/clickable change is applied by **remove+re-add of the scene slot** (factored into `refreshGhostScene`,
    shared with the refactored `setGhostClickable`); `:rotate`/`:move` ride `Placed.autotick`. The deferred create now
    reads the ghost's **current** res/sdt + applies alpha/tint/hidden at publish, so a verb in the streaming-in window
    takes effect on appearance. **Colour = named-key `{r=,g=,b=[,a=]}`** reusing the shipped `luaColor` (markers/party/
    kin), NOT the spec's positional example (one canonical colour form). **ZERO core edit** (reuses the V1
    `addClientGob`/`removeClientGob` seam; only `io.brodgar.addon` — `GhostGob`/`LuaGhost`/`AddonManager`). Compile OK +
    **33 headless checks** (`obstate` state-gating via `BufPipe`: clickable→GobClick / alpha<1→BaseColor+blend / tint→
    MixColor / alpha==1 boundary / all-composed; parsers `clampAlpha`/`luaAlpha`/`luaTint`/`luaSdt` incl. byte round-trip
    — same-package + reflection) + LuaJ parse. `hello` **v0.37.0** (OnEnterWorld cabin spawns rotated+translucent+tinted,
    live res-swaps + rotates at +3s, hide/show at +5/6s, destroys +8s; `:hello ghost` = a clickable translucent cabin
    whose onClick live-cycles `:rotate`+`:alpha`). Doc `v3-look-orientation.md`. **In-game DoD pending** (rotated
    translucent cabin; res-swap morphs it; `:reload` leaks nothing). *(Java engine change ⇒ rebuild + restart.)*
    Deferred: `:scale` (→V6), grid-anchored layouts + `planner` (→V4), the gizmo (→V5/V6).
  - [x] **V4 — Layouts + `planner` example addon.** ✅ (see STATUS §5; doc `v4-layouts-planner.md`) New
    primitive **`hafen.map.fromGridPos(anchor)`** — the exact **inverse** of `gridPos` — via one new
    `haven`-package accessor `AddonWidgets.gridWorldUL` (grid-by-stable-id → world; **zero `MCache`/core edit**).
    New **`planner`** example addon (no permissions, safe-tier): `:planner place` spawns a clickable translucent
    blueprint ghost anchored via `gridPos`; `OnEnterWorld` reloads the per-char store layout + re-resolves each
    anchor via `fromGridPos`, **retrying** as grids stream in; **click-to-select** (V2), `:planner rotate` persists
    facing, plus `list`/`select`/`remove`/`clear`/`blueprint`. `hello` untouched (`planner` is the V-series example,
    D-031). Compile OK + `ant bin` packages it; **headless LuaJ parse + a real store JSON round-trip** (19-digit
    `gridId` survives as an exact string; nested `items[]`/`anchor{}` preserved; empty→`[]`) + the `fromGridPos`
    arithmetic round-trip. **In-game verified ✅. Committed `186b23b9`** (placed several, click-selected, relog →
    reloaded at the same grid position). *(Java engine change ⇒ rebuild + restart.)*
  - **V5 — Gizmo: move (+ placegrid snapping, [D-033](decisions.md)).** *(Split into V5a primitives + V5b arrow
    gizmo — the D-031 seam: Java exposes primitives, the gizmo behaviour is a bundled Lua library. Each is one
    in-game-verifiable increment.)*
    - [x] **V5a — Gizmo primitives + planner move-mode.** ✅ (see STATUS §5; doc `v5a-gizmo-primitives.md`) The
      three Java primitives: **`hafen.map.screenToWorld(sx,sy,fn)`** — the raycast inverse of `worldToScreen`, via
      the engine's own [`Maptest`](src/haven/MapView.java:1981) GPU pass (subclassed inline from the bridge — the
      class is public, **zero core edit**); **ASYNC by necessity** (GPU→CPU readback, like the placement Plob), so
      `fn({x,y})` / `fn(nil)` is called a frame later. **`hafen.map.snapPlace(x,y[,fine])`** + **`placeGrid()`** —
      reuse the client's placegrid snapper via **one `// addon:` refactor** factoring `StdPlace`'s snap math verbatim
      into a shared static **`MapView.placeSnap(Coord2d,int)`** (no drift; the preferred D-033 option), `fine`→SHIFT.
      **`hafen.hook.grab{move,up}`** — the drag-capture primitive: a new visible **`LuaMouseGrab extends Widget`** on
      `ui.root` (broadcast `MouseMoveEvent` reaches every visible widget; `ui.grabmouse` captures the terminating up +
      down/wheel → **no camera pan**, the "camera stays put" DoD, zero core edit — the `Window`-drag pattern);
      `mods={shift,ctrl,alt}` (no Lua bit ops); bridge-owned (`Addon.mouseGrabs`) + deferred self-unlink; `{ :release()
      }`. **Threading:** input dispatch (`UILoop.Frame.tick`) and the Maptest readback BOTH hold `synchronized(ui)`, so
      all addon Lua stays serialized (the V2-click/L3 guarantee). **One `// addon:` core edit** (`MapView.placeSnap`);
      rest is `io.brodgar.addon` (new `LuaMouseGrab` + `AddonManager` + `Addon`). Compile OK + **9 headless `placeSnap`
      checks** (tile-centre incl. negatives / sub-tile placegrid / free at plobpgran 0, replicated on real `Coord2d`
      since `MapView.<clinit>` needs GL) + LuaJ parse. **`planner` v0.2.0** move-mode `:planner grab` (selected ghost
      follows the cursor snapped to the placegrid; SHIFT=fine; click to drop + re-anchor + persist; coalesced
      raycasts; ghosts made **opaque** post-verify — translucent was too faint). `hello` untouched. **In-game verified
      ✅. Committed `b8526302`.** *(Java engine change ⇒ rebuild + restart.)* Deferred to V5b: the arrow handles + axis
      constraint (`hafen.ghost.gizmo`).
    - [x] **V5b — The transform gizmo (Unity-style, drawn with `g:draw`).** ✅ (see STATUS §5; doc `v5b-gizmo.md`) The
      bundled Lua gizmo library (D-031) as a new **`planner/gizmo.lua`** installing a `gizmo(target, opts)` global
      (mirrors the api-reference `hafen.ghost.gizmo` shape; NOT a `hafen.*` global — a planner-shipped Lua library,
      promotable later). **Maintainer chose the spec §4 "2D-projected" path** over 3D arrow-mesh ghosts (no arrow
      resource ships in the jar): the handles are **drawn** — red **X** / green **Y** arrow shafts (`g:line`) + FILLED
      TRIANGLE heads + a yellow free **centre** (`g:frect`) — on a `hafen.ui.overlay`, **projected from the world axes
      each frame** (`hafen.player.worldToScreen`, so they foreshorten with the camera), the arrow-head a fixed SCREEN
      size (grabbable at any zoom). **Pick** = `hafen.hook.input("mapview","mousedown")` screen-space hit-test →
      `ev:preventDefault()` (no map click / camera / V2 select) → arm `hafen.hook.grab` on the real press (true
      press-drag-release; the FIRST up IS the drop, no pick/timing ambiguity). **Drag** = `screenToWorld` →
      **axis-constrain** (X arrow varies world-X keeping the start-Y line; Y arrow the mirror; centre free — clean
      because `placeSnap` snaps each component independently) → `snapPlace` (SHIFT=fine, D-033) → `target:move`; camera
      fixed via the grab; `onCommit` re-anchors + persists. Hover-highlight via a second (non-preventing) mousemove
      hook. **Zero `haven` core edit** — the only new Java is a **`g:poly`** filled-convex-polygon primitive added to
      our own `LuaGOut` (public `GOut.drawp(TRIANGLE_FAN)` + public `GOut.tx`; reusable by all addons). Bridge-owned
      teardown (overlay/hooks/grab) + planner detaches on select-change/grab/remove/clear/relog/disable. Compile OK +
      headless (real-`Sandbox` load of `gizmo.lua` → `gizmo` global is a function; target-validation rejects nil/`{}`/
      pos-only before touching `hafen`; `main.lua` parses) + `ant bin`. `planner` **v0.3.0** (`:planner gizmo` toggle;
      `hello` untouched). **In-game DoD pending.** *(Java engine change ⇒ rebuild + restart.)* Deferred to V6: rotate
      ring (`snapAngle`/`:placeangle`) + `g:scale` + draw-on-top/constant-size polish; promote to a shared
      `hafen.ghost.gizmo` when a 2nd addon needs it.
  - [x] **V6 — Gizmo: rotate (+ placeangle) + scale + polish (stretch).** ✅ (see STATUS §5; doc
    `v6-gizmo-rotate-scale.md`) Completes the transform gizmo. **Rotate:** new **`hafen.map.snapAngle(a[,fine])`**
    + **`placeAngle()`** — the ABSOLUTE analog of the wheel-relative `StdPlace.rotate` (45° coarse / `π/plobagran`
    fine, normalized to (-π,π]); a **zero-edit bridge mirror** reading the public `MapView.plobagran` (no verbatim
    StdPlace code to share, unlike position's `placeSnap`). **Scale:** **`g:scale(s)`** = a `Location.scale` prepped
    in `GhostGob.obstate` — composes UNDER the gob's translate+rotate (child render slot) → **T·R·S**, i.e. in-place
    scaling around the local origin (**zero core edit**); mirrored like alpha/tint (re-add via `refreshGhostScene`),
    applied at deferred-create publish, clamped 0.01..100; **`g:pos()` now `{x,y,a,scale}`**. The gizmo (`gizmo.lua`)
    gains a cyan **rotate ring** (relative drag → `snapAngle`, SHIFT fine), a magenta **scale box** (screen-distance
    drag → `g:scale`), and a **`mode`** (`move`/`rotate`/`scale`/`all`, default all; `:setMode`/`:mode`) + a pure
    `atan2` (no `math.atan2` dep). **Polish falls out of the 2D-projected path** (draw-on-top HUD overlay = no depth
    occlusion; grab handles constant screen size; only the axis shafts foreshorten). **Zero `haven` core edit**
    (only `io.brodgar.addon` + the planner Lua). Compile OK + **14 headless checks** (real-`Sandbox` gizmo load +
    target-validation + quadrant-correct `atan2` + `main.lua` parse) + a separate `snapPlaceAngle` math check + `ant
    bin`. `planner` **v0.4.0** (`:planner gizmo [mode]`/`scale`, gizmo onCommit persists facing+scale, grid-anchored).
    Doc `v6-gizmo-rotate-scale.md`. **In-game verified ✅. Committed `9d13b6e7`.** *(Java engine change ⇒ rebuild +
    restart.)* **This completes the V-series** (client-only ghosts + the full transform gizmo). Deferred: promote to
    a shared `hafen.ghost.gizmo`, multi-select/group transform, non-uniform/snapped scale.

- **R — Custom rendering (`hafen.render.*`): non-`.res` images & 3D models (SAFE-tier, client-only).** *(Split into
  R1 screen-2D + R2 world-2D + R3 glTF-3D, like the V-series.)* 🟢 **Decisions RATIFIED** (2026-07-26) —
  [17-custom-rendering.md](17-custom-rendering.md) + [18-custom-models-gltf.md](18-custom-models-gltf.md) (decisions
  [D-034](decisions.md)/[D-035](decisions.md) **ratified**; slices open). A namespace for assets that are NOT
  engine `.res` — **PNG** (screen + world) and **glTF** 3D models — exposing the substrate `.res` already uses
  ([`ImageIO.read`→`TexI`](src/haven/Resource.java:1061); engine `Model`/`Material` from glTF). **`hafen.ghost` stays
  `.res`-only, unchanged.** Loaders `hafen.render.image`/`model` feed a **shared world-entity core** (the generalized
  V-series) with a **pluggable visual**; the gizmo works on any handle. **NOT gated** (client-only, like
  `hafen.ui.overlay`/ghosts — [D-029](decisions.md)). Specs: `17-custom-rendering.md`, `18-custom-models-gltf.md`,
  `code-map.md` (R-series seams), `api-reference.md` (`hafen.render.*`). **Overall DoD:** an addon draws a PNG icon
  in its UI, stands a PNG in the world (billboard + fixed), and places a glTF model — all client-side, no `.res`,
  gizmo-transformable; `:reload` leaks nothing.

  - [x] **R1 — 2D image on screen (`hafen.render.image` + `g:image`).** ✅ (see STATUS §5; doc `r1-images-screen.md`)
    `hafen.render.image(path)` → a `TexI`-backed, **cached, bridge-owned** handle (`:size()`→`{w,h}` / `:dispose()`),
    decoded synchronously via `ImageIO.read` → `new TexI(img)` from the addon's own folder (new `resolveAddonAsset`:
    resolve under `Addon.dir` then `startsWith(base)` — **one containment check rejects both absolute and `..`-escape**,
    D-017), one handle per (addon, path); + `g:image(img,x,y[,w,h])` (native/scaled →
    [`GOut.image(Tex,Coord[,Coord])`](src/haven/GOut.java:97)) + `g:aimage(img,x,y,ax,ay)`
    (→ [`GOut.aimage`](src/haven/GOut.java:107)) on the shared [`LuaGOut`](src/io/brodgar/addon/LuaGOut.java) (all
    draw surfaces at once; a nil/disposed handle draws nothing). The handle carries its `LuaImage` as an **opaque
    userdata** (the `LuaMarshal` facade-safe pattern, P1 — no Java method reachable, unforgeable) so the draw verbs
    `resolve` it back to the `TexI`; `volatile dead` guards the blit so `:dispose()` is final (no `TexI.st()`
    re-upload). **ZERO `haven` core edit** (all public: `GOut.image`/`aimage`, `new TexI`, `ImageIO`) — new
    `LuaImage.java` + `Addon.images` + `AddonManager` (facade + `newImage`/`imageHandle`/`disposeImage`/
    `teardownImages`, wired into `teardown`). Compile OK + `ant bin` packages the asset + **33 headless checks**
    (`resolveAddonAsset` containment; `LuaImage.resolve` userdata round-trip + foreign-value reject; `newImage`
    end-to-end decode→handle→`:size`→cache-same→`:dispose` dead+drop+idempotent→post-dispose fresh handle;
    validation rejects) + LuaJ parse. `hello` **v0.38.0** (loads `icon.png` — a 32×32 RGBA test asset — at OnLoad;
    draws it native+scaled in the 2a window and anchored in the 2b HUD overlay). **In-game verified ✅. Committed
    `45d851b9`.** *(Java engine change ⇒ `ant` rebuild + restart.)* Deferred: async decode for large assets,
    image-from-bytes/data-URI, `TexI` filter control.
  - **R2 — 2D image in the world (`hafen.render.sprite`, billboard + fixed).** Two world visuals on the shared
    core (§ [17](17-custom-rendering.md) §2/§5). *(Split into R2a fixed + R2b billboard — the fixed quad also does
    the shared-core generalization the billboard reuses; each is one in-game-verifiable increment.)*
    - [x] **R2a — fixed sprite (`TexI`-quad world geometry) + the shared-core generalization.** ✅ (see STATUS §5;
      doc `r2a-sprites-world.md`) `hafen.render.sprite{image, x, y [, a] [, scale] [, alpha] [, tint]}` → a transform
      handle (`:move`/`:rotate`/`:scale`/`:alpha`/`:tint`/`:show`/`:hide`/`:pos`→`{x,y,a,scale}`/`:image`/`:destroy`),
      gizmo-compatible. **Generalizes the V-series core** (D-013, the "one real refactor"): a new base
      **`LuaWorldEntity`** holds the transform/look/scene/lifecycle + the gizmo; `LuaGhost`/new **`LuaSprite`** are
      just visuals on it (the `AddonManager` scene helpers renamed `*Ghost`→`*Entity`, widened; `addEntityHandle`/
      `entityMatches` factored). The **fixed quad** = a resource-free **`SpriteQuad`** — a 4-vert `TRIANGLE_STRIP`
      [`Model`](src/haven/render/Model.java:45) ([`Homo3D.vertex`](src/haven/render/Homo3D.java:41) VEC3 +
      [`Tex2D.texc`](src/haven/render/Tex2D.java:36) VEC2, upright, aspect-sized to ~1 tile) wrapped by
      [`Material`](src/haven/Material.java:143)`(tex.st(), blend, maskdepth, nofacecull)` on a
      [`SprDrawable`](src/haven/SprDrawable.java:40), reusing the `GhostGob` `obstate` (tint/alpha/scale) + the V1
      `addClientGob` seam. **Synchronous create** (the `TexI` is already decoded → no `Loading`, unlike a ghost);
      **click-through** in R2a (the V2 click dispatch stays ghost-only). **Zero `haven` core edit.** Compile + `ant
      bin` + **33 headless checks** (`spriteWorldDims` aspect/degenerate; `SpriteQuad.quadVerts` upright geometry +
      texcoords + real `Model` builds; the generalized `entityMatches` filter) + LuaJ parse. `hello` **v0.39.0**
      (`:hello sprite` stands `icon.png` upright, then live-`:move`/`:rotate`/`:scale`s it). **In-game DoD pending.**
      *(Java engine change ⇒ rebuild + restart.)* Deferred to R2b: the billboard, sprite click/gizmo-select, planner
      integration.
    - [x] **R2b — billboard sprite (`billboard=true`, camera-facing) + gizmo/planner integration.** ✅ (see STATUS §5;
      doc `r2b-billboard-sprite.md`) The **second visual on the shared R2a core**: `hafen.render.sprite{…,billboard=
      true}` → a new resource-free **`LuaSpriteBillboard extends Drawable implements PView.Render2D`** (the
      `SpeakerIcon`/`LuaGobOverlay` pattern) whose `draw` projects the gob origin ([`Homo3D.obj2view`](src/haven/render/Homo3D.java:201))
      and blits the `TexI` bottom-centred, reading the `GhostGob`'s live alpha/tint/screen-scale. It is a **`Drawable`**
      (not a bare `GAttrib`) so the gob keeps a Drawable → dodges [`Gob.ctick`](src/haven/Gob.java:463)'s
      empty-virtual-gob `oc.remove` cleanup, and [`Gob.added`](src/haven/Gob.java:761) registers its `Render2D` in the
      2D pass (membership by slot-object type — why `SpeakerIcon` renders). Position/gizmo-move apply; world-rotate/
      scale do not (2D). Also **generalized the V2 click dispatch to sprites**: `findGhostByGob`→`findEntityByGob`
      over `LuaWorldEntity` (ghosts + sprites), `onGhostClick` (same `Click.hit` entry — **no new core edit**) fires
      the subclass-named event (`clickEvent()`/`clickKey()`) — a **fixed** sprite is now `clickable` (quad in the
      clickmap), firing `onClick` + the owner-scoped **`SpriteClicked`**; billboards have no mesh → never picked.
      **Zero `haven` core edit** (reuses V1 `addClientGob` + V2 `Click.hit`); only `io.brodgar.addon`. Compile + `ant
      bin` + **LuaJ parse** (hello/planner/gizmo) + **pure billboard colour-math checks** (`clampByte`/`lerpByte`).
      `hello` **v0.41.0** (`:hello billboard`); **`planner` v0.5.0** — records generalized to ghost **or** sprite
      (`kind`/`img`/`billboard`, `it.ghost`→`it.entity`, one code path selects/gizmos/persists both), `:planner
      sprite [billboard]`, ships `planner/icon.png`. **In-game DoD pending** (billboard faces camera; both gizmo-move;
      relog restores; `:reload` leaks nothing). *(Java engine change ⇒ rebuild + restart.)* **Completes R2.** Deferred
      to R3: glTF model. Also deferred: a billboard **pick** (screen-space hit-test) so billboards click-select too.
  - **R3 — custom 3D model in the world (`hafen.render.object` + glTF static loader).** The big one — full plan
    in [18-custom-models-gltf.md](18-custom-models-gltf.md). glTF 2.0 static subset ([D-035](decisions.md)): `.glb`
    reader + accessor/index decode (pure Java over [`Json`](src/io/brodgar/addon/Json.java), no native deps) → engine
    `Model`+`Material` per primitive → `Sprite` → `SprDrawable` on the shared core. `hafen.render.model(path)` +
    `hafen.render.object{model=,…}`. *(Split into R3a parse+mesh, R3b textures/material, R3c lighting — each one
    prompt + one in-game verification; skins/animation deferred to a later series.)*

    - [x] **R3a — glTF parse + static mesh, unlit + basis/units conversion.** ✅ (see STATUS §5; doc
      `r3a-models-world.md`) `hafen.render.model(path)` → a cached, bridge-owned **`LuaMesh`** handle
      (`:bounds()`→`{min,max,size}` world units / `:dispose()`) parsed by a **new pure-Java `Gltf`** (`.glb`
      header/chunks + `.gltf` **base64 data-URI**/external buffers over our `Json`, no native deps; accessor decode —
      6 componentTypes + stride + normalization — + indices; **node-transform baking** down the scene tree; a **basis
      conversion** glTF +Y-up-metres → H&H +Z-up with **1 metre = 1 tile** [a det-+1 rotation × unit scale, so winding
      survives for R3b]; caps `MAX_PRIMS`/`VERTS`/`BYTES` + named errors for unsupported features, D-018). `hafen.render.
      object{model,x,y[,a,scale,alpha,tint,clickable,onClick,follow,offset]}` → a **`LuaObject extends LuaWorldEntity`**
      standing it in the world on the shared R2 core (transform/look/`follow`/gizmo, synchronous create), visual = a new
      resource-free **`MeshSprite`** (one `POSITION`-only `Homo3D.vertex` `Model` + a flat **`BaseColor`**
      [`baseColorFactor`] **unlit** `Material`, `nofacecull` double-sided, per glTF primitive). V2 pick generalized to
      objects (`findEntityIn` also scans `Addon.objects`) → the owner-scoped **`ObjectClicked`**. **Zero `haven` core
      edit** (reuses V1 `addClientGob` + V2 `Click.hit`; render primitives + `Matrix4f`/`Coord3f` all public); only
      `AddonManager.java` + `Addon.java` changed, + 4 new addon classes. Compile OK + `ant bin` (ships the `.glb`) +
      **27 headless parser checks** (`.glb`/`.gltf`+data-URI; indexed+non-indexed; TRS + parent→child baking; the basis
      round-trip — a real cube comes out upright, 1 tile tall; baseColorFactor + default white; doubleSided; the 6 error
      paths) + LuaJ parse of `hello`/`planner`/`gizmo`. `hello` **v0.42.0** (ships `cube.glb`; `:hello object` stands +
      live-transforms a glTF cube). Doc `r3a-models-world.md`. **In-game verified ✅. Committed `203a2622` (bundled
      with R3b-1).** *(Java engine change ⇒ rebuild +
      restart.)* Deferred to R3b/R3c: textures + `TEXCOORD_0` + multi-material + alpha modes (R3b); `NORMAL` + engine
      lighting + sRGB (R3c); skins/animation, Draco/meshopt, async decode (later).
  - **R3b — textures + multi-primitive/material.** *(Split into R3b-1 engine-rendering + R3b-2 planner-integration —
    too big for one prompt + one in-game verification: the textured multi-material render is a complete increment
    verifiable via `:hello object` on its own; the planner editor flow is a distinct Lua slice. Same a/b split as R2.)*
    Spec: `18-custom-models-gltf.md` §5. **Overall DoD:** a textured multi-material `.glb` renders correctly + gizmos in planner.
    - [x] **R3b-1 — textures + TEXCOORD_0 + multi-material + alpha modes/cull (the render).** ✅ (see STATUS §5; doc
      `r3b1-textures-materials.md`) `Gltf` now decodes **`TEXCOORD_0`** + the full material (`baseColorTexture`,
      `alphaMode` OPAQUE/MASK/BLEND, `alphaCutoff`, `doubleSided`) and **extracts each referenced image to a raw byte
      blob** (`bufferView` slice / `data:` URI / external via the R3a `Loader`), **lazy + deduped** per glTF image
      (`tank.glb`'s 53 materials → **4** images) — staying pure (no GL/`ImageIO`, still headless). `newMesh` decodes the
      blobs to **shared `TexI`s owned by `LuaMesh`** (`new TexI(img,false)` — no POT rounding, so `[0,1]` UVs sample the
      whole image; freed in `disposeMesh`, teardown-ordered after objects). **`MeshSprite`** builds a
      `POSITION`+`TEXCOORD_0` interleaved `Model` + a per-material `Material` (**`TexDraw` × `BaseColor`** = texture ×
      `baseColorFactor`; `MASK`→`TexClip` / `BLEND`→`FragColor.blend`+`maskdepth`; `doubleSided`→`nofacecull` else
      back-face `Facecull`), sharing one `TexRender` per image. Still **unlit** (lighting → R3c). New mesh-handle
      **`:info()`** (`{prims,textured,textures,verts,tris}`). **Zero `haven` core edit** (all texture/material primitives
      public; reuses V1 `addClientGob` + V2 `Click.hit`). Compile + `ant bin` + **43 headless parser checks** (real
      `tank.glb` all-textured/4-deduped-images/OPAQUE/doubleSided/UVs-not-baked; synthetic data-URI-`MASK`/`BLEND`/
      external-loader/untextured/no-image-error; cube basis regression) + LuaJ parse. `hello` **v0.43.0** (`:hello
      object` stands the tank **textured**, scaled from `:bounds()` to ~2 tiles; logs `:info()`). **In-game verified
      ✅. Committed `203a2622` (bundled with R3a).** (Tank renders textured; UV `v`-orientation correct — `TEXV_FLIP`
      stays false.) *(Java engine change ⇒ rebuild + restart.)*
    - [x] **R3b-2 — planner integration (`:planner object`).** ✅ (see STATUS §5; doc `r3b2-planner-object.md`) The
      object analog of R2b: a `kind="object"` planner record + **`:planner object`** stands a shipped **`cube.glb`** (the
      940-byte R3a cube) at your feet, **click-selectable** (its mesh is in the clickmap → per-object `onClick` + the
      owner-scoped **`ObjectClicked`**), **gizmo-driven** (the same transform handle `:hello object` proves), and
      **grid-anchor-persisted** (a `model` path stored beside `res`/`img`, re-resolved via `hafen.map.gridPos`/
      `fromGridPos` on relog). Highlights by **alpha** (a colour tint would recolour the model's texture, like a sprite).
      **Lua-only** — the object render + transform handle + V2 pick/`ObjectClicked` + gizmo-compatibility all shipped in
      R3a/R3b-1, so ONLY `addons/planner/` changed (**zero** `haven` core edit, no `io.brodgar.addon` change). Compile
      still **BUILD SUCCESSFUL** (nothing broke) + `ant bin` packages `cube.glb` + **LuaJ parse** (planner/gizmo/hello all
      clean). `planner` **v0.6.0** (ships `cube.glb`; `:planner object`; `ObjectClicked` listener; records carry `kind`
      ghost/sprite/**object** + `model`). **In-game DoD pending** (place → click-select → gizmo-move → relog restores).
      **Completes R3b.** *(No rebuild — Lua reload: `ant bin` to package + `:reload`/relog.)*
    - [x] **R3c — lighting polish.** ✅ (see STATUS §5; doc `r3c-lighting.md`) glTF models now **shade with the world
      lights** instead of drawing fullbright. `Gltf` bakes per-vertex **`NORMAL`** (from the attribute, transformed by
      the **inverse-transpose** of the `basis·node` matrix — `trim3(transpose(invert(fin)))` — so non-uniform node scale
      shears them right; or **computed smooth** = area-weighted face normals from the baked geometry when absent) +
      **`emissiveFactor`**, both baked H&H-local, parser still pure/headless-testable. **`MeshSprite.buildModel`** became a
      generic interleaver (`POSITION` + `NORMAL`-when-lit + `TEXCOORD_0`-when-textured → stride 12/20/24/32) feeding
      **`Homo3D.normal`**, and each lit material adds a **`Light.PhongLight`** so the engine `Phong` shader multiplies the
      MapView scene's world lights into the fragment (albedo = R3b's texture × `baseColorFactor`; `emissiveFactor`→`emi`;
      neutral matte reflectance — engine defaults amb 0.2/dif 0.8/no spec — per-fragment). New `:info().lit` count.
      **sRGB = deliberate no-op** (the engine never `.srgb()`s model textures → our `UNORM8` `TexI`s already match).
      **Zero `haven` core edit** (reuses V1 `addClientGob` + R3b material path; `Homo3D.normal`/`Light.PhongLight` public;
      only `Gltf`/`MeshSprite`/`AddonManager`). Compile OK + **10 headless parser checks** (synthetic with/without-NORMAL
      triangles agree on `(0,-1,0)` + emissive + unit-length; real `tank.glb` all 53 prims lit + unit) + LuaJ parse of all
      addons. `hello` **v0.44.0** (`:hello object` now stands the tank **lit**). Doc `r3c-lighting.md`. **In-game DoD
      pending.** **Completes R3 + the whole R-series.** *(Java engine change ⇒ rebuild + restart.)* Deferred:
      `emissiveTexture`, `TEXCOORD_1`, sampler wrap/filter, full PBR maps, a tunable per-object reflectance/shine,
      cel-shading to match the world's cel look.

- **N — Data & networking (`hafen.json` + `hafen.http`): JSON + external requests.** *(Split into N1 json + N2a
  http-get/substrate + N2b http-post, like the V/R-series.)* 🟢 **Decisions RATIFIED** (2026-07-26) —
  [19-data-and-network.md](19-data-and-network.md) (decisions [D-036](decisions.md)/[D-037](decisions.md) **ratified**;
  slices open). Two sibling namespaces: **`hafen.json`** (parse/encode, **ungated**, reuses the existing reader + REPL
  writer) and **`hafen.http`** (external GET/POST — **async by necessity**, callback marshalled to the tick like
  gob-deltas, a `:cancel()` handle bridge-owned in `Addon.requests`). **`hafen.http` is GATED** by a manifest
  `network` block whose `hosts` array is the allowlist ([D-037](decisions.md)); private/loopback IPs blocked;
  size/timeout/concurrency caps ([D-018](decisions.md) spirit). `HttpURLConnection` (Java 1.8-compatible, unlike
  `java.net.http.HttpClient`). Specs: `19-data-and-network.md`, `api-reference.md` (`hafen.json`/`hafen.http`),
  `code-map.md` (N-series seams). **Overall DoD:** an addon fetches JSON from an allowlisted URL and parses it; a
  disallowed host / private IP is refused; `:reload` cancels in-flight, leaks nothing.

  - [x] **N1 — `hafen.json` (parse/encode).** ✅ (see STATUS §5; doc `n1-json.md`) `hafen.json.parse(str)` (→ Lua
    value; objects → string-keyed tables, arrays → 1-based; JSON `null`→`nil` **absent-key/array-hole caveat**;
    integral numbers → Lua ints; malformed / over the `-D`-tunable size+depth caps → pcall-able `LuaError`) and
    `hafen.json.encode(value)` (→ compact JSON; **strict** — function/userdata/thread/cycle/non-finite → `LuaError`,
    unlike the REPL's forgiving echo). **The one refactor (D-013):** the REPL writer moved from `AddonManager.json`
    into `Json.write(v[,strict])`, so REPL echo + `hafen.store` persistence + `hafen.json.encode` share **one**
    serializer; the JSON→Lua marshal centralized into `LuaMarshal.jsonToLua` (integer-preserving), shared by
    `hafen.store` restore. **Zero `haven` core edit** (three files: `Json`, `LuaMarshal`, `AddonManager`). Compile OK
    + **27 headless checks** + LuaJ parse; `hello` v0.45.0 round-trips a table at OnLoad. **In-game DoD pending.**

  - [x] **N2a — `hafen.http.get` + the async/security substrate.** ✅ (see STATUS §5; doc `n2a-http-get.md`)
    `hafen.http.get(url[,opts],cb)` → `{ :cancel() }`; async (returns immediately, `cb(res)` on the tick).
    A shared engine-lifetime bounded daemon `ExecutorService` runs `HttpURLConnection` GET off the UI thread;
    an `HttpCompletion` queue is drained on tick (new step **1a** `drainHttp`, beside `GobEvent`) → armed +
    isolated callback with `res={ok,status,body,headers(lower-cased),error}` (`ok`=a reply arrived, any status;
    `!ok`=transport failure). Handle owned in `Addon.requests`, cancelled on teardown (**callback never fires**).
    **Security:** new **`network` manifest block** (`Manifest.network`/`usesNetwork`/`hostAllowed` — exact ci +
    `*.domain`, disk `"*"` rejected; REPL=allow-all) gated at call by `requireNetwork`; **private/loopback/
    link-local IP block** on the resolved address (`LuaHttp.isBlockedAddress` via `InetAddress` classifiers +
    manual `fc00::/7`); size (8 MB) / timeout (10 s, cap 60 s) / per-addon in-flight (6, **non-blocking**
    UI-thread scheduler `maybeStartHttp`; hard cap 64 → LuaError) / pool (8) caps; generic UA, no cookies,
    hop-by-hop headers stripped (`headerAllowed`), TLS verified, **no redirects** (3xx raw). AddOns panel shows a
    `[net]` badge + declared hosts (tooltip). **Zero `haven` core edit** — new `LuaHttp`/`LuaHttpRequest`; edits
    to `Manifest`/`Addon`/`AddonManager`/`ui.AddonPanel`. Compile OK + `ant bin` + **38 headless checks**
    (manifest parse / host allowlist / private-IP block v4+v6 / header hygiene) + LuaJ parse. New **`netdemo`**
    example addon (`:netdemo get|bad|lan`). **In-game DoD pending.** *(Java engine change ⇒ rebuild + restart.)*

  - [x] **N2b — `hafen.http.post` + rich headers + redirect-follow.** ✅ (see STATUS §5; doc `n2b-http-post.md`)
    `hafen.http.post(url, body[,opts], cb)` — `body` = a **string** verbatim or a **table** (→ strict `Json.write`
    + `Content-Type: application/json` unless the addon sets its own); same gate/limits/`res`/async as `get`.
    **Redirect-following** for BOTH verbs: `LuaHttp.perform` is now a hop-loop following ≤5 `3xx` (`MAX_REDIRECTS`,
    `-D`-tunable) with a new **`validateHop`** that **re-checks the allowlist + private-IP block on every hop** — a
    redirect to a non-allowlisted/private host aborts (`ok=false`), so a `3xx` can't escape the declared hosts;
    `303`/POST-`301`/`302` demote to `GET`+drop-body, `307`/`308` preserve. Thin add on the N2a substrate (no new
    fields/threads/manifest); `AddonManager` gained the `post` facade + `httpBody`/`hasContentType`. **Zero `haven`
    core edit** (`LuaHttp`/`AddonManager` + a comment in `LuaHttpRequest`). Compile OK + `ant bin` + LuaJ parse
    (`netdemo`/`hello`); the live POST/redirect paths are in-game-only (no headless session to drive the tick drain).
    `netdemo` **v0.2.0** (`:netdemo post|redirect|escape` added; hosts gains `httpbin.org`). **In-game DoD pending.**
    **Completes the N-series.** *(Java engine change ⇒ rebuild + restart.)* Deferred (§9): DNS-rebinding hardening,
    a generic `request{method=}`/PUT·DELETE·PATCH, non-default ports, streaming/download.

- **U — UI-API extensions (widget drops + `g:resource` + mouse mods).** *(maintainer-requested 2026-07-26.)*
  Three small, **additive** UI primitives that unblock drag-drop custom UI (e.g. a future "ActionBars" addon:
  drag an action from the menu grid onto a client-only bar, render its icon, move the bar with Shift, persist it).
  **Independent** of R3b-2/R3c and the N-series — the maintainer picks order (§6). Decisions
  [D-038](decisions.md)/[D-039](decisions.md)/[D-040](decisions.md); specs `07-ui-and-drawing.md` (+ `api-reference.md`,
  `code-map.md`). All in `io.brodgar.addon`, **zero `haven` core edit** (the engine already dispatches menu-grid
  drops generically). **Overall DoD:** drop an action from the menu grid onto a bridge widget → its icon renders +
  the `res` logs; Shift+click reports `shift=true`; `:reload` leaks nothing.

  - [x] **U1 — Widget `onDrop` + `g:resource` + mouse `mods` (one build).** ✅ (see STATUS §5; doc
    `u1-widget-drops-resource-mods.md`) Three additive UI primitives in one build, **zero `haven` core edit**,
    all ungated. **(a) `onDrop`** (D-038): [`LuaWidget`](src/io/brodgar/addon/LuaWidget.java) now
    `implements DropTarget`; a menu-grid drop reaches the widget under the cursor via the engine's own generic
    dispatch (`DropTarget.Drop` walked by `PointerEvent.propagation`, `cc` already widget-local) as
    `onDrop(x,y,{kind="pagina",res="<name>"})` — a **neutral facade-safe descriptor** (a resource name is
    plain data → ungated, D-017); `res` present only for **resource-based** paginae (`pag.id instanceof
    Indir`, `Loading`-guarded) — an id-only pagina carries `kind` alone (not persistable); truthy consumes.
    **(b) `g:resource(name,x,y[,w,h])`** (D-039) on the shared [`LuaGOut`](src/io/brodgar/addon/LuaGOut.java) —
    the `.res` sibling of `g:image`: blits an engine resource's default image layer (`Resource.imgc`) **by
    name**, async + name-cached (static `LuaGOut` map, cleared on `:reload`) + `Loading`-guarded (draws
    nothing until ready; bad name → nothing, never throws); static icon only. **(c) mouse `mods`** (D-040):
    every widget mouse callback (`onClick`/`onMouseUp`/`onMouseMove`/`onWheel`) gains a trailing
    `{shift,ctrl,alt}` table from `ui.modflags()` (shared `AddonManager.modsTable`, mirrors `hook.grab`) —
    branch on the modifier at press time. **Zero `haven` core edit** (`LuaWidget`/`LuaGOut` + one line in
    `AddonManager.reload()`). Compile OK + LuaJ parse of `hello`. `hello` **v0.46.0** (a borderless
    drop-target box below the 2a window: drop an action → its icon draws via `g:resource` + the `res` logs;
    Shift+click → `shift=true`). Doc `u1-widget-drops-resource-mods.md`. **In-game DoD pending** (drag an
    action onto the box → icon renders + res logs; Shift+click → shift=true; `:reload` leaks nothing).
    *(Java engine change ⇒ rebuild + restart.)* Deferred: activating a dropped action (the menu-ability
    primitive — a resolvable ability handle + gated `use`); item drops (`DTarget.drop`/`iteminteract`);
    `g:resource` live sprites/cooldown (`g:ability`); the `Inventory.invsq` empty-slot `TexI`.

- **W — Widget introspection (walk the guts of any widget).** *(maintainer-requested 2026-07-26.)* A **generic,
  read-only** way to walk *any* server widget's children to arbitrary depth from Lua — so a maintainer who has read
  the upstream widget class can build a window adapter (`barterstand.products()/price()/buy()`, or any UI) **in pure
  Lua**, instead of a new Java adapter per window. **Independent** of the U/N-series — the maintainer picks order
  (§6). Decision [D-041](decisions.md); spec [20-widget-introspection.md](20-widget-introspection.md) (+
  `api-reference.md`, `code-map.md`). All in `io.brodgar.addon`, **zero `haven` core edit** (`Widget.children()`/
  `wdgid()`/`c`/`sz`/`visible()`/`getClass`, `Label.texts` all public). Complements — does **not** replace — the
  [14](14-widget-tree-reads.md) typed adapters (which stay for hot/event-driven + private-field reads). **Overall
  DoD:** from `:lua`, walk an open server window (e.g. a Barter Stand) and dump its full nested `type`/`id`/`text`
  tree; server-bound nodes report an `:id()`, client-only ones report `nil`.

  - [x] **W1 — `hafen.ui.root()`/`node(id)` + the `WidgetNode` handle.** ✅ (see STATUS §5; doc `w1-widget-node.md`)
    **`hafen.ui.root()`** (top of the whole client tree) / **`hafen.ui.node(id)`** (by server widget id) +
    **`model:node()`** sugar → an opaque, facade-safe **`WidgetNode`** (new **`io.brodgar.addon.LuaWidgetNode`**,
    D-041): `:type()`/`:id()` ([`Widget.wdgid()`](src/haven/Widget.java:560), `-1`→nil = client-only, the pivot for
    `hafen.act.raw`)/`:children()`/`:parent()`/`:pos()`/`:size()`/`:visible()`/`:text()` (best-effort over
    Label/Button/Window/TextEntry, one localized `nodeText` switch)/`:walk(fn)` (depth-first, `false` prunes)/
    `:same(other)` (reference identity — the per-frame guard W2 needs). A **`GobRef`-style lazy handle** — NOT an
    owned-registry entry (a deep tree mints thousands); `nodeLive` checks liveness per access via
    [`Widget.hasparent(ui.root)`](src/haven/Widget.java:1666) and **nulls the ref once stale** (no pin, no teardown,
    no leak → `:reload` leaks nothing by construction). Facade-safe (P1/D-017): no `haven.Widget` crosses to Lua; the
    handle carries the node as an **opaque userdata** (the `LuaImage`/`LuaMarshal` round-trip) so `:same` resolves the
    other handle. Read-only — to act, pass a server-bound `:id()` to the gated `hafen.act.raw` (D-025), **no new
    gate**. **Zero `haven` core edit** — all backings public (`Widget.children/wdgid/c/sz/visible/parent/hasparent/
    getClass`, `Label.texts`/`Button.text`/`Window.cap`/`TextEntry.text()`, `UI.getwidget`/`root`); only
    `AddonManager.java` (+ imports Label/Button/Text/TextEntry) + the new `LuaWidgetNode.java`. Compile OK + **7
    headless facade-safe round-trip checks** (`LuaWidgetNode.resolve`: handle-table/raw-userdata→node; nil/foreign
    table/foreign userdata/string→null; distinct identity) + LuaJ parse of all addons. **NO example addon**
    (maintainer's request — deviation from §6); verify from the `:lua` REPL. Doc `w1-widget-node.md`. **In-game
    verified ✅** — `hafen.ui.root():walk(...)` dumped the whole client tree incl. an open **Barter Stand**
    (`Window #79`→`Shopbox #80..84`+`Button #85`), server-bound nodes with `:id()`, client-only with `nil`. **The
    run surfaced blank `:type()` for anonymous subclasses** (Hafen builds many widgets as `new TextEntry(...){}` →
    empty `getSimpleName()`); fixed: `nodeType` now climbs to the nearest **named** superclass (that field →
    `TextEntry`, that window → `Window`). *(Java engine change ⇒ rebuild + restart.)* Deferred to W2: hit-testing
    (`hafen.ui.at`/`mouse`/`node:rootpos`/`node:at`) + the `widgetstack` example addon.

  - [x] **W2 — hit-testing: `hafen.ui.at`/`mouse` + `node:rootpos` (the WoW `/framestack` enabler).** ✅ (see STATUS
    §5; doc `w2-hit-testing.md`) Add the two
    reads that find *what widget is under the cursor* (W1 already gives the tree + `:parent()` walk = the stack).
    **`hafen.ui.mouse()`** → `{x,y}` from public [`UI.mc`](src/haven/UI.java:54); **`hafen.ui.at(x,y)`** +
    **`node:at(coord)`** → the **deepest** `WidgetNode` under a point (or `nil`); **`node:rootpos()`** →
    [`Widget.rootpos()`](src/haven/Widget.java:496) `{x,y}` (for a highlight box). `at()` **mirrors the engine's own
    pointer dispatch** [`PointerEvent.propagation`](src/haven/Widget.java:981): walk children `lchild→prev`
    (**topmost-first**), skip `!visible()`, descend by `parent.xlate(child.c,true)`+rect-isect, honour
    [`checkhit`](src/haven/Widget.java:794) at the leaf — so it resolves exactly what a click would hit (correct under
    **scroll** offsets + non-rect hit areas; a naïve rect test is **wrong**). **`onMouseOver` is deliberately NOT
    added** — a hover callback fires only on the addon's *own* widgets, not arbitrary native ones; hover = **poll
    `ui.mc`** each tick. **Read-only, ungated, zero `haven` core edit** (all backings public). Spec:
    `20-widget-introspection.md` §W2; decision [D-042](decisions.md).
    **This slice SHIPS the `widgetstack` example addon** (new `addons/widgetstack/` — the standing harness for W2,
    replacing the `:lua`-only check; a dedicated addon, D-031 spirit, not folded into `hello`). It is the
    `/framestack` clone: on **`OnUpdate(dt)`** ([09](09-events-catalog.md)) it reads `hafen.ui.mouse()` + `hafen.ui.at`,
    walks `:parent()` to the root, shows the stack (type/#id/'text'/WxH per level) in a `hafen.ui.window`, and outlines
    the hovered widget via `:rootpos()`+`:size()`. **Efficiency guard (maintainer requirement):** cache the last
    hovered leaf and **bail early** — `if leaf and last and leaf:same(last) then return end` — so the tree walk +
    window rebuild run **once per hover change, not per frame** (the only per-frame cost is `mouse()`+`at()`+one
    `:same()`). Uses W1's `:same()` (fresh handles + no-`:id()` leaves rule out `==`/`:id()`). Addon-side niceties (not
    new API): a `:widgetstack` slash toggle + an optional `hafen.hook.grab`/hotkey **freeze**.
    **DoD:** with `widgetstack` active, hovering the UI shows the live widget stack + a highlight box; an item in a
    **scrolled** inventory resolves the one a click would hit; a per-rebuild log counter does **not** tick every frame
    while the cursor sits still (the `:same` guard works); `:reload` leaks nothing. *(Java engine change ⇒ rebuild +
    restart.)*

### F — Fonts (`hafen.font.*`, [21-fonts.md](21-fonts.md) / [D-043](decisions.md)) — complete per-addon typography

> **NEW capability.** Per-addon **private font handles** + **owned overrides** on named client surfaces (NO
> shared registry — [D-043](decisions.md)). Resolution: per-instance → scope override → `"default"` override →
> stock. Engine change ⇒ **`ant` rebuild + full restart**. Route render sites **per slice** (`// addon:`
> one-liners), never all ~81 `Foundry` sites at once. Provider carries a **generation counter**; routed sites +
> cached `Text` rebuild when it moves. Specs: `21-fonts.md`, `code-map.md` (Fonts section).

- [x] **F1 — Registry + provider + `"default"` scope (foundation).** ✅ (see STATUS §5; doc `f1-fonts.md`)
  `hafen.font.load(source[, opts])` → an opaque `FontHandle` (built-ins `sans/serif/mono/fraktur` + a sandboxed
  addon-folder `.ttf`/`.otf` via `Font.createFont` + AWT `registerFont` for `$font`; `:derive`/`:family`/`:size`).
  New **`haven.Fonts` provider** (the registry lives HERE, owner-tagged by an opaque `Object`=the `Addon`, so
  `Text`/`Label` gain no `io.brodgar` dep — a small deliberate deviation from the "FontApi owns the registry"
  sketch): owner-tagged override stacks + a **`gen`** counter + a lock-free `active` fast path;
  `foundry(scope, stock)` resolves scope-override → `"default"` cascade → `stock` (last-wins), caching the built
  foundry per stock. Routed the **`"default"` consumers** — [`Text.render`](src/haven/Text.java:359)/`renderf`
  statics + [`Label`](src/haven/Label.java:61) default (its `f` made **non-final** + a `draw()`-time `restyle()` on
  `gen` change) — through `Fonts.foundry("default", std)` (`// addon:`). New `io.brodgar.addon.{FontApi,FontHandle}`
  (facade-safe opaque handle like `LuaImage`; reuses `RenderApi.resolveAddonAsset` + `luaColor`); `setFont`/`reset`/
  `scopes` + an owned `Addon.fontOverrides` list reverted on teardown (`Fonts.removeOwner` bumps `gen`).
  **3 tagged core edits** (`Text.java` ×2 statics, `Label.java`). Compile OK (clean) + **24 headless provider
  checks** (baseline stock identity / scope enum / `gen` bump / family resolution / foundry cache / `"default"`
  cascade / last-wins across two owners / per-scope refine while default cascades / `reset` resurfaces beneath +
  false-for-unset / `removeOwner` clears every scope / empty→fast-path) + LuaJ parse. `hello` **v0.47.0** (loads
  `fonts/demo.ttf` if bundled else built-in `serif`; `:hello font` flips `"default"` + a mono last-wins demo).
  **In-game DoD pending.** Deferred: bundling a real licensed `.ttf` (the code path is ready — drop one at
  `addons/hello/fonts/demo.ttf`), F2–F5 (own-widget/`$font`, chrome scopes, world scopes, per-instance).

- [x] **F2 — Own-widget fonts + draw wrapper + `$font` custom families.** ✅ (see STATUS §5; doc `f2-fonts.md`)
  **`font =` opt** on `hafen.ui.window`/`widget` (default font for the widget's own `g:text`/`g:atext` draws — NOT
  the title bar, that's F3's `window.title`) + a per-call **`g:text(str, x, y [, {font=h, color=…}])`** /
  `g:atext(…, {…})` option (**positional coords KEPT** — the shipped canon + ~30 call sites; opts additive, zero
  breakage — deviates from the spec's `pos`-table sketch, D-012 preserved), and a custom TTF in the existing
  **`$font[h:family(),sz]{…}`** tag (family AWT-registered at `load` → **zero `RichText` edit**). `g:text`/`atext`
  render through a **`RichText.Foundry`** whenever a font handle or `$`-markup is present (so `$font`/`$col`/`$b`/
  `$i`/`$u`/`$size` all work), WHITE glyphs tinted on blit (per-call `color`/bare `g:color` composes unchanged);
  **plain text w/ no font/markup keeps the EXACT stock path** (verified no shipped addon uses `$`/`{`/`}`/`\`),
  malformed markup falls back to literal (never throws). Foundries cached (`FontHandle.rich(px)` per-px + a lazy
  static `stockRich`). **Fully isolated** (own pixels only — no global state, no teardown). **ZERO `haven` core
  edit** (only `io.brodgar.addon`: `FontHandle`/`LuaGOut`/`LuaWidget`). Clean compile + `ant bin` + LuaJ parse of
  all addons; the render path is a **headless resource skip** (`ui/fraktur` absent → `Text`/`RichText` `<clinit>`
  can't run, like A8/A10/R2a) → verified in-game. `hello` **v0.48.0** ("F2 (fonts)" window in its own font + a
  two-font `$font` line). **In-game verified ✅. Committed `0e96ac09`.** *(Rebuild + restart.)* Deferred: native `Label` children of an
  addon widget honouring `font=` (→F3/F5).

- **F3 — UI-chrome scopes.** *(Split into 4 slices — the 7 chrome scopes are heterogeneous render sites
  [blur furnaces, per-widget rasterized `BufferedImage`, `RichText.Foundry` chat, plain foundries], each its
  own investigation + in-game verification, like 1c/1d/2/3/V/R.)* Route + enable each scope through the F1
  provider (`// addon:` one-liners at its render site, rebuilt on `Fonts.gen()`). Each falls back through
  `"default"` when unset (cascade). Specs: `21-fonts.md` §F3, `code-map.md` (Fonts). **DoD (per slice):** the
  scope restyles its surface independently in-game; setting only `"default"` still cascades to it; `:reload`
  reverts. *(Rebuild + restart per slice.)*

  - [x] **F3a — `"window.title"` (window captions).** ✅ (see STATUS §5; doc `f3a-window-title-font.md`) The
    first chrome scope. [`Window.DefaultDeco`](src/haven/Window.java:177)'s caption furnaces `cf`/`ncf`
    (`BlurFurn(TexFurn(Text.Foundry(fraktur,15), ctex), …)`) are no longer `static final` — a new
    **`checktitlefont()`** rebuilds them from **`Fonts.foundry("window.title", titlefnd)`** (new stock
    `Text.Foundry titlefnd`) whenever `Fonts.gen()` moves, and a per-instance **`capgen`** invalidates each
    window's cached `cap` on the same check, so `setFont("window.title", h)` restyles captions **live** and
    `:reload`/`reset` restores stock. Reuses F1's resolution unchanged (a `window.title` override refines ONLY
    captions; `setFont("default", h)` restyles captions TOO via the cascade). **2 tagged core edits, both in
    `Window.java`** (no new class, no `io.brodgar` edit). Compile OK + **8 headless provider-resolution checks**
    (no-override→stock / default-cascade / scope-refine / last-wins / gen-bump / teardown-fallback→stock) + LuaJ
    parse; the caption render is a **headless resource skip** (needs `ctex` + a `Text` toolkit, like A8/A10/R2a/
    F2) → verified in-game. `hello` **v0.49.0** (`:hello title` toggles the scope independently; `:hello font`
    now also restyles captions via cascade). **In-game DoD pending.** *(Rebuild + restart.)*
  - [ ] **F3b — `"button"`.** [`Button.tf`](src/haven/Button.java:51)/`nf` (a `BlurFurn` over `tf`) + per-button
    rasterized `BufferedImage cont` (re-render on `gen`); note [`Charlist.df`](src/haven/Charlist.java:35) also
    derives from `Button.tf`. **DoD:** button captions restyle live; cascade from `"default"`; `:reload` reverts.
  - [ ] **F3c — `"textentry"` + `"label"`.** Plain `Text.Foundry` sites: [`TextEntry.fnd`](src/haven/TextEntry.java:35)
    + `ReadLine`, and explicit-foundry `Label`s (the non-`std` path F1 left fixed). **DoD:** each restyles live;
    cascade; `:reload` reverts.
  - [ ] **F3d — `"menu"` + `"tooltip"` + `"chat"`.** [`FlowerMenu.ptf`](src/haven/FlowerMenu.java:36)/`MenuGrid`;
    the tooltip foundry (String tooltips already ride `Text.render`=`"default"` — find the dedicated site);
    [`ChatUI.fnd`](src/haven/ChatUI.java:43) is a **`RichText.Foundry`** (a different foundry type → needs its own
    provider path/primitive). **DoD:** each restyles live; cascade; `:reload` reverts. **Completes F3.**

- [ ] **F4 — World scopes.** **Locate** the render sites for floating names (`"world.nick"`) and speech bubbles
  (`"world.speech"`) — not yet mapped in `code-map.md` — then route them. If the world text is too distinct to
  fold into `hello`, propose a dedicated example addon (D-031 spirit). **DoD:** floating names / speech restyle
  live; revert on `:reload`. *(Rebuild + restart.)*

- [ ] **F5 — Per-instance override (stretch, priciest).** `node:setFont(h)` on a
  [`WidgetNode`](20-widget-introspection.md) (and/or `hafen.font.setFont(widgetRef, h)`), sitting at the **top of
  the resolution chain** — restyles one arbitrary native widget while siblings keep the scope/default font.
  Deferred until F1–F4 land (targets one native widget's `Text` cache — the expensive part). **DoD:** one specific
  window restyles while its siblings do not; `:reload` reverts. *(Rebuild + restart.)* **⚠ Confirm with the
  maintainer whether F5 ships in the first pass or waits ([21-fonts.md](21-fonts.md) "Open points").**

> When a task turns out too big for one prompt, split it and update this queue (leave the rest
> unchecked). Prefer small, verifiable increments.

---

## 8. Learnings & gotchas (append as we go)

- The in-game console **strips quotes** (`Utils.splitwords`) → use **`Console.rawcmd()`** for raw
  input (done for `:lua`).
- `UI.msg(String)` shows in-game notices; at **session init (pre-HUD)** logs may only reach stdout —
  `AddonManager.log` writes to both.
- **`Window.reqdestroy()` is async** (hide animation) → for synchronous teardown call
  `destroy()`/`remove()` directly.
- **`UI.drawafter` is one-shot** (cleared each frame) → the engine keeps its own persistent overlay
  list and paints from the addon-root widget.
- **Positioning:** NO global coordinate; `gob.rc`/`hafen.gob.pos` is **login-relative**. The shared
  anchor is **grid id + within-grid offset** (`hafen.map.grid`/`hafen.map.gridPos`); segment ids are
  local. See `hafen-positioning` memory + `coverage-gaps.md` C4.
- Widget creation runs `type.create(...)` **off the UI lock** (Loader thread) before `attach`/`bind`;
  do tree work in `added()`/`attached()` (under the lock). Factory-override seam covers builtin type
  names only (not resource-widget `/`-names).
- Threading: read `OCache` under `synchronized(oc)` (copy first), per-`Gob` under `synchronized(g)`,
  swallow `Loading`. Network-thread callbacks must be marshalled to the UI thread before hitting Lua.
- **Invisible widgets are still ticked.** `TickEvent.shandle` calls `w.tick()` regardless of
  `visible`; only `draw` skips invisible children. So a `visible=false`, zero-size child of
  `ui.root` is a perfect zero-core-edit per-frame hook (the `AddonRoot` tick pump). `ui.root` exists
  before `RemoteUI.init` runs (set in the `UI` ctor just before `fun.init(this)`), so attaching in
  `AddonManager.init` is safe.
- **`OCache.callback` holds callbacks in a `WeakList`** → you MUST keep a strong ref to the
  `ChangeCallback` (static field `ocCb`) or it gets GC'd and stops firing. `added/removed` fire on
  the network/loader thread → enqueue to a `ConcurrentLinkedQueue` and drain on the UI-thread tick.
- **`MapView.attach` runs on a loader thread** (widget creation is off the UI lock). So it only sets
  a `volatile enterWorldPending` flag; `OnEnterWorld` is actually fired on the next tick (UI thread).
- **LuaJ:** `ZeroArgFunction` accepts extra args, so `handle:off()` (method-call passes `self`) works
  with a `ZeroArgFunction` body. `error('x')` surfaces as a `LuaError` whose `getMessage()` includes
  `chunkname:line` (e.g. `@hello/main.lua:12: x`) — good for the isolation log. Chunk names: addons
  load with `@id/file` (a real path prefix), the REPL with `=lua` (verbatim).
- **The `:lua` REPL is a resource owner** (synthetic `Manifest.internal("(console)")`), so
  events/timers are testable from the console. Its subscriptions **persist across relogs** (the REPL
  `Globals` is long-lived and is NOT torn down on `init`, unlike real addons).
- **Headless testing works** for the pure engine (event/timer logic): install the facade on a throw-
  away `Addon`, drive `AddonManager.tick(dt)` directly. Only `AddonRoot`/`OCache`/`MapView` wiring
  needs the live game. (See the throwaway `TickTest` pattern — same-package + reflection for privates.)
- **Windows/Git-Bash gotcha:** a `;`-separated `-cp` gets mangled by MSYS path conversion → prefix
  `java`/`javac` with `MSYS_NO_PATHCONV=1 MSYS2_ARG_CONV_EXCL='*'`. Also `/tmp` breaks under
  `MSYS_NO_PATHCONV=1` — write throwaway `.java` to the **scratchpad** dir, not `/tmp`.
- **Gob reads (1c-1):** `Gob.rc` (Coord2d, login-relative), `Gob.a` (facing rad), `Gob.getattr(cls)`;
  attrs — `Moving.getv()` (speed; presence ⇒ moving), `GobHealth.hp` (float 0..1), `Speaking.text.text`
  (String via `Text.text`), `Drawable.getres().name` (type identity; **player = `gfx/borka/body`**),
  `GobIcon.icon().name()`. `getres()`/`icon()`/overlay names can throw **`Loading`** (a
  `RuntimeException`) or be null before resolve → **each reader try/catches and returns nil/skips**.
  Overlay names: `Gob.ols` → `Overlay.spr.res.name` (skip unresolved), read under `synchronized(gob)`.
- **`OCache` enumeration:** it `implements Iterable<Gob>`; copy the list under `synchronized(oc)` then
  build snapshots/apply the Lua filter **outside** the lock (filters call back into Lua). `getgob(id)`
  is already `synchronized`. Building a full snapshot per gob per scan is not free (icon() resolves a
  resource, cached after first hit) → keep recommending `GobAdded`/`GobRemoved` over per-frame scans.
- **GobRef resolution is centralized** in `resolve(LuaValue)` (the one place to add `"target"`/
  `"partyN"`/`"mouseover"` later). Unknown string token → `Long.parseLong` throws → caught → nil, so
  `hafen.gob.name("target")` is a graceful nil today, not an error.
- **Splitting a task is fine and expected** (PLAN §7 says so): 1c was 9 sub-APIs across
  OCache/MCache/GameUI/CharWnd/Glob/camera/Audio — too big for one prompt + one in-game verification.
  Split into 1c-1 (gob+world, done), 1c-2 (map/player/time/sound, done), 1c-3 (items/char/party).
- **Map coords (1c-2):** `tilesz = 11` (`Coord2d`), `cmaps = 100` tiles/grid (`Coord`) → a grid is
  **1100 world units** square. world→tile = `Coord2d.floor(tilesz)`; tile→grid = `Coord.div(cmaps)`.
  **Both floor-divide** (`Coord2d.floor` uses `Math.floor`; `Coord.div` uses `Utils.floordiv`) so
  **negative login-relative coords convert correctly** — do NOT hand-roll `(int)(x/11)` (truncates
  toward zero, wrong for negatives). `MCache.gettile(Coord)`→tileset id, `tilesetr(id).name`; `getcz(px,py)`
  = interpolated height. All three throw `Loading` before the grid is here → guard → nil.
- **`Grid.id` is `buf.int64()`** (full 64-bit) and is THE persistent/cross-player anchor → expose it
  as a **decimal String** (`Long.toString`), never a Lua number: LuaJ numbers are doubles and lose
  precision > 2⁵³. `Grid.gc`/`ul` are `Coord` (tile coords; `ul = gc*cmaps`). `gridPos` offset =
  `wc − ul*tilesz` (world units, 0..1100). Gob ids stay doubles (transient, session-local — 1c-1).
  `grid().seg` (segment id) is NOT on `MCache.Grid` — it's a `MapFile` concept (deferred to A1).
- **world→screen exists:** `MapView.screenxf(Coord2d)` projects to **map-view-relative** pixels via
  the live camera and **catches `Loading` → null** internally (uses `getcc()`); it reads the
  last-composited `basic.state()`, and the client already calls it off-draw (GameUI.updhand), so it's
  safe from Lua on the UI thread. Backs `hafen.player.worldToScreen` (still wrap in try/catch for NPEs).
- **Reaching `GameUI` from the addon layer:** `view.getparent(GameUI.class)` (MapView is a direct
  child of GameUI, added at `GameUI.addchild` :914). `GameUI.chrid`/`genus` are `public final String`;
  `chrid` **is** the local character name (in-game it read `"Irongete W16.1"`; backs `hafen.player.name`).
  `gui()` uses a **fast path (`getparent`) + fallback (DFS from `ui.root`)** — widget tree walk
  `for(Widget c = w.child; c != null; c = c.next)` (`child`/`next`/`parent` public). This robust reach
  backs all of 1c-3 (items/char/party). **NB:** at the *very first* enter-world tick neither reach
  finds GameUI — see below.
- **Two different "not ready yet" races at `OnEnterWorld`** (both surfaced in the 1c-2 in-game test,
  both correctly returned nil, not errors): (1) **HUD not assembled** — `OnEnterWorld` was firing from
  `MapView`'s ctor (loader thread → next tick) *before* GameUI exists in the tree, so **even the
  `ui.root` scan found nothing** and `player.name` was nil. Real fix: **gate the event** —
  `if(enterWorldPending && gui() != null) fire("OnEnterWorld")`. Now it fires once the HUD is up
  (≈ WoW `PLAYER_ENTERING_WORLD`), so every GameUI-backed read works inside the handler. Safe because
  `enterWorldPending` is reset each session in `init()`, and MapView (hence its GameUI ancestor) always
  materialises, so it can't stick. (2) **data-streaming** — the MCache grid, terrain z, and camera for
  the spot download a beat AFTER enter-world, so `map.tile`/`height`/`gridPos`/`worldToScreen` are nil
  for the first frames, then resolve. Nothing to "fix" (the data isn't here) — the `hello` harness
  reads map data **twice** (`readPlace("now")` + `timer.after(3, readPlace("+3s"))`) to demonstrate
  them. `hafen.gob.*`/`world.*`/`time.*` (incl. astronomy) ARE ready immediately at enter-world.
- **`hafen.gob.health("player")` is nil** — the player body has no `GobHealth` attr; GobHealth is
  *object* integrity (structures, damageable gobs), not the player's hp/stam/energy bars (those are
  the private `GameUI` meters, Phase 1d). Expected, not a bug.
- **`Glob.ast` (`Astronomy`) is nil until the first "astro" update**; the object is immutable (all
  final: `dt`/`mp`/`yt`/`night`/`is`…) so a plain ref read is safe. `glob.globtime()` (the clock) is
  available without `ast`. Centralized `glob()`/`mcache()`/`astro()` helpers hang off the live `view`.
- **Items/char/party (1c-3):** read them **without touching package-private state**. Inventory/
  equipment items: **walk the `WItem` children** — `inv.children(WItem.class)` (public recursive DFS)
  — instead of `Inventory.wmap`/`Equipory.wmap` (both package-private). `WItem.item` (public `GItem`),
  `WItem.c` (public `Coord`, inherited from `Widget`). Inventory grid cell = `witem.c.sub(1,1).div(
  Inventory.sqsz)` (reverses `c.mul(sqsz).add(1,1)`). Equipment slot index = `Equipory.epat(witem.c)`
  (public); slot name = `Equipory.etts[ep].text` (public `Text[]`, entries may be null); a **two-slot
  item shows up as two `WItem` children** (two entries, distinct `slot`). Item fields: `GItem.res`
  (`Indir<Resource>`, `.get().name` — Loading), `GItem.num` (`-1`→nil), `GItem.meter` (**0..100** %, the
  client treats `>0` as "has meter"), name via `ItemInfo.find(ItemInfo.Name.class, item.info()).str.text`
  (`item.info()` throws Loading). Cursor item = `GameUI.vhand.item` (public `WItem`).
- **A THIRD "not ready yet" race at `OnEnterWorld` (data-streaming, 1c-3):** char cattrs, `lp`/`weight`,
  and the inventory/equipment widgets **arrive a beat AFTER enter-world** — in the in-game test they
  were all nil/empty at the immediate `OnEnterWorld` read and populated ~seconds later (`str`→124/178,
  `lp`→403475, `weight`→12429, inventory 0→12, equipment 0→19). Same shape as the 1c-2 map-data stream.
  Not a bug (data isn't here yet; all Loading-guarded → nil, never errors). Addons must read char/items
  on a later tick/timer or off a change event, **not** synchronously inside the `OnEnterWorld` handler.
  The `hello` harness reads char/items twice (`readInv`/`readChar` at `now` + a `+3s` timer) to show it.
  (The `*Changed` semantic events that make this ergonomic come with the widget-tree mechanism, 1d.)
- **Char attrs / lp / weight are all public reads** — no widget-tree needed for these. `Glob.getcattr(nm)`
  (public, synchronized) **never returns null** (auto-creates `{base=0,comp=0}` for unknown names) → treat
  `base==0 && comp==0` as nil. The 9 base attrs are content-defined & hard-coded: `str,agi,int,con,prc,
  csm,dex,wil,psy` (from `BAttrWnd`). `hafen.char.lp/weight` = `GameUI.chrwdg.exp`/`enc` (**public int**):
  `chrwdg` (`CharWnd`) is created **hidden at login** (`GameUI.addchild` place `"chr"` → `.hide()`) and its
  `exp`/`enc` update via `uimsg` regardless of visibility — so they read live **without opening the sheet**.
  (FEP/food/curiosity/skills still need the widget-tree mechanism — 1d.)
- **Party (1c-3):** `Glob.party` (public), `party.memb` (`Map<Long,Member>`, public), `party.leader`
  (public). `party.memb` is **replaced wholesale off-thread** (`Partyview.uimsg` builds a new HashMap and
  assigns `party.memb = nmemb`), so copying `memb.values()` on the UI thread is snapshot-safe (no in-place
  mutation → no CME; keep a defensive catch anyway). `Member`: `gobid`/`seq`/`col` public, `getc()` (live
  gob pos else last-known, may be null)/`geta()` public; **no name field** (client/protocol limitation).
  Order the roster by `Member.seq` for the `"partyN"` ordinal. Colors → `{r,g,b,a}` 0..255.
- **`"partyN"` token added to the central `resolve()`** (the designed extension point): `s.startsWith(
  "party")` → `Integer.parseInt(s.substring(5))` → Nth member by seq → `getgob(member.gobid)`. Empty/
  non-numeric suffix → `NumberFormatException` → caught → nil (so `hafen.gob.name("party")` is a graceful
  nil). Out-of-view member → gob not in OCache → nil (use `hafen.party.member(id)` for last-known pos).
- **Item reads return snapshots, deliberately NO `hafen.items.name/count/wear` accessor fns.** Items have
  **no stable addon-visible id** to re-resolve by (unlike gobs), so the snapshot IS the canonical read
  (carries name/num/wear). Per-item live accessors wait for **item handles** (bridge-owned proxies over the
  live `GItem`, UI/replacement phase) — keeps D-013 "one canonical way".
- **Play a sound without blocking the UI thread:** mirror `GobIcon.resnotif` — `Indir<Resource> r =
  Resource.local().load(name)` then `glob.loader.defer(() -> { res = r.get(); ui.sfx(Audio.fromres(res)); }, null)`,
  **rethrowing `Loading`** (the loader re-runs the task) and catching other `RuntimeException` (report + swallow).
  `Resource.Named implements Indir<Resource>` so `Pool.load(String)` feeds `Music.play(Indir,loop)`
  directly (music resolves on its own player thread — no defer needed; `Music.play(null,false)` stops).
  Bundled sfx that always resolve locally: `"sfx/msg"`, `"sfx/error"`, `"sfx/hud/btn"`.
- **Widget-tree reads (1d) are the first NON-zero-edit surface** (B5 predicted this). Two core edits,
  both minimal + `// addon:`: (1) the **inbound-`uimsg` tap** and (2) a **`haven`-package accessor**.
- **`UI.uimsg(id,msg,args)` does NOT apply the message** — it `submitcmd`s a `UiMessage` Command that
  runs later on a **Loader thread** under `synchronized(ui)` and calls `dispatch(wdg, MessageEvent)`.
  So for a **post-apply** semantic tap, hook inside `UiMessage.run()` **after** the `dispatch(...)`
  block (widget state is fresh there), NOT at `UI.uimsg` (that's pre-apply — the future `hook.message`
  pre-hook seam). The tap runs off the UI thread → **only enqueue** (mark adapter dirty), never call
  Lua; the tick drains + fires on the UI thread (same pattern as the OCache gob queue).
- **Reaching widget-tree values without reflection in Lua:** put a tiny **package-`haven` accessor**
  class (`AddonWidgets`, the `SpeakerIcon` trick) next to the widgets. `protected`/package fields ARE
  accessible from package `haven` (e.g. `LayerMeter.meters` is `protected` → readable there), so no
  `setAccessible` reflection is needed for same-package fields — expose them as `public static` getters.
  This localizes the fragile read to ONE file (adapters call it), and Lua never touches reflection (D-017).
- **Vitals = `IMeter` bar fractions only** (0..1), NO absolute numbers, NO hunger (they don't exist as
  client state — B5). Locate via `gui().children(IMeter.class)` (public recursive DFS, like Equipory);
  value = first `LayerMeter.Meter.a` (via `AddonWidgets.meters`). `IMeter extends LayerMeter`; `IMeter.bg`
  (public `Indir<Resource>`) is the per-bar identity but the **bg names are server-published** (not in
  the client source), so map the three bars **positionally** in creation order (hp, stamina, energy) —
  `children(Class)` iterates tree/creation order. Update signal: `LayerMeter.uimsg("set")` (synchronous).
- **`IMeter` initial values:** the `im` factory decodes `decmeters(args,1)` from creation args, BUT
  in-game the three bars actually **streamed in as individual `set` uimsgs** a beat after their meters
  were created (observed: `VitalsChanged` fired once per bar, hp→stamina→energy, because a key
  appearing counts as a change) — so on this server the event DID cover initial population. Still, the
  robust pattern for any widget-tree tracker is: read the value once on a post-enter-world timer for
  the initial snapshot, then let the inbound-`uimsg` event stream updates. (Meters/CharWnd/inventory
  all **stream in a beat after enter-world** — the same race as 1c-2/1c-3 data; read on a timer, not
  synchronously in the handler.)
- **`TreeAdapter` mechanism shape:** `interested(Widget,msg)` (off-thread, cheap `instanceof`, marks
  dirty) + `refresh()` (UI thread, re-read snapshot + fire the semantic event). Engine holds a
  session-scoped `List<TreeAdapter>` + a `ConcurrentHashMap.newKeySet()` dirty set (both reset in
  `init()`), drained each tick. Change-detection (`vitalsEqual`): a null/nil cache ⇒ "changed" (first
  populated read fires), a key appearing/disappearing ⇒ changed, else compare the numeric fields — so
  colour/tooltip-only uimsgs are suppressed. Adding an adapter = one class + one `treeAdapters.add`.
- **Splitting 1d (like 1c):** 7 adapters + a core mechanism is too big for one prompt/verification →
  1d-1 (foundation + vitals, done), 1d-2 (buffs + FEP, done), 1d-3 (study + skills), 1d-4 (action bar + equip event).
  Buffs are the odd one: add/remove is **widget create/`cdestroy`** on `Bufflist`, not a `uimsg` (only
  the per-`Buff` `"ch"/"tt"` content change is a uimsg) → detect add/remove by diffing `children(Buff.class)`
  on tick or via a widget-create hook, not the uimsg tap alone. FEP is `BAttrWnd.uimsg("food"/"glut")`
  (clean uimsg→event) but `BAttrWnd` is **not** a `GameUI` field (locate by tree-walk / `@RName("battr")`).
- **The `TreeAdapter` now has TWO update paths (1d-2):** the 1d-1 uimsg path (`interested`→dirty→
  `refresh`) for server-pushed uimsgs, PLUS a per-tick **`poll()`** (a `default {}` no-op on the
  interface, so old adapters are untouched) for structural changes no uimsg announces. `tick()` calls
  `refreshTreeAdapters()` then `pollTreeAdapters()` — **refresh before poll** so a brand-new buff (in
  the tree + its `"tt"` already applied) emits a single `BuffAdded` in poll, not `BuffChanged`(from an
  empty cache)-then-`BuffAdded`. An adapter uses whichever path fits: `VitalsAdapter`/`FepAdapter` =
  uimsg-only; `BuffsAdapter` = poll for add/remove + uimsg for content. Adapter caches now live **in
  the adapter instance** (reset by re-instantiation in `init()`), not a static — cleaner than the 1d-1
  static `vitalsCache`.
- **Buffs (1d-2) — mostly zero-edit, all public:** `GameUI.buffs` (public `Bufflist`) →
  `children(Buff.class)` (public recursive DFS, **creation order**). `Buff.res` (public `Indir<Resource>`,
  `.get().name` — Loading), name from `res.get().layer(Resource.tooltip).t` (nullable `layer`, not
  `flayer`) with an `ItemInfo.find(ItemInfo.Name.class, Buff.info())` fallback. `amount`/`cooldown`/
  `number` = `ItemInfo.find` over `Buff.info()` for `Buff.AMeterInfo` (`.ameter()` 0..1) / `GItem.MeterInfo`
  (`.meter()` 0..1) / `GItem.NumberInfo` (`.itemnum()` int) — all public interfaces; often nil; **NOT
  time-varying** (info-cached, rebuilt only on `"tt"`), so per-tick snapshotting doesn't spam `BuffChanged`.
  `Buff.info()` throws Loading and is `emptyList()` until the first `"tt"`. **`Buff.dest` (protected)** is
  the only non-public bit → `AddonWidgets.buffDest` (a `dest` buff is fading out post-removal → exclude it).
- **FEP/food (1d-2) — 100% public, zero haven-edit:** locate `BAttrWnd` via the **public `CharWnd.battr`
  field** (set in `CharWnd.addchild` when the `@RName("battr")` child lands — NO tree-walk / `children`
  needed, though `gui().children(BAttrWnd.class)` also works). `BAttrWnd.feps` (`FoodMeter`) + `glut`
  (`GlutMeter`) are public finals; `FoodMeter.cap`/`els` (List<El>), `El.res`/`a`/`ev()`, `Event.nm`/`col`/`sort`,
  `GlutMeter.glut`/`lglut`/`gmod`/`lbl` are ALL public. `feps.update`/`glut.update` run on a Loader thread
  (uimsg) but only build a new list / set scalars; `els` is swapped in `FoodMeter.tick` on the UI thread —
  copy `els` (`new ArrayList<>(fm.els)`) before iterating for defensiveness. `hunger.level` = `glut` (the
  integer part is the hunger *level*, the fraction is progress within it); `label` = `lbl`; `efficacy` = `gmod`.
- **`msg` interning — don't rely on it:** the client compares uimsg names with `==` (interned), but from
  the addon layer compare with `.equals()` (`"food".equals(msg)`, `"ch".equals(msg)`) to be safe.
- **The 1d-1 inbound-uimsg tap now feeds THREE adapters** with zero further `UI.java` change — the single
  seam scales (B5's prediction holds). `AddonWidgets` is the one growing accessor file (`meters` +
  `buffDest`); each new protected/private widget field = one method there, never reflection in Lua (D-017).
- **1d-3 is the first ZERO-`haven`-edit widget-tree slice** — study + skills are 100% public reads, so
  neither the `UI.java` tap nor `AddonWidgets` grew (they weren't even needed): `CharWnd.sattr`
  (`SAttrWnd`) / `CharWnd.skill` (`SkillWnd`) are **public fields** set in `CharWnd.addchild` (like
  `battr` in 1d-2), null until the tab streams in a beat after enter-world. `SAttrWnd`/`SkillWnd` are
  built via a **`CharWnd.TabProxy`** (`@RName("sattr"/"skill"/"credo"/"expls")` create a proxy that
  lazily constructs the real tab and hands it to `CharWnd.addchild`) — so **locate via the public
  `CharWnd` field, never the `@RName`** (the RName widget is the proxy, not the window).
- **Study (1d-3):** the study window is `SAttrWnd` (a `CharWnd` tab, `chr.sattr`). The study inventory
  is not a named field — reach it via **`sattr.children(SAttrWnd.StudyInfo.class)` → `StudyInfo.study`**
  (public `Widget`); `StudyInfo` is created 1:1 with the study inventory in `SAttrWnd.addchild(child,
  "study")` and also carries the **live totals `texp`/`tw`/`tenc`** (public, recomputed every tick in
  `StudyInfo.tick`→`upd` = total LP / attention(mental weight) / exp-cost) → backs `study.summary()`
  for free. The study inventory holds **`GItem` children DIRECTLY** (NOT `WItem`-wrapped like the main
  inventory) — mirror `StudyInfo.upd`: `study.children(GItem.class)`.
- **`resutil.Curiosity`** is the study-profile `ItemInfo` on each curiosity item (`ItemInfo.find(
  Curiosity.class, gitem.info())`, Loading-guarded): public `exp` (learning points), `mw` (mental
  weight = **attention**), `enc` (experience cost), `time` (**TOTAL** study time, seconds). **There is
  NO per-item "time left" in the client** (only the total) — don't fabricate one (same honesty rule as
  the non-existent seconds buff timers). `GItem.meter` (0..100) is exposed as best-effort `progress`.
- **`StudyChanged` is poll-driven, like buffs** — a curiosity being placed/finished is a widget
  create/`cdestroy` on the study inventory (NOT a uimsg) and its `Curiosity` info resolves a beat after
  the item appears, so `StudyAdapter` overrides only `poll()` (diff `slots()` each tick via
  `studySlotsEqual`, a positional array compare reusing `luaFieldEq`); `interested()` returns false and
  `refresh()` is a no-op. A null cache ⇒ "changed", so the first populated (or first empty) read fires
  once. Order is significant in the diff (study items don't reorder in practice).
- **Skills (1d-3):** `chr.skill` (`SkillWnd`) → `skg` (`SkillGrid extends GridList<Skill>`) → `csk`
  (**known**) / `nsk` (**available**) are `GridList.Group`; `Group.items` is a **public `List<Skill>`
  swapped wholesale off-thread** by the `csk`/`nsk` uimsgs (like `Party.memb`) → **copy before
  iterating** (`new ArrayList<>(...)`), snapshot-safe. `Skill.nm` = the internal token (used for
  `wdgmsg("buy", nm)`), `Skill.res` = `Indir<Resource>` → display name from the resource tooltip
  (fallback to `nm`). `char.skills()` returns known only; `skill(name)` is a substring test (name|res)
  like `buffs.has`. No `SkillsChanged` (skills change only on buy — read on demand). Credos (`SkillWnd.
  credos`: `ccr`/`ncr`/`pcr` + pursuit `pcl/pclt`,`pcql/pcqlt`) and experiences (`exps.seen.items`) are
  public too but deferred.
- **Study in-game finding (1d-3):** a study slot can hold an item with **no `Curiosity` info** — e.g.
  "A Bond of Blood & Soil" (a Hearth-Magic bond). `ItemInfo.find(Curiosity.class, …)` returns null for
  those, so their snapshot is `{res,name}` only and they add 0 to `summary()` (which matched exactly the
  one real curiosity: `lp=25567 att=8 cost=1`). Confirms the Loading/optional-field design is right —
  never fabricate. `GItem.meter` was 0 for all study items (so `progress` was absent) — best-effort, as
  expected. `StudyChanged` streamed `0→1→3` as the widgets + Curiosity infos resolved after enter-world.
- **The action bar is the engine's "belt" — API renamed to `hafen.actionbar` (D-013 one canonical
  name):** H&H calls its hotbar the "belt" (`GameUI.belt`, `BeltSlot`, `setbelt`/`setbelt2`,
  `FKeyBelt`/`NKeyBelt`, `:belt`, pref `belttype`; the bar bg texture is even `gfx/hud/hb-main` =
  "hotbar main"). That collides with the worn-belt *equipment*, so after the maintainer flagged it the
  addon-facing API was renamed **`belt` → `actionbar`** everywhere (namespace `hafen.actionbar`, event
  `ActionbarChanged`, helpers `actionbar*`, adapter `ActionbarAdapter`, doc `phase-1d4-actionbar-equip`).
  **Engine names stay `belt`** (`GameUI.belt`/`setbelt`/`BeltSlot`…) — we don't touch `haven`; the
  adapter/helpers are `actionbar*` but read `belt[]`, bridged by a one-line comment. Rule for future
  gap subsystems: **expose the game's *concept* under a clear name, keep the engine's own identifiers in
  the Java that reads them.**
- **Action bar (1d-4) — poll, NOT the uimsg tap, because the write is deferred:** setting/clearing/
  dragging a slot is a `GameUI` `setbelt`/`setbelt2` uimsg, BUT for the resource/pagina cases the client
  does `belt[slot] = …` inside a **`ui.sess.glob.loader.defer(...)`** task that runs *after* the uimsg
  dispatch (`GameUI.uimsg` :1367/:1381). So the 1d-1 inbound-uimsg tap fires while `belt[slot]` is still
  the OLD value → a refresh-on-uimsg reads stale. Fix: `ActionbarAdapter` is **poll-driven** (diff the
  144 slots each tick), like buffs/study; `interested()` returns false. (Clears and `setbelt2 "p"`/`"d"`
  are synchronous, but the common cases aren't — so never trust the uimsg alone here.) The generalisable
  rule: **if a widget mutation is `loader.defer`-red, use poll(), not the uimsg tap.**
- **Action-bar reads are all public (zero `haven` edit):** `GameUI.belt` (`public BeltSlot[144]`,
  field-init so never null — elements are null). Two concrete slots: `ResBeltSlot` (`public getres()` →
  `rdt.res.get()`; a raw item/resource, no meter) and `PagBeltSlot` (`public pag`; a menu action). For a
  PagBeltSlot: `pag.res()` (icon), `pag.button().name()` (= `act().name`, the display name), and
  `pag.button().meter.get()` (the `cooldown`, an `AttrCache<Double>` from `GItem.MeterInfo`, 0..1). All
  can throw `Loading` via `res.get()`/`flayer` → try/catch each (though **`AttrCache.get` itself catches
  `Loading` and returns null**, `ItemInfo.java:438`). `ResBeltSlot` is a non-static inner class but
  `instanceof`/cast/`getres()` work fine cross-package (all public).
- **`cooldown` is a live meter → EXCLUDE it from `ActionbarChanged` change-detection** (`actionbarEqual`
  compares `res`+`name` only), else a cooling-down ability fires an event every frame. Same reasoning
  drops `wear` from `equipEqual` (`slot`/`res`/`name`/`num` only) — durability drift isn't an equip
  change. The field is still readable live via `hafen.actionbar.slot(n).cooldown` /
  `hafen.items.equipment()`.
- **Action-bar indexing = raw 0-based game index (0..143), NOT 1-based Lua.** The client packs pages as
  `page*12 + i` (12 slots × 12 pages; in-game slot 0 = F1/page 0, slots 120/121 = page 10) and
  `actionbar.use` (Phase 4) will send `wdgmsg("belt", n, …)` with that same n — so read and use share one
  index (D-013 "one canonical way"). The `"partyN"` token is 1-based but that's a naming *ordinal*, not
  an array index into a live game structure — different thing, don't conflate.
- **`EquipChanged` is poll-driven too** — equip/unequip is a `WItem` create/`cdestroy` under `Equipory`
  (not a uimsg). `EquipAdapter` re-reads the equipment snapshot each tick and fires with the **whole
  array** (positional diff, `wear` excluded). Refactored the 1c-3 `equipment` facade body into a shared
  `readEquipment(Equipory)` so the facade and the adapter can't drift. Positional compare is safe: the
  `Equipory` child order is creation-order and stable between equips (same assumption as study).
- **Poll-based streaming fires per-slot at login (expected, not a bug):** action bar / equipment stream
  in a beat after enter-world (like all HUD state), so each slot/item surfacing fires one
  `ActionbarChanged`/`EquipChanged` — consistent with buffs/study/vitals streaming. `hello` reads at now
  (empty) + `+3s` (populated) and throttles the event logs. **Phase 1d is now complete** (all
  widget-tree read surfaces: vitals, buffs, FEP/food, study, skills, action bar, equipment).
- **Saved variables (1e) — the per-char folder is unknown when addons load.** Addons load at
  `RemoteUI.init` (session bind), **before** the HUD exists, so `<genus>_<char>` (= `GameUI.genus`/`chrid`)
  can't be known yet. Resolution: **account-scope** vars (no char needed) load at addon-load (before
  `OnLoad`); **per-char** vars load at the **first `OnEnterWorld`** (gate: `gui() != null`, same as the
  retimed event) — so the per-char store is ready *inside* the OnEnterWorld handler (no post-enter
  streaming delay, unlike the read API). Rule for addon authors: **read/init per-char `hafen.store` from
  `OnEnterWorld` onward, never in `OnLoad`.**
- **Flush must use a CAPTURED scope, not a live `gui()` lookup.** A relog calls `AddonManager.init(newUi)`
  which sets `ui=newUi` then tears down the OLD addons — at that moment the new `GameUI` doesn't exist and
  a live `gui()` returns null, so the old character's data would have nowhere to go. Fix: **capture
  `charScope = "<genus>_<char>"` at OnEnterWorld** (static volatile) and flush against it; reset it to
  null in `init()` **after** the old-session teardown flush. Teardown order is **`OnDisable` → flush**
  (fire the event first so the addon's last-chance writes are captured, then persist) — the spec's
  "flush then OnDisable" numbering is just a list; capturing OnDisable writes is strictly better.
- **Reuse the REPL `json()` writer + the `Json` reader for persistence — they're already correct.** The
  1e serializer is literally the compact `json(LuaValue)` used by `:lua` (array/object auto-detect, cycle
  guard); the reader is the manifest `Json.parse`. Only new glue: `jsonToLua`/`fillTable` (JSON→Lua:
  object→string-keyed table, array→1-based; **fill in place** so a cached `hafen.store.x` ref stays valid).
  **Numbers are doubles** (integers >2⁵³ lose precision — same reason grid ids are strings). An **empty**
  Lua table serializes as `[]` (can't distinguish empty array from empty object) but round-trips as an
  empty table — cosmetic only. **A saved var can be an array** (`hafen.store.data = {1,2,3}`), so `fillTable`
  must handle both List and Map, not just Map (round-trips arrays intact).
- **Write-skip + throttled auto-save keep persistence cheap and crash-safe.** Per-scope, cache the last
  serialized JSON on the `Addon`; a flush that produces the same string **skips the disk write**. A **30 s
  throttled auto-save** in `tick()` (UI thread → no races reading the Lua tables) covers an unclean exit
  without a racy JVM shutdown hook; a relog still flushes cleanly via teardown. Writes are **atomic** (write
  `<file>.tmp`, then `Files.move` with `ATOMIC_MOVE`, fall back to `REPLACE_EXISTING`) and **non-fatal**
  (a read-only install is logged, never thrown — a broken save can't break the addon or the frame).
- **`savedata/` resolution mirrors `addonDir()`** — it's the **sibling of the resolved addon dir**
  (`saveDir()` = `addonDir().getParentFile()/savedata`), so it tracks dev vs release automatically
  (`bin/savedata` in a release; `${basedir}/savedata` under the dev override) without a second rule.
  `-Dhaven.savedatadir` overrides. Added `/savedata` to `.gitignore` (the dev-override path at repo root;
  `bin/` was already ignored). Sanitize genus/char to one safe path segment (`[A-Za-z0-9._-]`, else `_`).
- **Headless persistence testing is strong and cheap** (extends the throwaway-in-scratchpad pattern): a
  same-package `StoreTest` builds a real `Addon` (package-private ctor) with a hand-built `store` table,
  sets `charScope` + `haven.savedatadir` via reflection, then drives `flush`/`loadScope` to simulate
  write → **relog** (fresh Addon + empty store) → read → increment → relog, asserting the counter survives.
  19/19 including array round-trip + write-skip (mtime unchanged) — proves the DoD before the in-game run.
- **The pre-1f addon envs were NOT sandboxed at all (1f-1).** `JsePlatform.standardGlobals()` bundles
  `JseIoLib` (`io`) AND **`LuajavaLib`** (`luajava.newInstance`/`bindClass` — arbitrary Java reflection),
  so any addon could reach straight into `haven.*`, bypassing the whole facade (P1). It does NOT include
  `debug` (that's `debugGlobals()`). The fix is a **constructive** whitelist (`new Globals()` + load only
  safe libs), NOT subtractive neutering — dangerous surfaces are then *absent*, not merely hidden, so you
  can't forget one.
- **LuaJ stdlib modules self-register in `package.loaded` on load**, so `g.load(new TableLib())` (and
  `StringLib`/…) throws `attempt to index ? (a nil value)` if `PackageLib` wasn't loaded first (they do
  `env.get("package").get("loaded")…`). So: load `PackageLib` too, then **strip** `require`/`module`/
  `package` in a hardening pass — the libraries are wanted, the require *machinery* is not. `JseBaseLib`
  must be first (it can't depend on package — `standardGlobals` loads it before PackageLib).
- **Watchdog without exposing `debug` (D-018 layer 1):** set `Globals.debuglib = new DebugLibSubclass()`
  **directly — do NOT `g.load(...)` it.** `LuaClosure.execute` calls `globals.debuglib.onInstruction(pc,
  v,top)` on every VM instruction, guarded **only** by `debuglib != null` (verified in bytecode). So
  assigning the field enables the per-instruction hook while **no `debug` table is ever installed** into
  Lua (D-017). Override `onInstruction` to decrement a per-call budget and `throw new LuaError(...)` on
  underflow → caught by the engine's per-callback isolation.
- **The null-`globals` NPE — override `traceback` (and `onCall`/`onReturn`):** an *assigned* (not loaded)
  DebugLib has a **null `globals` field**. LuaJ's default error path — `LuaClosure.execute` catch →
  `processErrorHooks` (when `running.errorfunc == null` && `debuglib != null`) → `debuglib.traceback(level)`
  → `callstack()` → `this.globals.running` — NPEs on **every** Lua error (incl. the watchdog's own throw!).
  Fix: override `traceback(int)→""` and no-op `onCall`/`onCall`/`onReturn` (both overloads). No call-stack
  is kept, so an empty traceback is honest; addon errors still carry LuaJ's `chunkname:line` on the message.
- **Budget must be RE-ARMED per call** (`Sandbox.arm(env)` before each `invoke`/`call`): the counter
  depletes as instructions run, so without a reset a long-lived env would eventually trip on innocent
  later code. Arm at the three entry points — `callLua` (handlers/timers/events), `Addon.run` (file body),
  REPL `eval`. Default cap 10 M ⇒ a tight infinite loop aborts in **~36 ms** (≈2 frames) — imperceptible
  for real callbacks, near-instant for a runaway. `-Dhaven.addon.insncap` overrides (`<=0` disables).
- **The `:lua` REPL is deliberately left UN-sandboxed** (full `standardGlobals()`, incl. `luajava`): it's
  the operator's own trusted console, and the sandbox constrains *shared addon code*, not the user. It IS
  watchdog-armed (typo protection: `:lua while true do end` aborts). So the REPL can do things a real addon
  can't — expected; don't mistake it for a sandbox hole when testing the API.
- **Headless sandbox testing** (same throwaway-in-scratchpad pattern): `Sandbox.create()` needs no live
  game, so a same-package test asserts withheld surfaces are nil / whitelisted present, runs a bounded loop
  (no false-trip) and an infinite loop under a low `-Dhaven.addon.insncap` (aborts fast, catchable LuaError
  with "watchdog" in the message), for BOTH the addon env and `consoleGlobals()`. Also parse-compile the
  real `hello/main.lua` under `Sandbox.create()` to prove the harness stays compatible. 49/49 here.
- **Bumping `hello`: sync BOTH the Lua version string AND `manifest.json`'s `version`.** 1f-1 first bumped
  only the `hafen.log("hello loaded (vX)")` string, so the engine logged `loaded hello v0.10.0` (from the
  manifest) while the addon announced v0.11.0 — a harmless but confusing mismatch caught in the in-game
  run. The manifest `version` is what the engine (and the future AddOns panel, 1f-3) actually reports, so
  bump it every slice too.
- **Reload = reuse the relogin path, don't re-implement it (1f-2).** `AddonManager.init(ui)` already
  does teardown-all → reset → `loadAll`; a `:reload` is the same *minus* the session-infra reset. So
  `reload()` reuses the existing `teardown(Addon)` (OnDisable → flush → clear subs/timers) and `loadAll`
  verbatim, and only adds the in-world tail (restore per-char vars + re-fire `OnEnterWorld`). This
  guarantees reload and relogin can't drift, and keeps the new code tiny. **Do NOT** touch the
  session-scoped infra on reload — the `AddonRoot` tick pump, the `OCache` gob callback, and the
  inbound-`uimsg` tap belong to the session, not the addon layer (D-005 "addon layer only"); rebuilding
  them would be wrong and would double-register.
- **Defer reload to the UI-thread tick — console commands aren't all on one thread.** In-game `:`
  commands run on the **UI thread** (`ConsoleHost.done` ← key event), but the terminal/stdin console
  (`Chatwindow`'s `System.in` reader loop) runs `ui.cons.run` on **its own reader thread**. So a command
  that mutates widgets/Lua state (reload) must not act inline. `:reload` just sets a `volatile
  reloadPending`, and `tick()` runs `reload()` at the top of the next frame (UI thread) — the exact
  `enterWorldPending` pattern. `reload()` is `synchronized` (same monitor as `init`) so a reload and a
  concurrent relogin serialize instead of interleaving; `init` clears `reloadPending` so a reload queued
  against a dead session is dropped. (The `:lua` REPL calling Lua directly from stdin has always been
  off-UI-thread; reads are tolerant, but *reload* is not, hence the defer.)
- **On reload, re-fire `OnEnterWorld` (WoW `PLAYER_LOGIN`), and know it re-ticks login counters.** Spec
  05 step 6 says fire `OnLoad` then `OnEnterWorld` if already in-world, so addons re-init as if freshly
  logged in. Unlike first login there's **no streaming delay** — the HUD/char/items are already resolved,
  so reads inside the re-fired handler work immediately. Consequence to document for addon authors: any
  "logins"/"world entries" saved-var counter also increments on each `:reload`. `restorePerChar()` is
  reused to reload per-char saved vars first (charScope is still valid in-world).
- **Enabled set = a persisted DISABLED set (default-enabled, WoW), in the client prefs (D-006).** Storing
  the *disabled* ids (not the enabled ones) makes a freshly-installed addon **default to enabled** for
  free (it's absent from the set) — matching WoW, and failure-safe (a lost prefs entry re-enables, never
  silently disables). Persist it under the **client folder** via the client's own `Utils.getprefsl`/
  `setprefsl` (a `List<String>` in Java Preferences, key `addons/disabled`) — NOT `savedata/` (that's
  per-char/account saved *variables*, a different scope). `loadAll` reads the set once per scan and skips
  disabled folders (by folder name = addon id, checked before parsing the manifest). Toggling is
  **apply-on-reload** (D-006): `setEnabled` only persists + flags `reloadNeeded`; the change lands on the
  next `:reload`/login. `isEnabled`/`setEnabled` are **public** for the 1f-3 panel; enable/disable is NOT
  an addon-facing Lua API (operator/panel only, D-004).
- **Headless-test the enabled set against an isolated prefs node.** `Utils.prefs()` honors
  `-Dhaven.prefspec` (`Config.Variable.prop("haven.prefspec", "hafen")`) → `userNodeForPackage(Utils).node(spec)`.
  Run the test JVM with `-Dhaven.prefspec=addon-test-1f2` so `setEnabled`/`isEnabled` exercise the **real**
  `getprefsl`/`setprefsl` persistence path without touching the live `hafen` prefs, then `removeNode()` the
  test node afterwards. 14/14 (default-enabled, disable+enable round-trip, idempotency, persistence across
  a fresh read, null/empty no-op). The reload *sequence* itself (widgets/session) stays an in-game DoD.
- **`:addons` should scan the folder, not just the loaded list.** A disabled addon isn't in `addons`, so
  the panel/console must enumerate `addonDir()` folders (those with a `manifest.json`) and cross-reference
  the loaded set + the disabled set to show every discovered addon's status (loaded version / `disabled` /
  `not loaded` / `error`). `findLoaded(id)` maps a folder id back to its live `Addon`. Same enumeration the
  1f-3 panel will need.
- **The options panel lives in `io.brodgar.addon.ui`, NOT nested in `OptWnd` (1f-3) — one-line core edit.**
  Spec 10 endorses either, but the panel needs **no** package-private `haven` access (every widget it
  uses — `Scrollport`/`CheckBox`/`Button`/`Label`/`Widget.add`/`settip`/`pack` — is public, and `ACheckBox.a`
  + `set(boolean)` are public so the voice-style `new CheckBox(){ {a=…} set(){…} }` subclass works
  cross-package), and it only calls the **all-static `AddonManager` facade** (exactly like the voice panel
  calls `Voice`). So the ONLY `haven` edit is one `// addon:` `PButton` line in `OptWnd`; the whole panel
  is new code in the addon package. **`OptWnd.Panel`/`PButton` are non-static inner classes** → extend/
  instantiate them from another package with the qualified `opt.super()` (first ctor statement) and
  `opt.new PButton(...)` forms. It compiles clean at source 1.8.
- **`Widget.add(child, coord)` does NOT route through `addchild` — it links the child DIRECTLY** (`add0`:
  `child.parent=this; child.link()`). `Scrollport` only overrides `addchild` (the server-widget path) to
  route into its `cont`, so `scrollport.add(row, c)` would make the row a direct child of the *port*
  (unscrolled). Add scroll content via **`scrollport.cont.add(row, c)`** (`cont` is public; `Scrollcont`
  overrides one-arg `add` to also bump the scrollbar). General rule: `add`/`add0` = client-built tree
  (direct child); `addchild(Widget, Object...)` = the server-attach seam some containers re-route.
- **Panels built in a ctor have `ui == null` until added to their parent** (voice pattern): `add(...)`
  inside `new AddonPanel(...)` runs before the panel is attached to `OptWnd`, so children get `parent` but
  no `ui`; when `OptWnd.add(panel)` runs, `add0` calls `child.attach(ui)` which recurses the whole subtree.
  So building rows/scroll content in the ctor is fine — the tree attaches as a unit later. A panel that
  wants live data with **no teardown obligation** should **poll the facade in `tick()`** (like this one and
  the read-only bits of the voice panel) rather than register a listener — nothing to unregister → no leak.
  Only register+unregister (voice's `VoiceListener`) when you need push, and mirror it in `destroy()`.
- **Soft per-tick CPU budget (D-018 layer 2) rides the ONE Lua choke point, `callLua` (1f-3).** Wrap
  `fn.invoke` in `System.nanoTime()` and accumulate into `Addon.tickLuaNanos`; `tick()` zeroes it at the
  top (AFTER the reload early-return, so a reload tick's one-off `OnLoad`/`OnEnterWorld` don't count) and
  `enforceSoftBudget()` evaluates at the bottom. It's the complement to layer 1's **per-call** instruction
  cap: layer 1 kills a single runaway callback (~36 ms), layer 2 catches an addon whose handlers each stay
  under the cap but **sum to** most of every frame. Use **consecutive** over-budget ticks with a **reset on
  any at-or-under tick** (strict `>` budget) so a heavy `OnEnterWorld` / one janky frame never trips it —
  only a *sustained* offender (default 10 ms × 30 ticks ≈ 0.5 s). **Auto-disable is session-only**: record
  a warning + run the 1f-2 `teardown` + drop from `addons`; do **NOT** touch the persisted enabled set (a
  reload/login re-tries; the user persist-disables via the panel). Enforce at **end of tick** so mutating
  the (CopyOnWrite) `addons` list is safe. The REPL owner is exempt for free — it's not in `addons`.
- **Don't fold a CPU hog into the `hello` regression harness (1f-3) — ship a dedicated `hogtest` addon,
  DORMANT by default.** An always-on hog would auto-disable itself (and hitch) every login, breaking the
  harness. Gate it on an **account-scope saved var** `cfg.arm` (default false, seeded on first run) so a
  normal login is undisturbed; arm it (edit `savedata/account/hogtest.json` to `{"cfg":{"arm":true}}`, or
  the unsandboxed `:lua io.open(...)` one-liner) + `:reload` to demonstrate the auto-disable on demand.
  In-game arming can't be an addon API yet (no console/hook API until Phase 2), so a saved-var file flip is
  the cleanest opt-in. Calibrate the hog with a **wall-clock `os.clock` busy-wait** (~15 ms), not a fixed
  instruction count — it must be reliably OVER the ms budget but UNDER the per-call instruction cap
  regardless of machine speed (a fixed loop count is machine-dependent and could trip the hard cap instead).
- **1f-3 added NO Lua-facing API, so `hello` was left unchanged** (correctly). The panel is operator UI and
  the soft budget is an engine watchdog — neither is a `hafen.*` surface an addon calls. When a task adds
  no addon-observable behavior, extend the harness with a **new example addon** that exercises the engine
  behavior (here `hogtest`) instead of bumping `hello` for no functional reason (a no-op version bump is
  just noise — the 1f-1 learning was about keeping the Lua string ↔ manifest version in sync *when* you do
  bump).
- **Splitting Phase 2 (custom UI + hooks) like 1c/1d/1f:** `hafen.ui` (windows/widgets, overlays, gob
  overlays) + `hafen.hook` (input/action/message) is far too big for one prompt/verification. Slices: **2a**
  custom widgets/windows + GOut wrapper (done), **2b** HUD + gob overlays, **2c** input hooks (L1, zero-edit
  `Widget.listen`), **2d** action hooks (L2, `UI.wdgmsg`) = the `hook.action("click")` DoD, **2e** message
  hooks (L3, `UI.uimsg`) + `hafen.key` hotkeys. L4 method/hookable-subclass hooks fold into Phase 3.
- **The input event model is object-based (this fork), not `(Coord, int button)`:** `Widget.mousedown(
  MouseDownEvent ev)` where `ev.c` is the **widget-local** Coord and `ev.b` the button; `MouseUpEvent` same;
  `MouseMoveEvent` has `ev.c` (returns void); `MouseWheelEvent` has `ev.c`, `ev.a` (amount int), `ev.s`
  (double); key events (`KeyDownEvent`/`KeyUpEvent extends KbdEvent`) carry `code`/`mods`/`c` (char). A
  handler **returning `true` consumes** (mouse/wheel/key are boolean; mousemove is void). These nested types
  are inherited by a `Widget` subclass, so `LuaWidget` references `MouseDownEvent` unqualified.
- **Two opposite arg conventions in the UI bridge — get them right (2a):** an addon's *callbacks* (`onDraw`,
  `onClick`, …) are invoked FROM Java via `fn.invoke(varargsOf(x,y,b))`, so **no `self`** — `onClick(x,y,b)`
  reads arg1..3 directly. But the *wrapper/handle methods* (`g:text(...)`, `win:move(...)`) are Lua
  **colon-calls INTO** my Java `VarArgFunction`s, so **`self` is arg1** and real params start at `arg(2)`.
  Mixing these up shifts every coordinate by one arg. Headless-verify the callback side (mouse dispatch with
  a recording Lua fn — no GOut needed); verify the wrapper side in-game (text/bars land at the right pixels).
- **`callLua` returns `Varargs` now (was `void`)** so input forwards can read the handler's return for
  "consume" (`.arg1().toboolean()`); every existing caller ignores the return, so it's a safe widening. Route
  ALL widget callbacks (draw/tick/mouse) through `callLua` — that's the single choke point that arms the
  watchdog (D-018 layer 1), isolates errors, and accounts CPU time. Don't call `fn.invoke` directly anywhere.
- **Custom windows = composition, not a `LuaWindow` subclass (D-013 one-way, DRY):** a plain `haven.Window`
  already gives the title bar, **drag** (`DefaultDeco` → `Window.drag`/`grabmouse`), and a close button — so
  `hafen.ui.window` builds `new Window(size, title)` and adds ONE `LuaWidget` content child at `Coord.z`
  (the deco offset is handled by `Window.xlate`). All the Lua-forwarding lives in `LuaWidget` alone; the spec's
  separate `LuaWindow` would duplicate it. **Redirect `Window.reqclose(Runnable)`** — its default is
  `wdgmsg("close")`, which a client-side (server-unbound) window can't send (it falls through to `ui.root` and
  is dropped) — to fire `onClose` then destroy.
- **`Window` draws its children every frame via an offscreen buffer** (`Window.draw` → `drawbuf` →
  `super.draw` into `gbuf`, then blits) — so a `LuaWidget` content child's `onDraw` fires every frame with a
  GOut already clipped/translated to its area; drawing at `(0,0)` hits the content top-left. No caching to
  worry about. The window ctor's `sz` is the **content** size; the deco sizes the frame around it.
- **The GOut wrapper must be inert outside `onDraw`:** hold the live `GOut` in a `LuaWidget` field set right
  before the `onDraw` call and nulled in a `finally`; every wrapper method early-returns if it's null. This
  is the spec's "resets state per callback" — an addon that stashes `g` in a timer can't draw into a stale/
  wrong context. Build the wrapper table **once** in the ctor (closures over the widget), not per frame.
- **Owned custom UI teardown (2a):** a new `Addon.widgets` (`List<LuaWidget>`) is the P2 registry, alongside
  `subs`/`timers`. `teardown` (relog/`:reload`/disable/CPU-auto-disable) calls `destroyWidgets` **under
  `synchronized(ui)`** — `LuaWidget.kill()` sets a `dead` flag (silences any late callback) then destroys its
  **root** (the window chrome for a window, else itself), which cascades to children. Track the LuaWidget
  content (not the window) + give it a `root` ref, so one list type covers both `window` and `widget`. A
  bridge-created widget is safe to attach off the UI thread because `Widget.add` locks on `ui`.
- **Draw callbacks escape the soft per-tick CPU budget (2a known gap):** `onDraw` runs in `UI.draw`, which is
  *after* `tick()` zeroes `tickLuaNanos` and *after* `enforceSoftBudget()` (both in the same frame's tick).
  So draw Lua time is wiped before it's ever evaluated → layer-2 auto-disable never sees a draw hog. The
  per-call **instruction cap (layer 1) still aborts** a single runaway draw. Folding draw time into the budget
  needs a frame-boundary accounting change (deferred); for now, document it and rely on layer 1 for draws.
- **`OnEnterWorld` was firing BEFORE `GameUI` is attached to `ui.root` (2a fix — the real "entered" signal).**
  The 2a demo window was invisible on a fresh login but appeared after `:reload`. Root cause found by
  instrumenting the server→client widget protocol (temporary `[wdbg]` traces at `UI.NewWidget.run` /
  `AddWidget.run` / `UiMessage.run` + a marker where we fire OnEnterWorld): across 3 logins, our marker fired
  **exactly one line before** `ADD GameUI -> parent RootWidget`. `MapView` sets `enterWorldPending` from its
  ctor and `gui()` finds `GameUI` **via the map view** (`view.getparent(GameUI.class)`) a beat before GameUI
  is added to the root — so the old gate `gui() != null` fired too early. A window added to `ui.root` then is
  a sibling placed **before** GameUI → the full-screen HUD draws **on top of it** (hidden). On `:reload`
  (in-world) GameUI is already under root, the window is added **after** it → on top → visible. That's the
  exact login-vs-reload asymmetry. **Fix:** gate OnEnterWorld on `gui().parent != null` (GameUI is in the
  tree), firing the tick after the HUD mounts — one clean line in `tick()`, benefits every addon (ui.root
  windows now land on top), and OnEnterWorld is semantically correct (the HUD root is actually attached).
  Streaming-in of GameUI *children* (inv/meters/char) still lags a beat — unchanged; read those on a timer.
  **The reliable "fully entered the world" signal is `GameUI` being added to `RootWidget`** (≈ WoW
  `PLAYER_ENTERING_WORLD`); `gui().parent != null` is the cheap UI-thread test for it.
- **Instrumenting the widget protocol is a strong diagnostic (kept in a learning, code reverted):** three
  `System.out.println` taps — widget **create** (`UI.NewWidget.run`), **place** (`AddWidget.run`, shows
  `child -> parent` — the most revealing for tree assembly), and **message** (`UiMessage.run`) — plus a marker
  at the code point under test, tagged `// addon-debug:` for one-grep removal, captured to a file over a few
  logins, pinpointed an ordering race in minutes. `ant run` forks the client with stdout inherited, so
  `ant run 2>&1 | tee x.log` captures it (note: PowerShell `tee` writes **UTF-16** — `tr -d '\000'` to read;
  ant prefixes forked stdout with `[java]`).
- **The frame loop is `tick → draw → swap`, sequential, on ONE thread (2b — the key threading fact).**
  `UILoop.Frame.run()` calls `tick()` (→ `ui.tick()` → the `AddonRoot` tick pump) then `display()` (→
  `ui.draw`), both under `synchronized(ui)` on the single "Haven UI thread". So **every** Lua callback — tick
  events/timers/`OnUpdate` AND draw callbacks (widget `onDraw`, HUD overlays, gob overlays) — runs on that one
  thread, sequentially; there is **no concurrent LuaJ access** to guard against (LuaJ is not thread-safe, so
  this matters). It also means a `ui.drawafter(cb)` **registered during `tick` fires that same frame** (tick
  precedes draw), and a `PView.Render2D.draw` runs *inside* the `ui.draw` traversal (below), not on a
  separate render thread.
- **HUD overlays = re-queue ONE `UI.drawafter` per tick (2b).** `UI.drawafter` is one-shot (`UI.draw` clears
  `afterdraws` after painting), so you can't register-and-forget. But `UI.draw` runs the afterdraws **after
  `root.draw(g)`**, i.e. above the whole HUD — exactly where a HUD overlay must land (a `ui.root` sibling
  added *before* `GameUI` draws *under* it, the 2a asymmetry). So: keep a persistent per-addon overlay list,
  and each `tick` (which precedes draw) `ui.drawafter(oneStaticAfterDraw)` when the list is non-empty; the
  afterdraw paints the whole list with the full-screen root `GOut`. Re-queuing the SAME static instance each
  frame is fine (cleared each draw; one tick per draw → one entry). Don't register each overlay as its own
  drawafter (they'd be one-shot); register one pump that iterates the list.
- **Gob overlays generalise `SpeakerIcon` — and need ZERO `haven` edit (2b).** A world-space overlay is a
  `GAttrib implements RenderTree.Node, PView.Render2D` attached with `gob.setattr(...)`; the render tree pins
  it over the gob in every camera and disposes it with the gob. Its `draw(GOut, Pipe state)` runs from
  `PView.draw → list2d.draw` (`ScreenList`, the 2D pass) — which is **inside the normal `ui.draw` widget
  traversal** (MapView *is* a Widget), so it's on the UI thread, same frame, never racing the tick. Project
  the anchor with `Homo3D.obj2view(new Coord3f(0,0,z), state, Area.sized(g.sz())).round2()` (z≈15 = head
  height, the buddy-name-label anchor). **Unlike `SpeakerIcon`** (which lives in `haven` to *reflect* into
  another gob's `Info` name texture), a generic overlay reads nothing package-private: `GAttrib`'s ctor +
  `gob` field are public, and `Gob.setattr/getattr/delattr`, `PView.Render2D`, `RenderTree.Node` (its
  `added`/`removed` are empty defaults `GAttrib` overrides), `Homo3D.obj2view`, `Area.sized`, `GOut.sz()` are
  all public → the overlay attrib lives in `io.brodgar.addon`, zero-edit.
- **One SHARED gob-overlay attrib per gob serves all addons (2b).** `getattr` keys by exact class, so you
  can't attach a per-addon subclass. Instead attach **one** `LuaGobOverlay` per gob that holds **no** addon
  state; its `draw` calls back into `AddonManager.paintGobOverlays(gob, …)`, which re-checks **every** addon's
  filter for that gob and paints the matches. Two addons overlaying the same gob need one attrib; removing one
  addon's overlay just stops painting it (the idle attrib draws nothing). Detach idle attribs wholesale only
  when **no** addon wants gob overlays (handle `:remove()` / teardown) — reload-safe because a `:reload` keeps
  the same session/OCache (the attribs would otherwise linger on persistent gobs). `detachGobOverlays` mutates
  render slots under `synchronized(ui)` (like `destroyWidgets`) since teardown can run off the UI thread.
- **Dynamic (Lua) filters → THROTTLE the gob sweep; attach-only (2b).** `SpeakerIcon.sweep` runs every frame
  with a cheap Java filter (`isPlayer`). A gob overlay's filter is arbitrary Lua, so evaluating it for all
  ~150+ gobs at 60 fps is wasteful — rate-limit the sweep (default 5 Hz, `-Dhaven.addon.gobsweepsec`). The
  sweep only ATTACHES (a gob that later stops matching keeps an idle attrib; the per-frame draw re-checks the
  filter and paints nothing). The sweep runs in `tick`, so its filter time IS covered by the soft CPU budget
  (D-018 layer 2) — the expensive all-gobs part is watched. **Draw** callbacks (HUD + gob, like 2a `onDraw`)
  run in `ui.draw` after the tick's budget window, so their time escapes the soft budget (same gap as 2a); the
  hard per-call instruction cap still applies. So: expensive filtering = budgeted; drawing = instruction-capped.
- **Extract the `g` wrapper once, share it everywhere (2b, DRY / D-013).** 2a's GOut wrapper was inline in
  `LuaWidget`; 2b needs the identical surface for HUD + gob overlays. Pull it into a standalone
  `io.brodgar.addon.LuaGOut` (`bind(GOut)`/`unbind()`, inert when unbound) and have `LuaWidget`, the HUD pump,
  and `LuaGobOverlay` all use it — one canonical `g:text/atext/rect/frect/line/prect/color` everywhere, no
  drift (the same reasoning as the shared `readEquipment` in 1d-4). Refactoring `LuaWidget` onto it kept
  behaviour identical (the 2a in-game draw was the check; the refactor is pure extraction).
- **LuaJ `isstring()` is TRUE for numbers (2b test gotcha).** A filter validation `filter.isfunction() ||
  filter.isstring()` accepts a **number** (Lua coerces number↔string), so `gobOverlay(3, fn)` treats `3` as
  the substring filter `"3"` — consistent with the existing `world.gobs` `matches()` (same `isstring()`), so
  it's intended, not a bug. A truly-invalid filter to reject is a table/boolean/nil (`isstring()` false).
  Caught by the headless test asserting rejection → fixed the *test* (use a table), not the code.
- **Input hooks are a BUILT-IN pre-hook — `Widget.listen`/`handle` (2c, zero core edit).** `Widget.handle`
  runs registered `EventHandler` listeners **before** the widget's own default (`shandle`), and a listener
  returning `true` **short-circuits** — the default never runs. `Event.dispatch` then returns immediately, so
  a consuming listener also **blocks child dispatch** (preventDefault ⇒ stopPropagation at this seam → expose
  **one** consume, not both). So `hafen.hook.input` needs no `haven` edit: wrap `listen`/`deafen`. Event
  fields are public: `Widget.PointerEvent.c` (coord, all mouse events), `MouseButtonEvent.b` (button),
  `MouseWheelEvent.a` (wheel amount). Test the core headlessly by calling `w.handle(new MouseDownEvent(coord,
  btn))` directly (no `dispatch`, so no `CPUProfile`/graphics needed) and asserting the widget's own
  `mousedown` did/didn't run — a real `Widget` subclass instantiates fine headless (as 2a's LuaWidget tests
  already showed).
- **`:reload` keeps engine widgets ALIVE → hooks MUST be deafened on teardown (2c, P2).** Unlike an addon's
  own `LuaWidget` (destroyed on teardown), an input hook is attached to a **persistent** engine widget
  (MapView/GameUI/root survive a `:reload` — only the Lua layer rebuilds). If teardown didn't call
  `Widget.deafen`, the old `LuaInputHook` would keep firing into the torn-down env. So `teardownHooks` deafens
  + marks each hook dead (the `alive` flag also no-ops a dispatch racing teardown). A hook resolved to a
  specific instance also dies naturally when that widget is destroyed (its listener list goes too) — the
  explicit deafen is for the reload-persists case. Register hooks in **`OnEnterWorld`** (the target must
  exist), which `:reload` re-fires — so they re-install automatically.
- **Generic `listen()` + captured wildcard (2c Java gotcha).** `Widget.listen(Class<E>, EventHandler<? super
  E>)` with an `eventClass()` returning `Class<? extends Widget.Event>` can trip javac's wildcard-capture
  inference. Sidestep it: make the listener `EventHandler<Widget.Event>` (works for any concrete event since
  all extend `Widget.Event`) and widen the class token's **compile-time** type only —
  `(Class<Widget.Event>)(Class<?>)cls` — the runtime `Class` is unchanged, so `Listener.check`'s
  `t.isInstance(ev)` still keys on the real subclass. One `@SuppressWarnings("unchecked")` helper.
- **The MapView `"click"` is sent from the RENDER thread, but under `synchronized(ui)` (2d — the pivotal
  threading fact).** `mousedown` submits an async GPU `Hittest`; when the fragment readback completes,
  `Hittest.ckdone` (on the render/GL thread) takes **`synchronized(ui)`** and calls `hit(...)` →
  `wdgmsg("click", {pc, mc.floor(posres), button, mods [, gob…]})`. So an action hook at `UI.wdgmsg` does **not**
  run on the UI thread for clicks. But `UILoop.Frame.tick` runs input dispatch + the addon tick under the same
  `ui` monitor, and `Frame.display` draws under it too — so **every path that runs Lua holds `synchronized(ui)`**.
  A naive `Thread == uiThread` guard would WRONGLY skip the click hook (render thread ≠ UI thread), breaking the
  DoD. The right guard is **`Thread.holdsLock(ui)`**: run the hook's Lua only when the caller already holds the
  `ui` monitor (true for input dispatch, the tick, AND the hit-test callback), which mutually excludes it from
  tick/draw Lua → no LuaJ race. It only **tests** the lock (acquires nothing), so **no deadlock** is possible;
  a rare off-lock `wdgmsg` is passed through unhooked. Verify the threading by reading `UILoop.Frame.tick`
  (`synchronized(ui)` wrapping `loop.dispatch` + `ui.tick`) and `MapView.Hittest.ckdone` (`synchronized(ui)`
  before `hit`), not by assuming actions are UI-thread.
- **L2 = ONE core edit at `UI.wdgmsg`, split into hook + `rawWdgmsg` (2d, D-011).** `wdgmsg` becomes
  `if(!AddonManager.onWdgmsg(sender,msg,args)) return; rawWdgmsg(sender,msg,args);`, and the original send body
  (widgetid + `rcvr.rcvmsg`) moves verbatim into a new **public `rawWdgmsg`**. `ev:resend()`/`ev:send()` call
  **`rawWdgmsg`, not `wdgmsg`**, so re-issuing an action **bypasses the hook chain** — the spec's re-entrancy
  caveat solved by construction (no guard needed for resend itself; a small `dispatchingAction` boolean still
  guards a hook body that triggers some *other* wdgmsg). Keep the fast path near-zero (`actionHooks.isEmpty()`
  first — `wdgmsg` is hot). `resend`/`send` **imply preventDefault** (they take over the send); doing nothing →
  normal send; `preventDefault` alone → dropped (resend later from a timer = "do X, then move").
- **Marshalling wdgmsg args Java↔Lua (2d): keep the default/resend path LOSSLESS, convert only on read/`send`.**
  `resend()` and the default send reuse the **original `Object[]` verbatim** (no conversion → no loss, even for
  exotic args). Only **`ev.args` (read)** and **`ev:send(t)` (rewrite)** marshal: `Coord`↔`{x,y}` table,
  Integer/Short/Byte→int, Long/Double/Float→double (the usual `>2^53` caveat), String/Boolean direct, and
  **anything else → `LuaValue.userdataOf(obj)`** which `touserdata()` maps back to the **identical** object — so
  a clicked gob's click-data survives untouched. Discriminate on `v.type()` (`TNUMBER`/`TSTRING`/… — a numeric
  `LuaString` has type `TSTRING`, so this beats `isnumber()`); `LuaInteger`→Integer else Double. The full
  `{pc, world, button, mods}` click vector round-trips exactly (headless-verified), so `ev:send(ev.args)` is faithful.
- **The two arg conventions bite `ev:send` too (2d, re-confirms the 2a rule).** `ev:preventDefault()`/`resend()`
  take no real args → a `ZeroArgFunction` (ignores the colon `self`). But **`ev:send(t)`** is a colon-call, so
  `self`=arg1 and the table `t`=arg2 → it MUST be a **`TwoArgFunction`** reading arg2, never a `OneArgFunction`
  (which would read `self`). Headless-testable without a live UI: put a recording `TwoArgFunction` in a table and
  call `t:m(payload)` from Lua, asserting arg1==the table and arg2==payload.
- **Action hooks are owned but have NO widget to deafen (2d, differs from 2c).** An L1 input hook is a
  `Widget.listen` listener (teardown = `deafen`). An L2 action hook lives **only** in `AddonManager`'s per-`msg`
  dispatch map, so `Addon.actionHooks` teardown just marks it dead + removes it from the map (drop the now-empty
  per-`msg` list so the `isEmpty()` fast path stays meaningful). A `:reload` rebuilds the Lua layer but not the
  `UI.wdgmsg` seam (session infra), so unregistering on teardown is what prevents a stale hook firing into a
  torn-down env — same P2 reasoning as deafening input hooks, different mechanism.
- **Headless-testing an L2 hook without constructing a live `UI` (2d).** A real `UI` needs a real `Audio.Root`
  (`new ActAudio.Root(null)` NPEs on `sys.mixer`), so don't build one. Test the pieces that don't need it: the
  marshalling converters (pure static), `LuaActionHook.invoke` with a real `Sandbox.create()` env + a `new
  Widget()` sender + `u=null` (a preventDefault/passthrough handler never dereferences `u`), the colon-call
  convention in isolation, and `onWdgmsg`'s no-hook fast path (returns true before the `ui`/`holdsLock` check).
  The `resend`/`send` → `rawWdgmsg` wiring (one line each) and the `holdsLock` gate are then the only in-game
  bits — same "headless proves the logic, in-game proves the wiring" split as prior slices. 33/33 here.
- **L3 = the inbound mirror of L2, at `UI.UiMessage.run` — and it needs NO `holdsLock` gate (2e-1).** Server
  updates funnel through `UI.uimsg(id,msg,args)` which only *queues* a `UiMessage`; the message is actually
  APPLIED later in `UiMessage.run()` on a **Loader thread** under `synchronized(ui)` via `dispatch(wdg,
  MessageEvent)`. Hook there (before the dispatch), NOT at `UI.uimsg` (pre-resolve — no widget yet, wrong
  thread). The one edit: `Object[] happly = AddonManager.onMessage(wdg,msg,args); if(happly!=null) dispatch(...,
  new MessageEvent(msg, happly));` — `onMessage` returns the args to apply, a rewritten array, or **null to
  swallow**. Unlike L2 (whose `wdgmsg` senders aren't all UI-locked, hence 2d's `Thread.holdsLock` gate), this
  seam is reached ONLY from `UiMessage.run`, which is **always** under `synchronized(ui)` — the tick/draw
  monitor — so the hook Lua can never race other Lua and no gate is needed. Trade-off: a heavy L3 handler holds
  the `ui` monitor on the Loader thread and **stalls the frame** (spec's "keep it light"); the D-018 layer-1
  instruction watchdog still bounds a single runaway.
- **Gate the 1d post-apply read tap on the message being applied (2e-1).** `UiMessage.run` originally always
  called `AddonManager.onUimsg` (the 1d-1 widget-tree tap) after `dispatch`. Now that an L3 hook can **swallow**
  a message (skip the dispatch), fire the tap only when the message was actually applied (`if(applied)`): a
  swallowed message left the widget unchanged, so re-reading would be pointless (and firing a `*Changed` off an
  unapplied update would be wrong). When no L3 hook is registered, `onMessage` returns the original args →
  `applied` is always true → identical behaviour to before (no regression for vitals/buffs/food/etc.).
- **`MessageEvent`'s ctor interns the name — the spec's L3 intern caveat is handled for free (2e-1).**
  `Widget.MessageEvent(msg,args)` does `this.msg = msg.intern()`, and `Widget.uimsg` compares names with `==`
  on interned strings. So rewriting the message NAME (deferred) would be safe automatically (build a new
  `MessageEvent` with the new name → interned in the ctor). This slice only rewrites ARGS (`ev:rewrite(t)`),
  keeping the name, so the caveat doesn't bite at all. Args rewriting reuses 2d's colon-call `TwoArgFunction`
  (self=arg1, table=arg2) — the same convention `ev:send` needs; a `OneArgFunction` would read `self`.
- **Extract shared marshalling into `LuaMarshal` when a second hook level needs it (2e-1, DRY / D-013).** 2d's
  `toLua`/`toJava`/`argsToLua`/`luaToArgs` lived inside `LuaActionHook`; L3 needs the identical Java↔Lua arg
  conversion. Pull them into a standalone `io.brodgar.addon.LuaMarshal` (static, neutral error messages taking a
  `ctx` label) and have both `LuaActionHook` and `LuaMessageHook` call it — one canonical converter, no drift
  (same reasoning as the shared `LuaGOut` in 2b and `readEquipment` in 1d-4). The refactor is pure extraction
  (behaviour identical — the 2d headless round-trips still pass, now exercising `LuaMarshal` directly).
- **`onMessage` precedence: preventDefault wins over rewrite; last rewrite wins; dead hooks skip (2e-1).** Share
  a `boolean[] prevented` + `Object[][] rewritten` across all hooks matching one message. At the end: if
  `prevented` → return null (swallow); else if `rewritten[0]!=null` → return it; else the originals. So a
  suppress from ANY matching hook beats a rewrite from another (suppression is the stronger, safer intent). A
  `LuaMessageHook.alive==false` (torn-down but racing) is skipped in the loop — the same P2 guard as action/input
  hooks. Copy-on-write per-`msg` list so a hook may `:remove()` itself mid-dispatch.
- **Demo L3 with a safe, reversible, VISIBLE suppression: freeze the vitals meters (2e-1).** Hook `"set"` scoped
  to `ev.target == "IMeter"` (the HUD vitals bars use `LayerMeter.uimsg("set")`; the `im` factory builds `IMeter`
  directly, so the class simple name is exactly `"IMeter"`). While a toggle is ON, `ev:preventDefault()` swallows
  the update → the hp/stamina/energy bars **freeze** on the real HUD (and in the 2a window, which reads
  `hafen.player.vitals()` off the same meters) — a clear on-screen effect. It's purely cosmetic and fully
  reversible: the server still knows the true vitals; the next un-swallowed `set` thaws the bars. This is the
  cleanest L3 DoD that doesn't risk corrupting client state (unlike swallowing structural/inventory messages).
  NB: `"set"` is a common message name (many widgets use it), so the hook fires for every `"set"` and early-
  returns on non-`IMeter` targets — fine for a demo, and it shows filtering by `ev.target` in action.
- **Headless-test `onMessage` end-to-end via reflection into the private dispatch map (2e-1).** `LuaMessageHook`
  needs only a throwaway `Addon` (package-private ctor + a `Sandbox.create()` env — no live UI, unlike 2d's
  `onWdgmsg` which needs `holdsLock`), so the FULL `onMessage` precedence path IS headless-testable: reflectively
  grab the private `static messageHooks` map, `put` a `CopyOnWriteArrayList` of hooks, call the public
  `onMessage`, assert (null=swallow / new array=rewrite / same-array-identity=fast path). Build handler fns with
  `env.load("return function(ev) … end","=t").call()` (the Java compile API works on a sandbox env — it strips
  only the Lua-facing `load`). 27/27; the fast path returning the *same* array instance (`==`) proves near-zero cost.
- **LuaJ canonicalises small whole doubles to LuaInteger (2e-1 test gotcha).** `LuaValue.valueOf(9.0)` returns a
  `LuaInteger`, so a `Long` of 9 marshalled via the double path reads back `.isint()==true` (the VALUE is exact —
  correct). The `>2^53`/precision caveat only bites large values: a `Long` above 2^31 (`1L<<40`) stays a
  `LuaDouble`. Assert the marshalled *value* (`.todouble()==9`), not the internal int/double tag, for small
  numbers — the tag is an implementation detail LuaJ is free to optimise.
- **Global hotkeys are a BUILT-IN seam — `UI.keydown`→`GlobKeyEvent`→`Widget.globtype` (2e-2, zero core edit).**
  `UI.keydown` first dispatches a **focused `KeyDownEvent`**; **only if unconsumed** does it fire a `GlobKeyEvent`
  that walks the whole tree calling `globtype` on each widget (this is how the client's own hotkeys work —
  `GameUI`/`MapView`/belt all override `globtype`). Two free wins fall out: (1) a hotkey fires only after an
  **unconsumed** focused KeyDownEvent — a focused text field consumes the keys IT handles, i.e. **all ordinary
  typing** (`ReadLine` inserts any printable char with no Ctrl/Alt → returns true), so a plainly-typed hotkey is
  naturally suppressed while typing; a chord the field *ignores* (Ctrl+H in PC edit-mode) can still fire, exactly
  like the client's own Ctrl-bindings — don't over-claim "never fires while typing". (2) Overriding `globtype`
  on our invisible **`AddonRoot`** (already on `ui.root`) needs **no `haven` edit** — same "reuse the engine's
  dispatch seam" move as 2c's `Widget.listen`. Pattern: `if(AddonManager.onGlobKey(ev)) return true; return
  super.globtype(ev);`.
- **`GlobKeyEvent.propagation` does NOT check `visible()` — the invisible AddonRoot receives it (2e-2).** Unlike
  `FocusedKeyEvent`/`MouseHoverEvent` propagation (which skip invisible children), `GlobKeyEvent.propagation`
  iterates `from.lchild…prev` unconditionally, and `Event.dispatch` doesn't gate on visibility either — so a
  `visible=false` `AddonRoot` still gets `globtype`, just like it still gets ticked (the same invisible-widget
  property the tick pump relies on). No need to make AddonRoot visible.
- **Walk order = precedence: AddonRoot is walked LAST, so client keys win (2e-2).** The `GlobKeyEvent` walk is
  reverse-child-order (`lchild…prev`) and depth-first, returning true on the first consumer. `AddonRoot` is
  attached at session bind (before `GameUI`), so it's an **early** child → visited **after** GameUI/MapView/belt
  and all their subtrees. A client binding on the same key is therefore matched first; an addon hotkey only fires
  for keys the client left unbound → **addon hotkeys are a fallback, never a hijack**. For a reliable demo bind an
  obviously-free key (client defaults are Ctrl+A/B/C/E/G/M/O/T/Z, Alt+A/F/R/S, Ctrl+Tab/Enter, Shift+1..5, arrows,
  V, Tab; the belt eats F1..F12 in FKey mode or 0..9 in NKey mode) — **`Ctrl+H`** is free.
- **`KeyBinding` is a PROCESS-GLOBAL, PERSISTENT registry — key it right, tear down the wrapper only (2e-2).**
  `KeyBinding.get(id, defkey)` caches by `id` in a static map and restores the user's re-map from `Utils.getpref
  ("keybind/"+id, …)`; the `defkey` is used **only on first creation**. So re-fetching the same id across
  reloads/sessions returns the SAME binding with the user's saved key — exactly the persistence we want. Namespace
  addon ids as `addon/<addonId>/<name>` (can't collide with client bindings or across addons). Teardown drops
  only the `LuaKeyBind` (fn wrapper) from the dispatch list; **never remove the `KeyBinding`** (that would forget
  the user's re-map). Consequence: changing `defaultKey` in code does NOT override a key the user already has —
  same as every client binding (document it).
- **`KeyMatch` is the match primitive; parse strings TO it, don't reinvent matching (2e-2).**
  `KeyMatch.forcode(code, mods)` (named/VK keys) / `forchar(chr, mods)` (single chars) build a matcher;
  `km.match(KbdEvent)` does the compare (`mods = UI.modflags(ev)`; modmask defaults to `S|C|M` so **exact**
  modifier match — `"M"` won't fire on `Ctrl+M`). `KeyMatch.nil` (chr=0, code=VK_UNDEFINED) never matches →
  perfect for an **unbound-by-default** binding (`defaultKey=nil`/`"None"`). Parser: split on `+`, last token =
  key (named-key table → `forcode`, else single char → `forchar`), earlier tokens = modifier aliases. `mods` are
  `KeyMatch.S=1/C=2/M=4` and `UI.MOD_*` alias them 1:1, so building an AWT event with `InputEvent.CTRL_DOWN_MASK`
  yields `modflags==C`.
- **Headless-testing anything that builds a `KeyEvent`/`GlobKeyEvent` drags in `UI.<clinit>` (2e-2).** `KbdEvent`'s
  ctor calls `UI.modflags`, and `UI`'s static block runs `loadscale()`→`initscale()`→`Toolkit.instance()` — which
  **NoClassDefFoundErrors** without `lib/jglob.jar` on the classpath, then throws a **caught** `Unavailable`
  ("could find no working toolkit") under `-Djava.awt.headless=true` (an `Error` isn't caught by `initscale`'s
  `catch(Exception)`, but the toolkit `Unavailable` IS → falls back to default scale and proceeds). So the
  headless run needs `build/classes;luaj;lib/jglob.jar` (+ jogl/lwjgl so the providers load and fail *gracefully*
  headless) and `-Djava.awt.headless=true`; a benign "could not determine maximum scaling factor" warning prints,
  then the real events/`match`/`onGlobKey` all work. Use `forcode` keys (F5, Ctrl+F5) for deterministic match
  asserts (no AWT control-char mangling); `-Dhaven.prefspec=addon-test-2e2` isolates the `KeyBinding` prefs. 31/31.
- **Task 2e complete (2e-2): the hook levels + hotkeys are all in.** L1 input (2c), L2 action (2d), L3 message
  (2e-1), and `hafen.key` hotkeys (2e-2). Three of the four reused a **built-in engine seam at zero core edit**
  (`Widget.listen` for L1, `Widget.globtype`/`GlobKeyEvent` for hotkeys) or **one minimal `UI.java` edit** (L2/L3
  at the wdgmsg/uimsg choke points). **L4** (method replacement / hookable subclasses) folds into **Phase 3**
  (widget replacement) — the next task.
- **Surfacing addon keybinds in the client panel = one tiny edit, because the client's `SetButton` already does
  capture + persist (2e-3).** `OptWnd.BindingPanel.addbtn(cont, label, KeyBinding, y)` pairs a label with a
  `SetButton extends KeyMatch.Capture`; the Capture grabs the next keypress and calls `KeyBinding.set(key)` →
  `Utils.setpref("keybind/"+id, …)`, restored next launch by `KeyBinding.get`/`KeyMatch.restore`. So an addon
  binding (whose id is `addon/<id>/<name>`, a real client `KeyBinding` since 2e-2) drops straight into `addbtn`
  with **zero new capture or persistence code** — the whole slice is: a read-only `AddonManager.describeKeyBinds()`
  (group the live `keyBinds` by owner) + a `// addon:` loop in `BindingPanel` after "Voice chat" that emits a
  `Label(addonName)` header + one `addbtn` per binding. **Don't reinvent key capture/persistence — reuse the
  client's binding widget.** The api-reference's "shown in the client keybind panel" was the intended home; the
  panel is a **hardcoded list**, so the only way in is to append rows (it does not auto-enumerate
  `KeyBinding.bindings`).
- **Panel-build-time enumeration is sufficient (2e-3).** `BindingPanel` is rebuilt each time it's opened, and an
  addon binds its hotkeys at load (file body/OnLoad) — before you can open Options — so reading the live
  `keyBinds` list in the ctor always reflects the current, enabled addons. A disabled/unloaded addon has no live
  bind → no section (WoW parity), while its persisted key pref still survives in the `KeyBinding` registry for
  when it reloads. Group by owner with a `LinkedHashMap<Addon, …>` to keep first-registration order; label the
  section with `manifest.name`, the row with the bind's `name`. (No live refresh while the panel is open — a
  hotkey bound via `:reload` with the panel already open needs a reopen; acceptable, matches the rest of it.)
- **`hello` demo idiom for an assignable-from-panel hotkey (2e-3): bind a SECOND key UNBOUND by default
  (`hafen.key.bind("ping", nil, fn)`).** It contributes a second row to the addon's section and starts as
  `None`, so it exercises the panel's assign-from-scratch flow (the user picks a key, it fires + persists) —
  complementing the pre-bound `toggle` (Ctrl+H). Two rows also prove the per-addon grouping visually.
- **The vanilla client has NO keybinding-conflict detection — the same key can bind to many actions (2e-3).**
  `KeyBinding.set` just writes the pref; the `GlobKeyEvent` walk's FIRST matching `globtype` wins and the rest
  are silently shadowed. So a duplicate bind isn't "both fire" — it's "one wins, the others are dead" — but the
  panel happily SHOWS the same key on several rows, which is what the maintainer (rightly) disliked. **Not an
  addon bug** (addon binds are ordinary `KeyBinding`s). **Fix at the source, client-wide:** in `KeyBinding.set`,
  when a REAL key is assigned, loop `bindings` and unbind (`→ KeyMatch.nil`) every OTHER binding that fires on
  the same key (WoW-style exclusivity). The panel's `SetButton.draw` re-reads `cmd.key()` each frame, so a
  stolen row flips to `None` live — no panel change needed. **Gotchas:** (1) clear to `KeyMatch.nil`, NOT
  `set(null)` — `null` means "revert to default" (`key()` returns `defkey`), only `nil` truly unbinds; (2)
  compare against `other.key()` (effective = set-or-default), so assigning a key steals it even from a binding
  that only had it as its DEFAULT; (3) a captured key is code-based (`forevent`→`getExtendedKeyCode`) but the
  client's letter bindings are char-based (`forchar`), so normalise both to a keycode via
  `KeyEvent.getExtendedKeyCodeForChar` before comparing, else "Ctrl+G" as a letter vs a code wouldn't match;
  (4) compare `modmatch` so `J` and `Ctrl+J` stay distinct; (5) guard `key != null && key != KeyMatch.nil` so
  revert/disable don't steal, and `KeyBinding.get` (load) bypasses `set` so there's no load-time cascade.
  Headless-testable with an isolated `-Dhaven.prefspec` node (no UI needed — `KeyBinding.set`/`get`/`key` are
  pure prefs + `KeyMatch`). 9/9.
- **Widget-creation interception (3a) — the descriptor needs BOTH creation and placement.** A server widget's
  registered **type** string (`"inv"`, `"wnd"`, …) is known only at `UI.NewWidget.run` (the instance does **not**
  carry it — `gettype3(typenm)` resolves a `Factory` and discards the name), while **place**/**parentType**/
  **caption** only exist after `UI.AddWidget.run` places it. So D-024's `{id,type,place,caption,parentType}`
  descriptor can't be built from one seam: `NewWidget.run` records `id→typenm`, and `AddWidget.run` (right after
  `pwdg.addchild`) reads it back + adds place/parent — **firing at placement is the first complete moment**
  (refines api-reference's indicative "`UI.NewWidget` hook"). `AddWidget.run` runs on a **Loader thread but under
  `synchronized(ui)`** (the monitor tick/draw hold), so the observer's Lua is safe to call inline like an **L3
  message hook** — no `holdsLock` gate. **Seam choice:** adopt-after-create (**seam B**, `AddWidget.run`) is the
  default — it needs no tampering with the package-private `Widget.types` map and dodges the off-UI-thread
  `create()` caveat (learning above); the factory override (**seam A**) is only needed to *pre-empt* a type and
  can't touch resource-published `/`-names anyway. **`place` = `pargs[0]` only when it's a String** (an item added
  to an inventory has `pargs[0]` = a grid `Coord` → `place=nil`, and its `parentType` is the container, not
  `"GameUI"` — so filter HUD windows by `parentType=="GameUI"`). **`caption`** reads a `Window`'s own `cap`;
  bare widgets the engine wraps in a titled window (e.g. `Inventory` inside a `Hidewnd "Inventory"`) report
  `caption=nil` — identify those by `type`/`place`. Every widget placement passes the seam, so a **global-empty
  fast path** is essential (and `widgetTypes` records nothing unless an observer exists → bounded, cleared per
  session). Referencing `haven.Window` headlessly triggers its static `Tex` loads (needs GL) → test the
  `instanceof Window ? cap : null` branch via the descriptor builder with an explicit caption instead.

- **3b — model handle / adopt-by-id (`hafen.ui.adopt`).** **`UI.getwidget(id)`** is the public id→widget map both
  `uimsg` and `wdgmsg` route by, and it doubles as the **destroy signal**: when the server destroys a widget
  (`UI.DstWidget.run` → `destroy` → `removeid`), its id stops mapping to it, so a per-tick `getwidget(id) != wdg`
  test is a zero-core-edit `onDestroy` (also fires if the id is reused). **`Widget.hide()` keeps a server widget
  fully live** — it only sets `visible=false` + drops the parent's focusable entry; the widget stays a child, stays
  bound, keeps getting `uimsg`/`addchild` (D-009's headless model, confirmed by construction). So `:items()` + the
  add/remove poll work while hidden. **Item add/remove is NOT a `uimsg`** (it's a `WItem` create/`cdestroy`, exactly
  like buffs/study), so it must be **polled** and diffed identity-keyed — reuse the `BuffsAdapter` shape. **A bare
  `new haven.Widget(Coord)` IS constructible headless** (no GL), and `hide`/`show`/`visible`/`children(WItem.class)`
  all work on it — so the whole model-handle surface is headless-testable with a real Widget (unlike 3a's `Window`);
  only the `UI.getwidget`-backed paths (a live UI + server items) need in-game. **Un-hide-on-teardown timing:** guard
  the un-hide on the widget *still being the live server-bound one* (`getwidget(id)==wdg`) — because `init` sets
  `ui = ui_` (the NEW session) BEFORE the teardown loop, a relog's teardown correctly *skips* un-hide (old widget
  gone), while a same-session `:reload`/disable correctly *does* un-hide. **`children(Class)` is a DEEP traversal**
  (whole subtree, not just direct children) — fine for an `Inventory` (WItems are direct kids). **Scope boundary
  (important):** an item **verb** (`take`/`drop`/`transfer`/`use` → `GItem.wdgmsg`) is an **outbound gameplay
  action**, so it belongs to the **gated Phase-4 `hafen.act.*` tier** (D-010/D-025 + the Phase-4 queue's "item
  verbs"), NOT the read-tier model — even though spec 08's older sketch listed it on `model`. Rule of thumb going
  forward: **anything that emits a player `wdgmsg` is gated; reads/UI stay ungated.** The `hello` harness adopts via
  the onWidgetCreate observer, which **won't re-fire for the existing inventory after a `:reload`** (only creation
  fires it) → re-finding an already-open window is 3c's `replace`; don't store a widget id across relogs (ids are
  per-session, and a stale id could adopt the WRONG widget). **Harness gotcha (found in-game):** `onItemAdded`
  fires for the items ALREADY in the backpack as they stream in at login (like `BuffAdded` for pre-existing buffs)
  — ~12 of them — so a naive "log the first 5" cap is exhausted before the user can act, making a live pick-up
  look like it did nothing. The event was firing; the log was masked. Fix pattern for any poll-based lifecycle
  event: log the initial fill quietly, flip a `ready` flag a few seconds after enter-world, then log EVERY live
  change. (Also: hiding the grid does NOT stop the add — `children()` still sees the new `WItem` — which is the
  whole point, so the demo must survive the hidden state.)

- **3c — `hafen.ui.replace` = adopt+hide+view over 3a's dispatch, plus a SCAN for the already-open case.** The
  headline of 3c is the **two match paths**: (1) **creation** — fold the replacer check straight into 3a's
  `onWidgetPlaced` (right after the observers, same `synchronized(ui)`, same fast path — now gated on *both*
  `widgetObservers` and `widgetReplacers` being empty; `onWidgetCreated` records the type when *either* exists), so a
  target opened after registration is caught with the full descriptor; (2) **scan** — at `replace()` registration,
  sweep the live tree ONCE for an already-open match. The scan is what closes the `:reload` gap 3b flagged (a rebuilt
  addon layer gets no creation event for the existing inventory). **Zero new `haven` edit** — the whole slice rides
  3a's two `UI.java` one-liners.
- **The scan can't use the server type string — key on the Java class instead (3c).** `widgetTypes` records
  `id→typenm` only for **in-flight** creations (recorded at `NewWidget.run`, removed at `AddWidget.run`), so an
  *already-live* widget has no recorded type. The scan therefore maps the addon's `type` string → a Java class
  (`typeClass`: `inv`→`Inventory`, `epry`→`Equipory`, `chr`→`CharWnd`, `wnd`→`Window`) and walks
  `root.children(cls)` (a **`Set<T>`**, deep). This is a bridge-internal second lookup, NOT a second addon-facing
  way (D-013): the addon still passes ONE `type` string; the class map is an implementation detail of the scan. For
  `context="main"` skip the class-scan entirely and use the unambiguous public **`GameUI.maininv`** (a bare
  class-scan of `Inventory` would also return open *container* inventories — the ambiguity `context` resolves).
- **The main inventory's parent differs between the two paths — don't match on it in the scan (3c).** At **creation**
  the descriptor's `parentType` is the *server* parent (`GameUI`, `place="inv"`), but `GameUI.addchild` immediately
  re-parents the `Inventory` into a client-side `Hidewnd` (`invwnd`), so a **live** `maininv.parent` is `Hidewnd`,
  not `GameUI`. Hence `context="main"` is gated by `place=="inv" && parentType=="GameUI"` on the **creation** path
  only; the **scan** path targets `GameUI.maininv` directly (no place/parent recoverable for a live widget →
  `place=nil`). Keep the public `opts` to fields consistent across both paths (`context`/`caption`/`match`); expose
  `place`/`parentType` only inside the `match(desc)` predicate.
- **Replace hides the WRAPPER window, and must restore its ORIGINAL visibility, not blindly `show()` (3c).** `replace`
  hides `nativeWindowOf(wdg)` = the nearest enclosing `Window` (the *"Inventory"* `Hidewnd` around `maininv`), so the
  whole stock window disappears (the other 3b-deferred item), not just the grid. But that wrapper is
  **hidden-by-default** (the client only shows it on `Tab`), so teardown must **replay the captured
  `hideTargetOrigVisible`** (`false`→`hide()`), else disabling the addon would leave the native inventory *showing*.
  Generalised on `LuaModel`: a `hideTarget` (defaults to `wdg` → 3b `adopt` byte-for-byte unchanged; `replace`
  overrides it to the wrapper) + `hideTargetOrigVisible` captured in the ctor. `hide`/`show`/`visible`/`teardownModels`
  all route through `hideTarget`. Rule for any "hide the native UI" feature: **capture visibility before hiding,
  restore to that** — never assume the thing you hid was visible.
- **A live `:remove()` must UNDO, not just stop matching (3c).** For a toggle (the `bags` hotkey), the replace
  handle's `:remove()` restores the native window + destroys the view (`undoReplace` per active model), whereas
  teardown (reload/disable) reaches the same end via the existing `teardownModels` (restore) + `destroyWidgets`
  (destroy). Track the view as `LuaModel.replaceView` (the Lua handle `fn` returned) and destroy it by calling its
  own `:destroy()` (idempotent); a server-destroy in `pollModels` does the same (spec 08 "the view dies with the
  model"). The replacer holds an `active` list + a `handled` id-set so a re-scan/placement never double-fires.
- **`haven.Window` needs GL → the interesting `nativeWindowOf`/wrapper-hide branch is IN-GAME, but everything else
  is headless (3c).** A bare `new Widget(Coord)` builds headless (as 3b showed), so `nativeWindowOf(bareWidget)==self`
  and the whole hide-target/origVisible field logic test headless; the "finds the enclosing `Window`" branch and the
  live `getwidget`/`widgetid`-backed scan/`fireReplace` need a live UI. The **match logic is 100% headless** (pure,
  private-static → reflection): 36/36 including the `context="main"` container-inv rejection, caption, the `match`
  predicate in a real `Sandbox.create()` env, and the visible-grid vs hidden-default-wrapper origVisible capture.
  Same "headless proves the logic, in-game proves the UI wiring" split as every prior slice.
- **Ship the replacement demo as a DORMANT dedicated addon, like `hogtest` (3c).** A `bags` addon that
  auto-replaces the inventory on every login would (a) change the routine `hello`-regression login and (b) double up
  with `hello`'s 3b inventory adoption. So `bags` is **dormant behind a hotkey** (Ctrl+Shift+I toggles
  replace/restore) — routine logins are undisturbed, `hello` and `bags` coexist (both restore correctly), and the
  toggle exercises the **scan** path every press (the inventory is already open in-world). The toggle also gives the
  cleanest live DoD: press → replaced, press again → restored, or disable+`:reload` → restored. **Honest limit noted
  in the doc:** hiding the wrapper doesn't stop the client's own `Tab`/menu `togglewnd` from re-showing it (a full
  replace would intercept that binding too — later/Phase-4).
- **Markers (A1) — the map is a SEPARATE coordinate universe from the live gob world; the bridge is the minimap's
  `sessloc`.** `MCache` (the live terrain, session-local grid coords) and `MapFile` (the persistent on-disk DB,
  *segment* coords) are two different systems linked by the **stable grid id**. A marker stores `seg` (segment id,
  local) + `tc` (segment TILE coord), NOT world units. To move between them use the corner minimap's live
  **`sessloc`** (`MiniMap.Location` = a `Segment` + the segment-tile-coord of session tile 0,0, resolved each tick by
  `SessionLocator`): world→seg = `sessloc.tc + floor(world/tilesz)` (this IS what `MapWnd.MarkButton.FindMark.hit`
  does), seg→world = `(marker.tc − sessloc.tc)*tilesz + tilesz/2`. Both floor (negatives correct — same gotcha as
  1c-2). seg→world is only valid when `marker.seg == sessloc.seg.id` (a marker in another explored area has no world
  coord this session) — so a snapshot's `x,y`/`dist` are **session-local and optional**, while `seg`+`tc` are the
  **persistent anchor** (C4). Don't try to reverse a segment coord to a grid id via `Segment`'s internals (its
  `BMap<Coord,Long>` is private) — expose world `x,y` and let the addon call `hafen.map.gridPos(x,y)` for the
  shareable anchor (D-013, no duplication).
- **Locate the map DB with ZERO edit: `GameUI.mapfile.file` (or `.mmap.file`) — both public, same `MapFile`.** The
  big Map window (`GameUI.mapfile`, a `MapWnd`) and the corner minimap (`GameUI.mmap`, a `MiniMap`/`CornerMap`) are
  created together at login and share one `MapFile` (`public final` on both). Every marker member is public too
  (`MapFile.markers`/`markerseq`/`lock`/`add`/`remove`; `Marker.seg`/`tc`/`nm`; `PMarker.color`/`onmap`;
  `SMarker.res.name`), so the whole subsystem is read/written without touching `haven`. `MiniMap.sessloc`/`file` are
  public; `MiniMap.Location.seg`/`tc` and `Segment.id` are public. (NB: **classloading `MiniMap` headless fails** —
  its static `Resource.loadtex(...)` fields need GL — so `MiniMap.Location`/snapshot paths are in-game-only tests;
  the pure arithmetic + ref map ARE headless via plain `Coord`/`Coord2d`/`MapFile` [`new MapFile(null,"")` does no
  I/O; `PMarker`'s ctor is side-effect-free — no `markerseq` bump].)
- **`MapFile.markerseq` is the perfect poll signal — but disk-loaded markers don't bump it.** `markerseq` (volatile
  int) bumps on `add`/`remove`/`update` and on a **segment merge** (which mutates `mark.seg`/`tc` in place on a
  loader thread under the write lock — hence copy-under-read-lock before snapshotting). It does NOT bump on the live
  grid updates every tick (`MapFile.update(MCache,gc)` is a different path) — so it's a clean "markers changed"
  signal, not per-frame noise. BUT markers loaded from disk in `MapFile.load` are added to the list **directly**
  (no `add()`), so they DON'T bump `markerseq` → **prime** the poll (record the current seq the first time the DB is
  seen, fire only on subsequent changes) and let the initial set be read via `markers.list()`; the server's SMarkers
  (`markobj`) DO stream in via `add()` a beat after login, so those fire `MarkersChanged` normally.
- **Marker refs = a session-scoped `IdentityHashMap<Marker,Long>` + reverse map (the WidgetRef pattern for a
  non-id'd object).** Unlike gobs (a real `long` id) markers have no addon-visible id, and `(seg,tc,nm)` isn't
  unique/stable (merge shifts `tc`). So assign a monotonic `long` on first surface (facade-safe, P1 — no Java object
  to Lua) and resolve back for `remove`; clear it in `init()` (Marker identities are per-session — a relog rebuilds
  the `MapFile`). Guard the maps `synchronized` because `hafen.markers.list()` can be called from the off-thread
  `:lua` REPL as well as the UI thread.
- **A demo that WRITES to a shared persistent store must clean up after itself (A1).** `markers.add` writes the
  real on-disk map DB, so the `hello` regression harness (many logins) can't add on every login or it accumulates
  "Hello marker" pins forever. Pattern: gate the write behind a **hotkey toggle** (Ctrl+Shift+M adds/removes), track
  the ref in a file-body local, and **remove it in `OnDisable`** (teardown cleanup) so a relog/`:reload` with a pin
  still placed clears it. A normal login writes nothing. (Persistence-across-relog is then demoed via a `:lua
  hafen.markers.add(...)` one-off that skips the cleanup — documented.) Same "dormant, non-polluting demo" spirit as
  `hogtest`/`bags`, but for a *write* surface rather than a CPU/UI one.
- **`SkillWnd`'s three tabs don't share a shape (A4).** A `Skill` and a `Credo` each carry an internal `nm` token
  (so their name falls back to it while the resource tooltip is Loading), but an **`Experience` has NO name field** —
  its name is *purely* the resource tooltip, so it is nil until the resource resolves (omit the key, don't fabricate).
  Their groupings differ too: skills are `skg.csk`/`nsk` (known/buyable `Group.items`), credos are
  `credos.ccr`/`ncr` (acquired/available) **plus** a distinct *pursued* credo (`pcr` + loose `pcl…pqid` progress
  ints, not a list), and lore is `exps.seen.items`. → Exposed credos as **one composite** (`{acquired, available,
  pursuing, cost}`, like `char.food()`) rather than parallel functions, and the flat tabs (skills/lore) as arrays.
- **When a subsystem is "mostly from 1d", the leftover is a small read-only completion, not a re-do (A4).** The
  most-wanted trackers (curiosity slots, FEP) already had events in 1d; A4's remaining scope was just the static
  reference tabs (buyable skills, credos, lore) — reads change only on explicit player actions, so **no adapter/
  event** was warranted. Extracting the shared `resTipName`/`resIdent` (tooltip-name + identity, both Loading-guarded)
  from the 1d-3 `skillName`/`skillRes` made all three new reads one-liners and kept the Loading discipline uniform.
- **A2 radar = a WRITE surface onto an EXISTING client registry — "drive the settings window's model" not "build a new
  one".** `GobIcon.Settings` (`GameUI.iconconf`) already backs the in-client "Icon settings" window; our setters just
  do what its checkboxes do (`set.show/notify = v; conf.dsave()`), so the addon change shows up there and persists —
  and it's **zero `haven` edit** because every member is public. The write model is inherited wholesale: same UI
  thread, same benign race (the loader swaps `settings` wholesale; boolean flags are atomic), same debounced persist.
- **First mutator over the canonical filter — matched-count is the right return, and a `nil` filter = "all".** The
  read/list convention (`nil`=all / string=`name`-substring / predicate) generalises to mutation cleanly: `setVisible/
  setNotify(filter,on)` flip **every** match and return **#matched** (so the addon knows its filter hit something; a
  no-op re-apply still counts, only an actual flip triggers `dsave`). The predicate form is the res-matching escape
  hatch (the string form matches `name` only, per shared `matches`). `nil`=all is powerful (a "hide everything"
  toggle) — documented as such.
- **A persisting mutator must NOT run in the `hello` regression harness (it would corrupt the user's real config).**
  Unlike the `A1` marker demo (which cleans up its own pin on disable), radar's setters write the user's actual icon
  settings — no clean "undo marker" equivalent — so `hello` stays **read-only** and the mutation DoD is a documented
  `:lua` step the maintainer runs + reverts. Pattern: harness exercises **reads**; **persisting writes** are covered
  by the headless test + a manual console step.
- **Headless-testing a method that persists: subclass the collaborator with a no-op sink, don't fight the static.**
  `radarSetIn` calls `conf.dsave()` on change; `ResCache.global` is `static final` (can't null it) and the real
  `save()` would NPE on the synthetic sets' null `from`. Cleanest fix: `new GobIcon.Settings(null,name){ public void
  save(){} }` — `dsave()`→(defer)→`dsave0()`→`save()` dispatches to the override → **zero disk I/O, no NPE**. Also:
  factor the testable core (`radarSetIn(Settings,…)`) to take the collaborator directly so it needs no live `gui()`,
  and keep it **package-private** so a throwaway `io.brodgar.addon`-package test class can reach it (jshell's unnamed
  package can't see package-private members — a compiled same-package `main` can). Full classpath for such a run =
  `build/classes` + **all** `lib/**/*.jar` (`Resource`'s `<clinit>` pulls in `lib/jglob.jar`).
- **A `:lua`/`hafen.log` result rendered in-game is ONE text texture — clamp it, or a big result crashes the GPU.**
  `A2 categories()` (~400 entries → ~40 KB single-line compact JSON, no spaces = no wrap points) made the REPL's
  `UI.msg(result)` build a text texture wider than `GL_MAX_TEXTURE_SIZE` → `GL_INVALID_VALUE (1281)` on the render
  thread → client crash. The **read was correct** (full result fine on the terminal) — it's a pre-existing REPL
  limit that the first ~40 KB read exposed. Fix once at the choke point: `clampMsg` bounds every string handed to the
  in-game notice sink (`UI.msg`/`error`) to ~500 chars; stdout keeps the full text and addons still get the real Lua
  value. **Takeaway for future reads that can return large collections:** the data path is fine (Lua/terminal handle
  size), but the in-game notice render is texture-bounded — never `UI.msg` an unbounded string.
- **A client-global registry with no unregister (`Console.setscmd`) → NEVER re-register it per reload; install a
  single engine-lifetime DISPATCHER that routes to current addon state.** (A11 / coverage-gaps C1.) The naïve
  `hafen.slash` would call `Console.setscmd(name, handler)` on every reload → leaked/duplicate commands pointing at
  torn-down handlers. Fix: the first registration of a name installs ONE `Console` command that reads
  `slashHandlers.get(name)` at dispatch time; reload/disable only swaps/drops that map entry (a `slashDispatched`
  set records which names are dispatched and GROWS ONLY — deliberately *not* reset in `init()`, unlike the
  session-scoped hook maps which ARE reset). A dropped name's dispatcher stays and replies "no addon handles it".
  This is the general pattern for **any** engine-lifetime global the bridge writes but can't un-write (registries,
  static maps): *register a stable indirection once, keep the live state in a bridge-owned map, swap the map.*
- **`Console` command dispatch is on the UI thread in-game (input handling), so it can't race the tick.** The `:`
  console reaches `Console.run` via `ConsoleHost.done` (a `ReadLine.Owner` keyboard callback) → UI thread, the same
  thread as the tick/draw — so a slash handler running Lua synchronously never races other Lua (no marshalling
  needed), exactly like the `:lua` REPL. Only a **terminal stdin** build (`Chatwindow`/`HeadlessClient`) dispatches
  off a reader thread; the REPL already accepts that trust/threading profile, so slash inherits it rather than
  inventing a defer.
- **`Console.findcmd(name)` (via the live `ui.cons`) is the collision check** for a would-be new command — it
  resolves the merged static+instance+dir command maps. Guard it (`ui`/`cons` may be null pre-HUD; wrap in
  try/catch) and only run it on the FIRST registration of a name (once our dispatcher is installed, `findcmd` would
  return *it*). Reserved engine names (`lua`/`addons`/`reload`) are also refused explicitly since they share the
  same static `scommands` map and would be silently clobbered by `setscmd`.
- **Kin/buddy (A6) — a widget's own `serial`/dirty counter can UNDER-report; diff a snapshot instead.**
  `BuddyWnd` looked like the easy "poll `serial`" case, but `serial` bumps on `add`/`rm`/`upd` and **NOT on
  `chst`** (the online/offline flip) — the single event a kin-alert addon most wants. So change-detection is a
  **snapshot diff** (id/name/group/online per entry), never the widget's counter. General takeaway: before
  trusting an engine-side change token, check *which* mutations bump it — if any state you expose changes without
  bumping it, diff your own snapshot. (Here the diff is order-sensitive, which is correct: `BuddyWnd` only
  re-sorts on `add`, so any reorder is driven by a real field change worth reporting.)
- **A6 is uimsg-driven, not polled — the opposite of buffs/study, because buddy changes ARE uimsgs.** Buffs/study
  poll because their add/remove is a widget create/`cdestroy` invisible to the 1d-1 inbound-`uimsg` tap. But
  every `BuddyWnd` roster change (`add`/`rm`/`upd`/`chst`) is a targeted `uimsg`, so a `TreeAdapter` whose
  `interested` flags those four msgs + a `refresh` that diffs is strictly better: **zero per-tick work when the
  roster is idle** (the common case). Pick the adapter path (uimsg vs poll) by asking "is the change I care about
  actually delivered as a `uimsg` to this widget?" — for structural widget create/destroy the answer is no (poll);
  for server field updates it's yes (uimsg-driven).
- **Tri-state → boolean is a legitimate "one canonical way" call (A6).** `Buddy.online` is `1`/`0`/`-1`
  (online / offline / hearth-secret-only). Exposing the raw int would be faithful but forces every addon to learn
  the encoding; exposing `online == 1` as a **bool** answers the 95% question ("is this kin online") cleanly. When
  a low-value distinction (the `-1` state, `Buddy.seen`/`notes`) would complicate the common path, expose the
  ergonomic form and **document the deferred nuance** rather than leaking the internal encoding.
- **Some read surfaces have almost no logic — the headless test then verifies null-safety + wiring, and the
  live value is an in-game check (A7).** A7 speed is `Speedget.cur`/`max` (two public ints) located via the
  Locator — the read itself is trivial, so the 8 headless checks target what CAN fail: the locator returning
  `null` with no HUD (no NPE), the facade table + functions installed, each returning `nil` with no HUD. The
  actual 0..3 value needs a live `Speedget`, verified in-game — same as every widget-tree read ultimately is.
  Don't manufacture a fake change-detection helper just to inflate the check count; test the real failure modes
  (null-safety, wiring) and lean on the in-game DoD for the live value.
- **A widget's `.class` literal / `isInstance`/`cast` do NOT trigger its static init, but reading a static
  FIELD does — and that can pull in resource loading unavailable headless (A7).** `gui().children(Speedget.class)`
  and the `cl.isInstance(n)`/`cl.cast(n)` inside it never run `Speedget`'s static block (JLS 12.4.1: class
  literals don't initialise), so the Locator is headless-safe. But `speedName()` reads `Speedget.tips`, a
  `static final String[]` populated by `Resource.local().loadwait(...)` at class-init — the first access forces
  the block and needs the client resource loader (`dolda/jglob/Loader`, absent under bare `jshell`). Practical
  rule: locating a widget by `.class` is always headless-testable; reading its static resource-backed tables is
  an **in-game** check. Keep the bounds-check that guards such a field read cheap and correct (verified in-game).

- **A8 — widget lists: check swap-vs-mutate before copying, and "copy under `ui`, snapshot outside".** When a
  read walks a widget's `List` fields, don't assume they're all the same to copy. In `Makewindow`, `inputs`/
  `outputs`/`qmod` are **reassigned wholesale** by their uimsgs (`this.inputs = wdgs`) — grabbing the reference
  is race-free (no `ConcurrentModificationException`, worst case a one-frame-stale snapshot). But `tools` is
  mutated **in place** (`tools.add(...)` on the `"tool"` uimsg), so `new ArrayList<>(mw.tools)` **can** CME. All
  those uimsgs run on a Loader thread **under `synchronized(ui)`**, so the safe, uniform fix is to copy **all**
  the lists inside one `synchronized(ui)` block, then build the Lua snapshots **outside** it (resolving resource
  names via `res.get()`, which may `Loading`, must NOT hold the lock) — the same "copy under the lock, snapshot
  outside" discipline the A1 marker read uses with `file.lock`. The static `ui` monitor is reentrant (the addon
  tick / in-game REPL already hold it) and only briefly acquired off the stdin REPL thread → no deadlock.
- **A8 — headless can't build a `haven` widget that renders text (extends the A7 note).** A7 found the Locator
  itself is headless-safe. A8 needed to test the *snapshot* of a `Makewindow.Spec` (an inner class), but merely
  referencing `haven.Makewindow` runs its `<clinit>`, which calls `Text.render("Quality:")` → the `ui/fraktur`
  font resource, absent under bare `jshell` (there is **no `res/` dir on disk** — resources come from a jar /
  the server at runtime), so it throws `NoSuchResourceException` before any test code runs. So: **pure data
  helpers** (here `craftRes`/`craftReses`, which take a stub `Indir<Resource>`) are headless-testable — fabricate
  a `Resource` via `Unsafe.allocateInstance` + reflect-set its `name` (needs `lib/jglob.jar` on the classpath,
  or `Resource.<clinit>` fails on `dolda/jglob/Loader`); but any helper that must be fed a **real widget-built
  object** is a documented **in-game / resource skip** (like 3a's Window-caption skip). Split the production code
  so the data-shaping is a plain-object function (A8's `craftSpec(Spec)` instead of `craftSpec(SpecWidget)`) to
  maximise what's testable without a live UI.
- **A9-1 — extract the change-detection DECISION into a pure function, and it becomes headless-testable
  (extends the A8 split to stateful adapters).** A per-item event adapter (`QuestAdded`/`QuestDone`) has two
  parts: *reading the widget* (needs a live UI) and *deciding what changed* (pure). Keeping them fused (the A6
  `KinAdapter` style — read + diff + fire in `refresh()`) leaves the interesting logic — "new **active** quest →
  Added, active→finished → Done, already-finished-at-login → **silent**, removed → prune" — untestable without a
  live `QuestWnd`. Splitting the decision into `questDiff(cache, fresh)` (both `Map<Integer,Integer>` of
  id→status **in**, `{event,id}` pairs **out**, cache mutated) let 13 of 26 checks nail the exact semantics
  headlessly; `refresh()` shrinks to read-the-lists → call `questDiff` → map id→snapshot → `fire`. Same spirit
  as A8's `craftSpec(Spec)`, but for a **stateful** cache diff rather than a stateless snapshot. When an adapter
  fires per-item deltas, make the delta computation a pure map→events function.
- **A9-1 — `public static final int` constants are inlined (JLS 13.1), so a status-mapping helper is
  headless-safe even when its enclosing class's `<clinit>` renders text.** This is the A7/A8 "touching a
  resource-backed class blows up headless" note, but turned to advantage: `QuestWnd.Quest` has a font-rendering
  static block (`catf.render("Quest completed").tex()`), yet `questStatus`/`questActive` reference only
  `Quest.QST_PEND`/`DONE`/`FAIL`/`DISABLED` — compile-time constants folded into the caller's bytecode as
  literals, so invoking them **never loads `Quest`**. The A8 `craftSpec` skip was forced because it needed a
  built `Spec` *object*; here the status codes are constants, so the mapping is fully testable. Rule of thumb:
  a helper that reads only a class's `static final` primitive/String constants doesn't trigger that class's init;
  one that reads a non-constant static field, or takes an instance, does.
- **A9-2 — a content-published number can still be read faithfully when the CLIENT defines the marker
  interface.** A8/A7 warned that touching a *content* resource class blows up headless. But a wound's severity
  is not an opaque content class — it's whatever `ItemInfo` in `Wound.info()` implements **`WoundWnd.QuickInfo`**,
  a `public` interface **the client declares**. So the bridge finds it exactly as the client's own
  `WoundList.Item.getqdat` does — iterate `info()`, keep the highest-`qprio` `instanceof WoundWnd.QuickInfo`, call
  `qstr()` — reaching a content-defined value through a client-owned seam (like `Buff.AMeterInfo`/`GItem.NumberInfo`
  in 1d-2). The rule: when the engine names an interface/class for a content-published datum, read through that
  name (`instanceof` + the public accessor), don't reach into the resource. `qstr()` is a **display String**
  (usually a number) → expose it verbatim, `NOT seconds`, `tonumber()` on the addon side — the 1d-2 buff-amount /
  A8 craft-spec faithfulness rule.
- **A9-2 — two ORTHOGONAL adapter decisions: the event SHAPE (single `*Changed` vs an Added/Done split) and the
  TRIGGER (uimsg vs poll). Pick each on its own axis.** *Shape:* quests have a directional lifecycle
  (active→finished) the api-reference wanted surfaced as `QuestAdded`/`QuestDone`, so A9-1 built a stateful
  `questDiff`. Wounds are a set with magnitudes and no canonical "direction" (a wound worsens, heals, spawns a
  complication), and the contract names a single **`WoundChanged`** — so a `KinChanged`-style whole-list payload +
  a pure `woundListEqual` diff is the honest model (put the changing magnitude, `severity`, IN the equality key so
  "got worse" counts). *Trigger:* A6 kin and A9-1 quests are **uimsg-driven** because their key data (online flag,
  quest status) lands whole in the uimsg; A9-2 wounds are **poll-driven** (the 1d-3 study shape) because the key
  datum — `severity` — is resource-derived and **streams in a beat after** the `"wounds"` uimsg, so a uimsg-timed
  refresh reads it as nil and never re-fires. Don't assume "model on X" fixes the mechanism: the same event shape
  (KinChanged) can need a different trigger (poll) when the payload's key field resolves asynchronously.
- **A9-2 — some subsystems are a TREE, not a flat list (`Wound.parentid`/`level`).** Wounds nest (a complication
  under a wound); the client keeps it flat in `WoundList.wounds` but renders a tree via `parentid` (-1 = root) +
  a `treesort`-computed `level`. Expose both raw fields on the snapshot (authoritative `parentid` + convenience
  `level`) so an addon can rebuild the same indentation the panel shows, rather than flattening the structure away.
- **A10 — one server widget can hold several ORTHOGONAL data structures → several focused reads, not one blob.**
  `FightWnd` bundles a palette (`acts`), a keyed layout (`order[]` + `keys[]`), and saved-slot scalars
  (`maxact`/`usesave`/`nsave`). A8 craft used a single `current()` blob because a recipe is one transient unit; a
  persistent char-sheet tab whose parts answer different questions ("what do I know" vs "what's on which hotkey" vs
  "which school is active") reads cleaner as **`maneuvers()`/`deck()`/`summary()`** (the A9 quests `list()`/
  `selected()` precedent). These are distinct PROJECTIONS of the same widget, not two ways to do one thing — so
  "one canonical way" is preserved; `Action.u` legitimately appears in both `maneuvers` (palette) and `deck`
  (layout). Choose the decomposition from whether the widget is one unit (blob) or several sub-structures (focused
  reads), and from whether it's transient (craft `current()`) or persistent (char-sheet tabs → per-concern reads).
- **A10 — expose the RAW engine index the write path will consume, even in a read-only slice.** The deck slot is
  `order[]`'s 0-based index — the same index a future gated `fight.use(slot)` sends, and the same 1d-4 rule for the
  action bar (raw 0..143, not 1-based Lua). Surfacing `slot` now (alongside the human `key` label) means the
  Phase-4 action verb takes exactly what the read handed out — no re-derivation, no 0-vs-1 mismatch — the "one
  canonical index" discipline paying forward from read to action.
- **A10 — zero-edit vs a one-line accessor is a JUDGEMENT CALL; default to the tradition, defer the extra.** School
  NAMES sit in the private `FightWnd.saves[]` — a trivial `AddonWidgets` accessor away (the 1d-1 vitals pattern),
  and D-011 permits it. But the whole A-series (A2/A4/A6/A7/A8/A9) has been proudly **zero-`haven`-edit**, and the
  names are a nicety (the headline is the deck + maneuvers; switching schools is Phase-4 gated anyway). So expose
  what's public (`usesave`/`nsave` identify the active slot by index) and **defer** the private field with a clear
  note, keeping the slice tight for one in-game verification. Invasiveness is allowed, not obligatory — reach for a
  core edit when it unlocks the HEADLINE feature (1d-1 vitals had no zero-edit path), not a garnish.
- **A10 — headless-testable surface shrinks when a read has no pure transform + its class won't `<clinit>`
  headless.** A read-only, event-less subsystem has no change-detection function (the bulk of A6/A9's headless
  checks) — only null-safety + any pure helper. Here even the pure helper (`deckKey`) is untestable headless
  because touching `FightWnd` at all triggers `Text.<clinit>` → `/res/ui/fraktur.res` (the A8 skip). So the honest
  headless count is small (**4**: the facade wiring + null-guards, which DON'T reference the un-initable class on
  the no-session path); don't pad it — state the resource skip explicitly and lean on in-game + source inspection
  for the literal-backed mapping. The value of the headless pass here is proving the guards return empty/nil
  without an NPE, which it does.
- **4a — the ENGINE already shows the canonical encoding for a "programmatic" action; find it before inventing one.**
  The one hard question for `moveTo` was the screen coord `pc` — a real click gets it from a GPU hit-test we can't
  do for an off-screen world coord. Grepping `wdgmsg("click"` across `src/` (not just `MapView`) surfaced
  **`MiniMap.mvclick`** (MiniMap.java:1218): the engine walks-by-minimap-click by passing the **current mouse pos
  as a dummy `pc`** and the real destination as the world arg. That resolved the whole design (dummy `pc`,
  off-screen dest is fine, server uses the world coord) with zero guesswork. **Lesson:** for any action verb, the
  client almost always contains a non-mouse caller of the same `wdgmsg` (minimap, party view, fightview, avaview
  all call `"click"`) — that caller IS the spec for the args. Search the whole tree, mirror it.
- **4a — don't read a persisted pref you have no UI to CLEAR yet; a sticky pref + no toggle = a stranded switch.**
  First cut made the master switch `getprefb("addons/actions", CFG.get())` — pref is state, config is default.
  Clean on paper, but: the *earlier* in-game test (the since-removed `:addons actions on`) had **persisted the pref
  = true**, and after the redesign there was **no in-client toggle left** (console command gone, panel is 4b). So
  the maintainer booted to "GRANTED" with **no way to turn it off** — the config default was moot. Fix: for 4a the
  master switch reads the **config flag ONLY** (`actionsEnabled()` = `CFG_ACTIONS.get()`, default false); the
  persisted, panel-toggled pref returns in **4b** alongside the UI that manages it. **Lesson:** a persisted
  override is only safe to *read* once there's a way to *write/clear* it. Stage the state source with the control:
  config flag while the control is a config edit; a pref once the panel exists. (Watch for stale state a prior
  version's control left behind — it outlives the code that set it.)
- **4a — a gated namespace should be PRESENT with gated verbs, not absent.** Building `hafen.act` always (with
  `enabled()` never-throwing + each verb calling `requireActions`) beats hiding the table when off: an addon can
  feature-detect without `pcall`, and a not-granted call yields a guiding error (how to grant it) instead of a
  `nil`-index crash. The spec's "engine can ship the API absent or disabled" allows either; present+gated is the
  better UX for a single runtime-toggled build. Verifiable end-to-end headless: build the real facade (via the
  private `console()` env / a hand-built `Addon` by reflection), flip the master pref + vary the owner's
  declaration, assert the verb throws the right distinct error / passes to "no map view" — provable without a live
  session.
- **4a/D-027 — reads and writes are the SAME API surface; the only difference is a declared PERMISSION, not a
  separate control surface.** My first cut bolted the opt-in onto the `:addons actions on|off` **console command**
  — which read like "an addon named actions" and split writes off from the uniform `hafen.*` API. The maintainer's
  correction reframed it cleanly: `hafen.act.*` is plain API like `hafen.gob.*`; what gates it is a **permission**,
  modelled like app permissions — (1) a global master switch the USER controls (never the addon — else a hostile
  addon self-grants and the opt-in is moot) + (2) a per-addon **manifest declaration** the AUTHOR makes, so
  the client can warn *before* running it. `requireActions(owner, verb)` checks declaration FIRST (author's bug →
  clearest message) then the switch (user's setting). **Lesson:** when a capability needs an opt-in, don't invent a
  command verb for it — model it as a *permission* (declared + authorized) and keep the capability itself in the
  normal API. Also: the manifest permission is an **array** from day one (`["actions"]`) so future categories
  (`"actions.move"`) don't force a format migration — cheap future-proofing when a field is clearly going to grow.
- **4a — headless test isolation: `-Dhaven.prefspec` for prefs, `lib/jglob.jar` on the CP for `OCache.<clinit>`.**
  Testing the gate touches real client prefs → set `System.setProperty("haven.prefspec", "…test…")` FIRST (before
  the first `Utils.prefs()`), then `prefs().remove(key)` for a clean default — real prefs untouched (the 1f-2
  trick). And `moveClickCoord` references `OCache.posres`, whose `<clinit>` scans annotated classes via
  `dolda.jglob.Loader` → add **`lib/jglob.jar`** to the jshell classpath or the class won't initialize (a subtler
  cousin of the A8/A10 font-resource `<clinit>` skip — here the fix is a jar, not a skip). `--execution local`
  ignores jshell's `-R-D…`; set system props inside the script instead.
- **4b — the always-on regression HARNESS cannot be a WRITE addon (the deep D-027 consequence).** 4a had `hello`
  declare `"actions"` to demo `moveTo`. But 4b's "master switch OFF ⇒ write-declaring addons don't load" rule,
  combined with the switch defaulting OFF, means a write `hello` **vanishes on a default login** — taking the
  ENTIRE regression suite with it. There is no clean exemption (the spec mandates unloading). So the harness must
  be **read-only** (`hello` v0.33.0: dropped `permissions`, removed the `hafen.act` demo → always loads regardless
  of the switch), and the write demo moved to a **separate, dormant, opt-in `walker` addon** (declares `"actions"`
  → default-disabled). This is architecturally right, not a workaround: *modding* (reads/UI/events) is always-on;
  *driving the character* (writes) is a gated, opt-in surface — so the thing that must always run can't be the
  thing that's gated off by default. Same "dormant dedicated demo" spirit as `hogtest` (CPU) / `bags` (replace).
  A bonus: `walker` only ever loads when the switch is on AND it declared the permission, so `hafen.act.enabled()`
  is **always true inside it** — a clean invariant for the write demo.
- **4b — the "seen set": apply a one-time default with a grows-only persisted set, keyed on the TRAIT that
  triggers it.** D-027 default-disables a *newly-discovered* write addon but must not fight the user who then
  enables it. The seen set (`addons/actions.seen`) records write-addon ids we've already defaulted: a write addon
  NOT in it → add to BOTH the disabled set and the seen set (default it once); a write addon already in it → leave
  to the user's choice; read addons ignored entirely. Key on **write-ness, not all ids** — so a read addon that
  LATER adds `"permissions":["actions"]` is treated as newly-declaring and re-opted-out (safer than grandfathering
  it in). The set only ever GROWS in `applyActionsDefaults` (additions-only), which makes change-detection a
  trivial size compare (`if(seen.size() != before) persist`) — same "register a stable indirection, keep live
  state in a bridge-owned set" shape as A11's slash `slashDispatched`. **No first-run grandfather was needed**:
  making `hello` read-only left ZERO pre-existing write addons, so the only default-disable is the genuinely-new
  `walker` — exactly the desired behavior, for free. (Grandfathering would only matter to protect an *existing
  enabled* write addon from retro-disable; there was none.)
- **4b — a persisted override pref is only safe to READ once its control UI exists (the 4a→4b closure).** 4a
  deliberately read the config flag ONLY (`CFG_ACTIONS.get()`), because a stray persisted pref could strand the
  switch ON with no toggle — it had, from an even-earlier `:addons actions on` experiment. 4b adds the panel
  checkbox (the toggle), so `actionsEnabled()` = `Utils.getprefb("addons/actions.enabled", CFG_ACTIONS.get())`
  (pref over config-default) is now safe. Used a **FRESH pref key** (`addons/actions.enabled`, not the 4a-era
  `addons/actions`) so any stale value from that experiment is ignored → a clean default-OFF first boot. General
  rule (already in §8 from 4a, now applied): stage the STATE SOURCE with the CONTROL — config flag while the
  control is a config edit; a persisted pref once the panel exists.
- **4b — split the master switch's two effects: the GATE is immediate, LOADING is apply-on-reload.**
  `actionsEnabled()` reads the pref live, so `requireActions` (the per-verb gate) sees a toggle immediately —
  toggling OFF makes any already-loaded write verb fail-closed at once (good: actions should stop the instant you
  say so). But LOADING a write addon follows the D-006 apply-on-reload model (`setActionsEnabled` only flags
  `reloadNeeded`; `loadAll` gates on the switch). Both are correct and intentional: the gate is safety (immediate),
  the load/unload is lifecycle (batched to reload, like the enabled set). Document the immediate-gate half so an
  author isn't surprised a granted verb starts throwing mid-session when the user flips the switch.
- **4b — headless-test the PURE policy + the pref round-trip, not the disk I/O (the A9-1 split, again).**
  `scanAddonDefaults()` does the disk/prefs I/O (read manifests → build a `Map<id,declaresActions>`, read/write the
  seen + disabled prefs); the DECISION is the pure `applyActionsDefaults(seen, disabled, declares)` (in-place set
  mutation, returns the write-id set) — so 7 checks nail the exact policy (read-ignored / new→disabled+seen /
  user-enabled-not-re-disabled / additions-only / `writeIds`=all) with no game or disk. The master switch is
  testable against an isolated `-Dhaven.prefspec` node (the 1f-2/4a trick): `setActionsEnabled`/`actionsEnabled`
  round-trip + idempotency, reading the private `reloadNeeded` via reflection (the public `reloadNeeded()` getter
  also works). `AddonManager.<clinit>` is headless-safe with `build/classes` + all `lib/**/*.jar` on the CP (its
  static block only registers `Console.setscmd` handlers; `CFG_ACTIONS`'s `Config.Variable.propb` is lazy). 12/12.
- **4c — a floating dialog must be a `ui.root` child; parenting it to the panel clips it (maintainer feedback).**
  I first parented the consent to the **panel** for free lifecycle (a child of a `hide()`-den panel is neither
  drawn nor clickable — `TickEvent`/pointer propagation — and cascades on destroy). But a panel-child window drags
  in the panel's coord space and **visibly runs outside the AddOns window** — it doesn't behave like a normal
  floating window. Fix: add it to **`ui.root`** (`ui.root.adda(dlg, ui.root.sz.div(2), 0.5, 0.5)` + `dlg.raise()`)
  so it drags freely and sits on top. The lifecycle you gave up (auto-hide/destroy) comes back cheaply from the
  **panel's `tick`**: `if(consent != null && consent.parent != null && !tvisible()) consent.destroy();`. That runs
  even while the panel is hidden — `TickEvent.propagation` ticks the whole tree regardless of `visible` (the
  `AddonRoot`-pump fact), and `OptWnd` is only **hidden**, never destroyed, on close (`GameUI.togglewnd` →
  `wnd.show(!visible())`). Lesson: don't trade the RIGHT window semantics for cheap bookkeeping — top-level is
  correct for a floating dialog; a one-line tick guard is the small price.
- **4c — a client-side `Window` has no server: redirect `reqclose` to `destroy`, and destroying from a button's
  own `action` is safe.** `Window`'s default `reqclose` sends `wdgmsg("close")` (there's no server for an addon-
  built window — the 2a lesson), so the ✕ does nothing unless you `reqclose(this::destroy)`. And a button whose
  `action` destroys its own window is safe: `Button.mouseup` does `d.remove(); redraw();` **then** `click()` last,
  so nothing touches the button after the handler returns (order verified in `haven.Button`).
- **4c — gate the SILENT bypass too, not just the obvious path.** The headline was "consent dialog on the enable
  checkbox", but the same gate has a back door: **`enableAll`** would flip every addon's enabled bit with no
  prompt. A per-addon permission that a "select all" can grant silently isn't a permission. So `enableAll` **skips
  write addons** (`if(!ai.declaresActions)`). When you add a consent/permission step, grep for every other path
  that reaches the same state change (bulk actions, console commands, import) and gate or exclude them too.
- **4c — encoding: this project compiles source as UTF-8, so non-ASCII string literals are fine.** `build.xml`'s
  `<javac>` sets no `encoding`, so it uses the JDK default charset — which is **UTF-8** on Java 18+ (JEP 400),
  and this client runs on Java 23. Proof it's relied on already: the whole `io.brodgar` tree has non-ASCII bytes
  (AddonManager alone ~1.2 KB), and `AddonPanel`'s 4b tooltip literal already renders an em-dash (`—`) in-game
  (4b verified). So curly quotes `“ ”` / `—` in a *rendered* literal are safe (`Text.std` covers General
  Punctuation) — no need to ASCII-fold. (Still worth a glance if a future contributor builds with an older JDK.)
- **D-028 — a redundant control is worse than none: the per-addon consent SUBSUMES the global switch.** 4b shipped
  a two-part gate (global master switch × per-addon declaration+enable). Once 4c made *enabling* a write addon a
  knowing, consent-gated act, the global switch added friction without adding control — every state it could
  express was already reachable per addon. Maintainer call: drop it. The lesson is to re-examine earlier gates
  after a later one lands; "defense in depth" that duplicates an existing decision point is just a second thing to
  toggle. Net: **enable-with-consent = grant** is the ONE canonical control (D-001 "one way").
- **D-028 — reverting a CLOSED maintainer decision is legitimate, but treat it as a first-class decision.** D-027
  explicitly chose the master switch; removing it isn't a silent code tweak. Path that kept the project coherent:
  a NEW decision (**D-028**) that records what/why + marks D-027 "refined", update the specs it cited (12/10/
  api-reference), and add **superseded-in-part notes** at the TOP of the affected `docs/addons/` files (4a/4b) —
  don't rewrite history, flag it and point forward. When unsure how far the change reached, `grep` the removed
  symbols across `src/`+`addons/`+`docs/` (`actionsEnabled`, "master switch", "Allow addon actions", …) and fix
  every hit, including addon comments/manifests and the demo (`walker`) that narrated the old model.
- **D-028 — "add ONE task then stop" doesn't cover a maintainer redesign mid-queue.** This came in as a direct
  request ("quiero quitar lo del enable global"), not a `/next` task. When the ask has a genuine design fork
  (here: is enable-with-consent the grant, or a separate persisted grant?), a single focused `AskUserQuestion`
  before the refactor beats guessing — the answer ("habilitar = conceder") set the whole shape.
- **4d — read the ENGINE's own send site, don't invent the wdgmsg shape.** Every action verb mirrors an exact
  `MapView` gesture; the arg arrays came straight from `Click.hit`/`iteminteract`/the place branch of `mousedown`/
  `Selector.mmouseup` + `Gob.GobClick.clickargs` — NOT from the api-reference table alone (which abbreviates). Two
  encodings would have been wrong from the table: `place`'s angle is `round(angle*32768/PI)` (not raw radians), and
  `"sel"` takes **TILE** coords (`mc.round().div(tilesz2)` in the Selector), not world. Factor each verb into a PURE
  arg-array builder (`clickGobArgs`/`placeArgs`/`selArgs`, taking the dummy `pc` as a param) + a thin sender that
  grabs the live `MapView` — the builders are then headless-testable and the senders stay a 3-liner, exactly like
  4a's `moveClickCoord`/`actMoveTo`.
- **4d — a gob click needs no render hit-test: synthesize `Gob.GobClick.clickargs` directly.** The engine builds a
  gob click's tail (`{0, gobid, gob.rc.floor(posres), 0, -1}`) from a live `ClickData`, but for a PROGRAMMATIC click
  you already know the gob — just emit that array from `(id, rc)`. Mesh id `-1` = "bare click", faithful for world
  objects (which use `Gob.GobClick`); a composite player/animal's specific body part would need the `Composited.
  CompositeClick` computed id (deferred). `mc` (the click's world point) = the gob's own floored `rc`.
- **4d — `optint(default)` is the clean way to do optional trailing Lua args.** `a.arg(3).optint(0)` returns the
  default for an ABSENT/nil arg and validates type for a present one (a string arg → a clear LuaJ "bad argument"
  error) — no `narg()` juggling. But **`isstring()` returns true for NUMBERS** in LuaJ (Lua coerces number→string),
  so a "must be a string" guard on a wdgmsg name only catches nil/table/bool, not a stray number — test the guard
  with a **nil** arg, not a number.
- **4d (tooling) — jshell hangs waiting on stdin after running a `.jsh` file; redirect `</dev/null`.** A script-file
  run drops into the interactive REPL at EOF and blocks on stdin (a 2-min timeout). Piping `</dev/null` makes it exit
  cleanly. `--execution local` is NOT a fix — it breaks classpath class-resolution (`Could not resolve class …`); keep
  the default forked VM. Headless facade tests need `lib/jglob.jar` on the `-cp` too (`OCache.<clinit>` →
  `dolda.jglob.Loader`), else `moveClickCoord` and friends throw `NoClassDefFoundError` before touching `posres`.
- **4e — VERIFY the sandbox's Lua surface by RUNNING in a real `Sandbox.create()`, don't trust the whitelist doc.**
  `Sandbox.java`'s class-doc lists `unpack` among the whitelisted base fns, but LuaJ 3.0.1 is **Lua 5.2** — there is
  **no global `unpack`**, only `table.unpack` (the `walker` menu demo first used `unpack(path)` and hit `attempt to
  call nil`). Fixed by `table.unpack`. Lesson: an addon's stdlib assumptions must be checked against the *actual*
  sandboxed `Globals` (a 5-line runtime test loading a chunk that calls the fn), because the sandbox is a curated,
  5.2-flavoured subset — not the 5.1 globals many Lua snippets assume. (Stale-doc note: the `unpack` mention in
  `Sandbox`'s Javadoc is aspirational.)
- **4e — for an ACTION that commits a choice, match EXACTLY (case-insensitive); save substring for READS.**
  `flower(label)` matches a petal by exact ci-name, unlike the read-side `buffs.has`/`items.find` substring. A loose
  match on a *write* could select the wrong menu item (irreversible) — so the canonical rule flips by tier: reads are
  forgiving, actions are precise. (And an action that "does nothing to pick" returns `false`, doesn't throw — reserve
  throws for the permission gate + type errors, so callers needn't `pcall` the normal empty case.)
- **4e — wrap-not-reimplement (D-009) beats re-sending the wire message: call the engine's own method.** `flower` calls
  `FlowerMenu.choose(petal)` rather than re-encoding `wdgmsg("cl", num)` — so a **client-side** petal (the voice
  Mute/Unmute the fork injects in `FlowerMenu.choose`) is handled locally instead of being wrongly sent to the server.
  When the engine already has the exact public method the gesture uses, drive THAT; you inherit its special cases for free.
- **4e — some UI surfaces GRAB input, so the "obvious" trigger can't reach them; the verb is then inherently for
  automation.** An open `FlowerMenu` grabs mouse+keyboard (`ui.grabmouse`/`grabkeys` in `added()`), so you cannot
  type a `:cmd` or press a hotkey to pick a petal by hand while it's up. `flower`'s real use is a **timer/event**
  chain (right-click → wait → pick) — the tick pump keeps running under the grab. Shape the demo around how the
  feature is actually usable, not around a trigger the grab blocks.
- **4f — the "item handle" the spec wanted (D-022) was already sitting there: a server item IS a bound widget.**
  A `GItem` is `@RName("item")`, created by the server and `bind`-ed with an id in `NewWidget.run` (the same seam
  3a taps); the visible `WItem` is only a **client-side wrapper** (`Inventory`/`Equipory.addchild` does
  `add(new WItem(gitem))`, no id). So the stable, facade-safe ItemRef is just **`GItem.wdgid()`**, re-resolved via
  `UI.getwidget(id)` — no bridge registry (→ no leak; the engine's `UI.widgets` already tracks it), no
  `(container,slot)` juggling (D-022). When a spec asks for an opaque handle and the thing is a server widget,
  its wdgid is almost always the answer (same as `LuaModel`/`raw`).
- **4f — add the handle to the SHARED snapshot builder and every reader gains it for free.** Putting `handle`
  in `itemSnapshot` made `hafen.items.*` AND `model:items()` actionable in one edit — which is exactly how the
  Phase-3 `LuaModel` item verbs got delivered without a second OO style (D-013: one canonical `hafen.act.item`,
  not `model:item:take()`). But first CHECK the change-detection: `equipEqual`/`actionbarEqual` compare only
  named fields and the model item poll is identity-keyed, so an extra field is inert — had a differ done a
  whole-table compare, the new field would have spammed `*Changed`. Enrich shared shapes deliberately, and
  re-verify every diff that consumes them.
- **4f — for a WRITE verb, re-resolve-and-fail-loud beats acting on a stale reference.** `hafen.act.item`
  re-resolves the live `GItem` each call and throws a guiding "handle is stale" error if the id no longer maps to
  an item (moved/used/consumed) — never silently acting on whatever took its place. A GobRef has the same
  contract (fresh each call, nil if gone); for an irreversible action that "fail loud" is the safe default.
- **4g — a WRITE verb belongs in its subsystem's namespace, not under `hafen.act`.** `speed.set`/`craft.make`/
  `actionbar.use`/`kin.*` sit next to their reads (`hafen.speed.get`, `actionbar.slot`, `kin.list`), sharing the
  same `requireActions` gate but NOT the `hafen.act.*` prefix — reads and their write pair read together (`use(n)`
  takes the exact index `slot(n)` returns). `hafen.act.*` stays for the map/menu/flower/item/raw primitives that
  have no read subsystem of their own. Wrap-not-reimplement (D-009) makes each verb a one-liner — drive the
  client's own `Speedget.set`/`Buddy.chgrp`/`Belt.act`, never re-encode the wire message.
- **4g — order a gated verb's checks so the headless-safe ones run before any static-field read.** `kin.setGroup`
  validates `group` against `BuddyWnd.gc.length`, but *referencing* `BuddyWnd.gc` forces `BuddyWnd.<clinit>` →
  `UI.<clinit>` → the resource loader (NoClassDefFoundError `dolda/jglob/Loader` under bare `jshell`), same class
  of trap as A7's `Speedget.tips` / A8's `Makewindow`. Resolving the kin FIRST (instance-only: `buddywnd()`/
  `find`/iteration touch no `BuddyWnd` statics) means headless we fail with "no Kin window" *before* the `gc` read,
  so the gate + wiring stay fully testable and the range check is verified in-game. General rule: instance ops on
  a possibly-null widget are headless-safe; a `Class.STATICFIELD` read is not — put it last.
- **4g — LuaJ `isstring()` is TRUE for numbers (they coerce), so it does not reject a numeric arg.** A `rename(kin,
  5)` passes `name.isstring()` and coerces to `"5"` — consistent with the existing `flower`/`item` verbs, and fine
  (Lua-idiomatic). To actually REJECT a non-string, test a non-coercible type (a table/bool) — `{}` → `isstring()`
  false. Mirror image: `isnumber()` is true for a numeric STRING (`"5"`) but false for `"x"`. Know which coercions
  your validation lets through before writing the test's expected error.
- **4g — read the widget's FULL interaction model (every message AND the UI states/petals that gate them)
  before finalizing a verb surface.** THREE maintainer corrections on the kin verbs, one root cause — I under-read
  `BuddyWnd` and mapped a generic CRUD sketch instead of the game's real model: (1) I dropped `kin.add` ("no
  add-by-name message") — but the *Add kin* field sends **`wdgmsg("bypwd", secret)`** (add by hearth **secret**,
  not name). (2)+(3) I collapsed removal into one verb — but the game has a **two-step state machine**: while a kin
  is active the petal is **"End kinship"** (`Buddy.endkin`) which un-kins them but keeps them **memorized**; only
  then does the **"Forget"** petal (`Buddy.forget`) appear to drop them from the list. Both send the same `rm`, but
  they are two distinct user actions, so 4g exposes **both** `remove` (End kinship) and `forget` (Forget) — the
  server advances active→memorized→gone. Final surface: `add(secret)`/`remove`/`forget`/`rename`/`setGroup` (five
  verbs over four messages `bypwd`/`rm`/`nick`/`grp`, `setGroup` added over the "add/remove/rename" sketch). The
  lesson: a `wdgmsg(` grep is necessary but NOT sufficient — read the widget's `opts()`/petals/state guards too;
  identical wire messages can be distinct user operations, and the client's own vocabulary (D-013), not a CRUD
  template, names the verbs.

- **V1 (world ghosts):** a **client-only `Gob`** is the whole trick. `new Gob(glob, rc)` passes `id = -1`, and
  `Gob` sets `virtual = true` for any `id < 0` ([Gob.java:437](src/haven/Gob.java:437)) → it is **never in
  `OCache`**, so it is invisible to every read API and to the server (N1/N2 hold **by construction**, not by a
  gate). The engine's own **placement preview `MapView.Plob`** ([:1779](src/haven/MapView.java:1779)) is the exact
  template: `new Gob` + `setattr(new ResDrawable(...))` + `basic.add(gob.placed)` + `Gob.move` + `slot.remove()`.
- **`basic`/`Gob.placed` are BOTH public** (`PView.basic` is `public final RenderTree.Slot`; `Gob.placed` is
  `public final`), so a zero-edit ghost was *possible* — but the spec/PLAN chose **option A** anyway: a centralized
  `// addon:` `MapView.addClientGob`/`removeClientGob` seam. The value isn't access, it's **encapsulation** — the
  addon layer never couples to "scene nodes go through `gob.placed` into `basic`", and V-series changes (a ghost
  scene layer, shadow exclusion) centralize in one place. D-011: invasiveness that clearly enables the feature.
- **`ResDrawable`'s ctor calls `res.get()`** → throws `Loading` until the resource is cached. So building a ghost
  on the UI thread would blow up on a cold prop. The fix is the **`glob.loader.defer` idiom** (Plob + `hafen.sound.
  play`): defer the build to a loader thread; `Loading` **re-runs** the deferred task when the resource lands; a
  non-`Loading` error means a bad name (report + abandon, don't re-run forever). The handle is returned immediately
  and works while the visual streams in — every `hafen.*` "create a visual from a resource name" call should do this.
- **RenderTree slot mutation is thread-safe from any thread** — `Slot.add`/`remove` take the tree's own lock
  ([RenderTree.java:472](src/haven/render/RenderTree.java:472)), which is why the engine's `Gobs`/`Plob` add slots
  on **loader** threads. So a deferred-create `addClientGob` (loader thread) + a UI-thread `removeClientGob` are
  both fine. Build the heavy gob+drawable OUTSIDE the ghost's own lock; keep only the **atomic add-and-publish**
  inside it (so a concurrent `:destroy` either discards the un-added gob or removes the published slot — never leaks).
- **A client-only gob must be ctick'd + gtick'd by hand — the first in-game bug** ("nothing appears"). The render
  tree ticks `gob.placed` (a `TickList.Ticking`) → `Placed.autotick` recomputes the **position** when `rc`/`a`
  change (so `:move` needs no poll). BUT the **sprite** (`ResDrawable`) is ticked by **`OCache.ctick`** → `gob.
  ctick` → `spr.tick`, and drawn via `gob.gtick`; a client-only gob is **not in OCache**, so without explicit
  `ctick`/`gtick` the sprite never prepares/animates and **renders nothing**. That is precisely why MapView
  hand-ticks the placement `Plob` — `ob.ctick(dt)` in `tick()` ([:1730](src/haven/MapView.java:1730)),
  `placing.get().gtick(g.out)` in `draw()` ([:1651](src/haven/MapView.java:1651)). Fix: the seam makes MapView own a
  `clientGobs` list and `ctick`/`gtick` each ghost in those same two spots (error-isolated per gob). So ghosts need
  no *addon-side* poll, but they DO need the engine to tick them — "in the scene" ≠ "ticked". Whenever you add a
  non-OCache gob, ticking is your job.
- **Game resources load via `Resource.remote()`, not `local()` — the second in-game bug** (the resource silently
  failed). `Resource.local()` = only the client jar (HUD/sfx, bundled). `Resource.remote()` = the game/server pool
  (terobjs, gobs, downloaded + preload) **with `local()` as a fallback** — the pool the engine uses for gob
  drawables (Session/Music/Widget/ISBox). A terobj like `gfx/terobjs/arch/logcabin` is a **server** resource, so
  `local().load` never finds it (→ non-`Loading` error → the create abandons, no prop). Use **`remote()`** for
  anything a game object would draw; `remote()` still covers client resources via its fallback, so it is the safe
  default for a "resource by name" API.
- **`Gob.removed()` is package-private** (only `Gob.dispose()` is public) — the addon layer can't call the Plob
  cleanup verbatim. `slot.remove()` (unrender) + `gob.dispose()` (free the sprite) is the reachable, correct pair;
  guard `slot.remove()` against `SlotRemoved` so a relog (which already tore down the whole scene) leaves teardown
  idempotent.
- **V2 (clickable ghosts): a virtual gob has NO pick surface by construction.** `Gob.GobState.apply` preps the
  `GobClick` (the `Clickable` the pick pass keys on) **only `if(!virtual)`** ([Gob.java:716](src/haven/Gob.java:716)),
  so the very thing that makes a ghost a ghost (virtual, id -1) also makes it unpickable. Do **NOT** fix this by
  flipping `virtual` — that would re-expose it to OCache-adjacent behaviour AND break any `cg.virtual` "is this a
  ghost" test (the `Click.hit` intercept relies on exactly that). The clean seam is the **`protected obstate(Pipe)`
  hook** `GobState.apply` calls for **every** gob regardless of `virtual`: a `Gob` subclass (`GhostGob`) overrides it
  to prep a `GobClick` when a `clickable` flag is set. `obstate` runs at render-**apply** time, so the flag is read
  live. Lesson: when a base-class behaviour is gated off for your case, look for the unconditional extension hook it
  still calls — don't fight the gate.
- **`Clicklist` (the gob pick list) decides membership at slot-ADD time and never re-checks it.** `Clicklist.add`
  ([MapView.java:1234](src/haven/MapView.java:1234)) runs `slot.state().get(Clickable.slot) == null → skip` **once**,
  when the mesh slot is added; a later ancestor-state change routes to `Clicklist.update`, which only touches
  *already-tracked* slots (a slot that GAINS a `Clickable` afterward is never promoted). The engine never needs a
  runtime toggle (a real gob is clickable for life; a virtual one never is), so there is no re-filter path. Practical
  consequence: to toggle a ghost's clickability live you must **remove + re-add** it to the scene (`removeClientGob`
  + `addClientGob`) so the filter re-runs on the fresh state — a state edit alone is silently ignored. A ghost
  created clickable needs no re-add: set the `GhostGob` flag **before** `addClientGob` and it is tracked from frame
  one. (Corollary: `Gob.GobState.equals` compares only `mods`, so `updstate()` — called every `ctick` — won't
  re-apply an obstate change either; the re-add is the reliable trigger.)
- **`RenderTree.Slot.cstate`/`ostate` REPLACE (they don't compose), and a `State` IS a `Pipe.Op`.** A slot has one
  `cstate` + one `ostate`, prepped in order into its `dstate` and inherited by children; `slot.ostate(x)` swaps the
  ostate wholesale (`chstate`). This is why I could NOT just add a `GobClick` to the ghost's placed-slot `cstate`
  after the fact and expect the click-list to notice (see above) — and why re-add, not state-poke, is the toggle.
- **`GhostClicked` is owner-scoped, not a global `fire`.** Every other bus event is about **shared server state**
  and broadcasts to all addons; `GhostClicked` carries the ghost **handle**, which is a private owner-only capability
  (it can move/destroy the ghost). Broadcasting it would hand addon B a live handle to addon A's ghost. So it is
  `fireTo(owner, …)` only — matching the per-ghost `onClick`. Lesson: an event whose payload is a *capability* (a
  handle, not data) should be delivered only to the owner; reserve the global bus for shared-world *data* events.
- **The `Click.hit` intercept is the mirror of the L2 action hook, done in-place.** Ghost clicks are consumed at the
  same `MapView.Click.hit` choke point the voice feature hooks ([:2066](src/haven/MapView.java:2066)) — before
  `wdgmsg("click", …)`. The `cg.virtual` pre-check is a near-zero fast path (real gobs are non-virtual → the addon
  layer is never asked about an ordinary click). A clickable ghost consumes **unconditionally** (client-only ⇒ a
  "click" send would be a bogus id -1 anyway); "pass through to the gob behind" would need a re-pick excluding the
  ghost, so it is deferred — an addon that wants a normal click keeps the ghost `:clickable(false)`.
- **V3 (ghost look): tint and translucency are ordinary render states in `obstate` — the engine already has the
  recipes.** A gob **tint** is a `MixColor(r,g,b,a)` (a = blend strength) — the exact state `GobHealth` composes for
  the red damage overlay ([GobHealth.java:48](src/haven/GobHealth.java:48)). A **translucent** object is
  `BaseColor(1,1,1,α)` (multiply the fragment alpha) + `FragColor.blend(new BlendMode())` (SRC_ALPHA/INV_SRC_ALPHA)
  + `States.maskdepth` (don't write depth) — the same three the client uses for its own translucent overlays
  (`gridmat` [MapView.java:872](src/haven/MapView.java:872), the drag-select rect [~:2277](src/haven/MapView.java:2277)).
  Both are `State`s (⇒ `Pipe.Op`s), so `obstate(Pipe buf)` just `buf.prep(...)`s them alongside V2's `GobClick`. No
  bespoke shader. Caveat: `maskdepth` means a translucent ghost does **not self-occlude** (x-ray/hologram look) — the
  standard trade for not writing depth; a solid-but-tinted prop is `tint` with `alpha = 1`.
- **A live `obstate` change (tint/alpha/clickable) needs the SAME remove+re-add as V2, for the SAME reason.**
  `Gob.GobState.equals` compares only the `SetupMod` mods, never `obstate`'s output, so `updated()`/`updstate()`
  won't re-apply a tint/alpha edit any more than it re-applied a clickable flip. One `refreshGhostScene` (remove +
  re-add the scene slot) serves all three; `:rotate`/`:move` are different — they change the `Placement` (position/
  facing), which `Placed.autotick` DOES diff and re-apply every frame, so no re-add. Lesson: know which state bag a
  change lands in — the placement (auto-diffed) or the gob obstate (not) — before deciding how to propagate it.
- **Swapping a drawable on a LIVE gob needs `synchronized(gob)` — the engine's own live res-swap shows the lock.**
  `ResDrawable.$cres.apply` (the server "change resource" delta) calls `g.setattr(new ResDrawable(...))` from a
  loader thread, and it runs inside `OCache.GobInfo.apply`'s `synchronized(gob)` ([OCache.java:384](src/haven/OCache.java:384)).
  `Gob.setattr` mutates the gob's plain-`ArrayList` `slots` (via `RUtils.multiadd/multirem`), which the ghost `ctick`
  path also touches under `synchronized(gob)` — so `:setRes` must take that same lock. Resolve the resource first on
  a loader thread (dodging `Loading`, like `new`), build the `ResDrawable` outside the lock, then `setattr` under it;
  a newer `:setRes` supersedes an older one via a `gh.res != rid` identity check so a slow swap can't clobber a fast
  one. (The create path does `setattr` BEFORE `addClientGob`, i.e. before the gob is live, so it needs no lock.)
- **Colour has ONE canonical shape in this API — named keys `{r=,g=,b=[,a=]}`, 0..255 — even though a spec example
  showed positional.** The 16-virtual-entities sketch wrote `tint = {80,160,255,180}`, but `hafen.markers` add-opts
  (`luaColor`) and the colours `hafen.party`/`hafen.kin` RETURN are all named-key. Reuse `luaColor` (with `a`
  defaulting to 255) so there is exactly one colour convention; a spec's illustrative literal does not override the
  already-shipped canonical form (§1 "one canonical way").
- **V4 (grid-anchored persistence): `gridPos` had no inverse, and it needs a grid-by-STABLE-id lookup.** Saving a
  layout means storing `gridPos(x,y)` = `{gridId, off}` (the offset is grid-relative ⇒ session-invariant) and, on
  load, turning it back into a login-relative world coord. The forward path (`getgrid(gc)`) keys grids by
  session-local `gc`; there is **no** public "find the grid whose stable `id == X`" — and stable ids aren't spatially
  ordered, so you can't derive it from a neighbour. The one honest primitive is a scan of `MCache.grids` (package-
  private) for `g.id == id`, returning `g.ul·tilesz` — the SAME basis `gridPos` subtracts, so `fromGridPos(gridPos)`
  is exact by construction. It lives in the addon-owned `AddonWidgets` (one read, **zero `MCache` edit**), not the
  engine. Lesson: when you expose a lossy/relative encoder (`gridPos`), ship its decoder as a real primitive rather
  than making every addon re-derive it — and reach package-private engine state through the ONE `AddonWidgets`
  accessor, never reflection.
- **V4: re-resolve grid anchors WITH A RETRY — grids stream in after `OnEnterWorld`.** The per-char store is restored
  before `OnEnterWorld` (1e), but the **map grids around you are not loaded yet** at that instant, so `fromGridPos`
  returns nil for anchors whose grid hasn't arrived. Resolve what you can at login, then `timer.every(1, …)` retry the
  rest for ~15s (same pattern as `hello` re-reading char/inventory at +3s). Anchors still unresolved after that are
  simply out of range this login — **keep them in the store** (never drop), they resolve on a closer login. This is
  the general shape for any grid-anchored reload (markers, ghosts, waypoints).
- **V4: the ghost HANDLE can't be persisted — keep a runtime list + a serializable mirror.** A ghost handle carries
  Lua closures/Java refs, so a saved-variables table stores only `{res, a, anchor}` and the live handle stays in a
  parallel runtime list (`items`, the source of truth); `persist()` projects the serializable subset. The store JSON
  round-trips a nested **array-of-objects** fine (verified: writer recurses, reader rebuilds 1-based arrays + string-
  keyed objects), and a 64-bit `gridId` MUST stay a **string** end-to-end or a double loses its low digits — the same
  reason `gridPos` returns it as a string (§ grid-ids-are-strings).
- **V5a: screen→world is a GPU readback ⇒ ASYNC — don't fake a synchronous return.** The engine's only accurate
  pixel→terrain answer is `MapView.Maptest` (the click-location buffer readback the client's own placement uses); a
  synchronous `screenToWorld(sx,sy)→{x,y}` would fence the UI thread on the GPU. So the primitive takes a **callback**
  (`fn` called a frame later), exactly the one-frame lag a placement `Plob` has. The spec table's `{x,y}|nil` return
  was illustrative; the faithful (D-009) reuse is async. During a drag, **coalesce** (one raycast in flight per
  callback) so a fast drag doesn't queue a backlog of GPU passes — the same cadence the client's placement has.
- **V5a: `MouseMoveEvent` is BROADCAST to every *visible* widget; `MouseUpEvent` is not.** A drag needs every move
  (even off the origin) + the terminating up wherever it lands. `MouseMoveEvent.propagation` dispatches to ALL visible
  children (no cursor-area test), so a **visible** root child gets every move — but the invisible `AddonRoot` tick
  pump (`visible=false`) does **not**, so a grab needs its own visible (zero-size) widget. `MouseUpEvent` only reaches
  the widget under the cursor unless `ui.grabmouse` captures it (grabs are checked before normal dispatch; it also
  captures down/wheel → the MapView neither pans nor clicks during the drag = "camera stays put", zero core edit).
  This is precisely the draggable-`Window` pattern — reuse it, don't invent capture.
- **V5a: every `callLua` site holds `synchronized(ui)`, so Lua from different threads still serializes.** The grab's
  move/up fire from input dispatch (which `UILoop.Frame.tick` runs under `synchronized(ui)`), while `screenToWorld`'s
  readback callback fires on the render thread and takes `synchronized(ui)` itself — so the two never run addon Lua
  concurrently (the same discipline behind V2 click / L3 message). And `Maptest.run()` does NOT block: it submits the
  readback and returns while the frame still holds `ui`; the callback lands after the frame releases it. When adding a
  new callback surface, keep it under the `ui` monitor and it composes with everything else for free.
- **V5a: factor a client formula into a shared static rather than mirroring it (D-033/D-009).** Ghost snapping must
  feel identical to placing a building, so instead of copying `StdPlace`'s math into the bridge (drift risk), one
  `// addon:` refactor lifts it **verbatim** into `MapView.placeSnap(Coord2d,int)` that both `StdPlace` and
  `hafen.map.snapPlace` call — one code path, always honouring the live `:placegrid`. A `MapView.<clinit>` needs GL
  (`dolda.jglob.Loader`), so the static can't be jshell-loaded headless; verify the pure formula on `Coord2d` and rely
  on textual identity with the proven client code (in-game confirms end-to-end) — the A8/A10 "headless resource skip"
  pattern, now for a whole class's `<clinit>`.
- **V5: a "gizmo" task is naturally two slices — the Java primitives, then the Lua gizmo (D-031).** Doing the
  primitives (raycast + snap + grab) with a body-drag proof (V5a), THEN the arrow-handle gizmo over them (V5b), keeps
  each one in-game-verifiable and front-loads the hard infra (async readback, capture, snap reuse) so the gizmo layer
  is pure Lua. Split at the primitive/behaviour seam whenever a capability is "engine exposes X, addon orchestrates X".
- **V5b: the spec's "fallback" can be the better build — DRAWN (2D-projected) handles need no resource.** V2 gives 3D
  ghost picking, so the "primary" gizmo was 3D arrow-**mesh** ghosts — but that needs a small arrow **resource**, and
  none ships in the client jar. The spec's documented alternative (§4) — project the target + world-axis tips to
  screen, draw the handles, hit-test in screen space — sidesteps the resource entirely and is what the maintainer
  wanted (Unity look, `g:draw` triangles). When a "primary" path has a hidden asset dependency, the "fallback" is
  often the pragmatic default. The arrows still look 3D: re-project every frame so they foreshorten with the camera.
- **V5b: arm the drag on the REAL mousedown (via `hook.input`+`preventDefault`), not on a V2 ghost-click.** A ghost
  `onClick` fires from the async `Click.hit` pick a frame AFTER mousedown, so "click an arrow-ghost to start a drag"
  races the click's own mouseup (does the arming release reach the grab, or not? — timing-dependent). Detecting the
  press directly with a `mousedown` input hook, `preventDefault`, and arming `hook.grab` **on that press** makes it a
  clean press-drag-release: the grab captures the moves + the terminating up, and the FIRST up IS the drop. No
  moved-flag hacks. `preventDefault` on a hit also blocks the map click + camera + the ghost's own V2 select; on a
  MISS, don't preventDefault, so ordinary clicks still work.
- **V5b: mapview-local pixels line up across pick and projection — `hook.input` `ev.x/y`, `worldToScreen`, and the
  overlay all share it (fullscreen MapView).** So a screen-space hit-test of the cursor against `worldToScreen`ed
  handles is exact with no conversion. Only the DRAWING assumes the MapView is fullscreen at the origin (like the 2b
  crosshair overlay); hit-testing is unaffected either way (both sides are mapview-local).
- **V5b: axis-lock is trivial because `placeSnap` snaps each component independently.** For an X-drag, vary world-X and
  pin world-Y to the value captured at grab start (the axis line through the target); `snapPlace(w.x, anyY).x` is the
  snapped X regardless of Y. So "project ground point → keep one component → snap → move" is the whole constraint — no
  line-projection math needed.
- **V5b: a filled triangle needed only a `LuaGOut` addition, not a `haven` edit — `GOut.drawp`/`tx` are public.**
  `g:poly(x1,y1,...)` calls the public `GOut.drawp(Model.Mode.TRIANGLE_FAN, verts)` (the same primitive `fellipse`
  uses) and adds the public `GOut.tx` per vertex so it lines up with `g:line`/`g:frect`. Before reaching for a core
  edit to draw something new, check whether the `GOut` primitive is already public — often the draw wrapper can grow
  in our own package.
- **V5b: a "bundled Lua library" ships as a separate file exposing a global — addon files share one env, `require` is
  withheld.** `Addon.run()` loads `manifest.files` in order into ONE `Globals`, so `gizmo.lua` (listed first) sets a
  global `gizmo` that `main.lua` reads. The sandbox doesn't lock the global table, so new globals are fine. This is
  the D-031 "ships in the planner example" shape; promote to a real `hafen.ghost.gizmo` later with a thin Java shim.
- **V6: a `Location.scale` prepped in `Gob.obstate` scales IN PLACE, because obstate is the gob's CHILD render slot.**
  The `Placed` slot applies the world translate (`"gobx"`) + facing rotate (`"gob"`); `obstate` (the `GobState`) is a
  deeper child slot, and `Location` composes multiplicatively down the tree (`Transform.fin(p)=p.mul(xf)`), so the
  model matrix is **T·R·S** — scale first (local origin), then rotate, then translate. So the "least-native piece"
  (spec §10) is a **zero-core-edit** one-liner in our own `GhostGob`. Guarded by: a sprite that does
  `Location.goback("gobx")` (e.g. `resutil.CSprite`) resets past BOTH facing and scale — but such resources already
  ignore ghost rotation, so it's a consistent, documented caveat, not a regression. Confirm survivability by the fact
  that ROTATION reaches the mesh (a `goback("gob")` would drop scale but not rotation — and no sprite does that).
- **V6: rotation snapping is NOT symmetric with position snapping — `StdPlace.rotate` is wheel-RELATIVE, so there's no
  verbatim math to share.** Position got a shared `MapView.placeSnap` (extracted verbatim from `StdPlace.adjust`);
  the rotate handler *increments* the facing per wheel notch, so a gizmo ring (which needs an ABSOLUTE angle→grid
  snap) has no engine expression to factor out. Answer: a small pure `snapPlaceAngle` in the BRIDGE reading the
  **public** `plobagran` (the §4.1 zero-edit mirror) — `45°` coarse / `π/plobagran` fine. Don't force a `MapView`
  refactor when the client has no matching operation; the public setting is the shared contract.
- **V6: a gizmo rotate ring should be RELATIVE (anchor the swept angle at grab), not absolute "face the cursor".**
  Capture `offset = a₀ − rawAngle` on the first raycast and apply `snapAngle(rawAngle + offset)`, so grabbing the ring
  rotates BY the swept angle instead of snapping the object to point at where you grabbed. Same trick works for any
  drag that maps an absolute cursor angle to a delta.
- **V6: build `atan2` from `math.atan` (1-arg) + quadrant fixes rather than depend on `math.atan2`.** It's an optional
  stdlib function (absent in some Lua 5.1 / LuaJ builds); the 1-arg `math.atan` + `math.pi` are always present.
  Headless-verify the quadrants in a real `Sandbox.create()` env (use `.invoke()` for multi-return chunks — `.call()`
  returns only the first value, which silently passes a `== expected` on the first case and fails the rest).
- **V6: the "draw-on-top + constant-size handles" polish is FREE on the 2D-projected gizmo path.** A HUD overlay has no
  depth test (always on top), and fixed-px handles are literally fixed px — no camera-distance rescaling (that was the
  3D-native path's problem). Only the world-anchored axis shafts foreshorten, which is desirable.
- **R1: a `.res` image is already a PNG, so the "custom image" loader is `ImageIO.read → new TexI(img)` — zero core
  edit.** `Resource.Image` does exactly `new TexI(ImageIO.read(...))` ([Resource.java:1060/1182](src/haven/Resource.java:1060)),
  and `SpeakerIcon.GLYPH` blits a bare `TexI` with no resource; every backing (`GOut.image`/`aimage`, `new TexI`,
  `TexI.sz`/`dispose`) is public. So `hafen.render.image` is `io.brodgar.addon`-only. Bonus: `new TexI(BufferedImage)`
  uploads to the GPU **lazily** (in `TexI.st()`), so the loader is even **headless-constructible** — the jshell test
  decodes a real PNG and builds the `TexI` with no GL context (only `st()`/a real blit would need one).
- **R1: a bridge-owned handle with no server id carries its Java ref as an OPAQUE USERDATA, not via a global id-map.**
  Widgets/items/gobs re-resolve through an int ref + `UI.getwidget` because they can go stale; an image can't (it's a
  pure client asset the bridge owns), so there's nothing to re-resolve — the reference travels *in* the handle. Storing
  it as `LuaValue.userdataOf(luaImage)` (the **same facade-safe pattern `LuaMarshal` uses** for hook args) is P1-clean:
  no metatable ⇒ no Java method reachable from Lua, and unforgeable ⇒ the sandbox omits `luajava`. `g:image` reads the
  handle-table's userdata field → casts → draws. Simpler than a registry (no counter, no map teardown; GC'd with the env).
- **R1: the D-017 path sandbox is ONE containment check, not a pile of string bans.** `base.resolve(name).normalize()`
  then `p.startsWith(base)`: after `normalize()`, an **absolute** path and a `..` that **climbs out** both fail
  `startsWith` (they no longer share the folder prefix), while an internal `a/../b` stays inside and is allowed. One
  line covers "reject absolute + `..`-escape" without banning legitimate internal traversal — cleaner than blacklisting
  `..`/`:`/leading-`/`. (Windows case-insensitivity is a non-issue: both paths derive from the same `base` prefix.)
- **R1: guard the blit on a `volatile dead` flag or `:dispose()` isn't permanent.** `TexI.dispose()` only nulls the
  cached GL texture; the very next `TexI.st()` (inside `GOut.image`) **re-uploads** it. So a disposed image drawn again
  would silently resurrect. The fix is a `volatile dead` on the `LuaImage`, set before `tex.dispose()` and checked in
  `g:image`/`g:aimage` before drawing — dispose becomes final, and a UI-thread dispose racing a draw-thread blit costs
  at most one extra frame. Lesson: engine `dispose()` methods are often "release resources," not "make unusable" — add
  your own liveness flag when you need the latter.
- **R2a: the V-series ghost was already 95% the generic world-entity — the "one real refactor" was a mechanical base
  extraction, not a rewrite.** Only `res`/`sdt`/`setRes` were ghost-specific; the transform/look/scene/lifecycle/gizmo
  are visual-agnostic. So `LuaWorldEntity` (base) + `LuaGhost`/`LuaSprite` (visuals) + a `*Ghost`→`*Entity` rename of
  the `AddonManager` scene helpers was low-risk (pure rename + type-widen), and the **existing ghost auto-demo is the
  regression test** — it drives every renamed helper at each login. Extract a base the moment a second thing wants
  95% of the first's machinery; don't wait until the duplication is entrenched (would-be R3 would have tripled it).
- **R2a: a client-only textured world quad is a `.res` mesh minus the resource wrapper — build the `Model` directly.**
  The `basic` PView scene already preps `Homo3D.state` (the proj·cam·loc vertex transform), so a raw 4-vert
  `TRIANGLE_STRIP` `Model` of `Homo3D.vertex`(VEC3)+`Tex2D.texc`(VEC2) renders in world space with no shader wiring.
  Author the quad in **gob-local space** (x=0 plane, z up 0→h, y across the width) and the gob's `Placed` slot
  (translate + z-rotation by facing) makes it stand upright and face `a` — identical to how a `.res` mesh is authored,
  so no coordinate fights.
- **R2a GOTCHA: a textured world surface must alpha-CLIP (discard), NOT alpha-blend — copy the engine's `$tex` matpart.**
  The first cut wrapped the texture in `new Material(tex.st(), FragColor.blend(new BlendMode()), States.maskdepth,
  nofacecull)` — that is the engine's **translucent-overlay** recipe (blend + no-depth-write, used for the tile-grid /
  selection rectangle), so even a fully-opaque PNG (verified `A=255`) rendered as a ~1% ghost. The RIGHT recipe is the
  one EVERY `.res` textured object uses ([`TexRender.$tex`](TexRender.java), `clip=true` by default):
  `new Material(tr.draw, tr.clip, nofacecull)` where `tr` is a `TexRender` over the `TexI`'s sampler (`tex.st().data`)
  — `TexDraw` samples, `TexClip` **discards** texels with alpha `< 0.5`, no blend, depth written → a **solid** cut-out.
  Lesson: don't hand-roll a `ColorTex`+blend stack for a world texture; reuse the engine's `TexRender.draw`/`clip`
  states so it renders exactly like the client's own art. (Opt-in `alpha<1` still blends, but only via `GhostGob.obstate`.)
- **R2a: to make a client entity FOLLOW a gob, attach a `Moving` — the render tree does the per-frame work for you.**
  `Gob.getc()` uses a gob's `Moving` attrib for its live position, and the render tree re-evaluates each client gob's
  placement every frame (`Placed.autotick` → new `Placement` → `getc()`). So a `FollowMoving extends Moving` whose
  `getc()` returns `target.getc() + offset` makes the entity track the target automatically — **zero Lua polling**,
  the exact path the engine's own `Following` (held-item-follows-hand) uses. Deliberately NOT a `Following` subclass:
  `Placed` special-cases `Following` (the bone-transform path); a plain `Moving` takes the simple translate-to-`getc()`
  + rotate-by-own-`a` path, so the sprite keeps its own facing/scale. Re-resolve the target id each frame
  (`oc.getgob(id)`) so it survives the gob unloading/reloading. All backings public (`Moving`, `Gob.glob`/`getc`/`getrc`,
  `OCache.getgob`) → zero core edit. This is the world-space analog of the `gobOverlay` GAttrib sweep.
- **R2a: no `res.get()` ⇒ no `glob.loader.defer` — a sprite creates synchronously, unlike a ghost.** The ghost defers
  only to dodge the `Loading` that `res.get()` throws until the resource streams in (the Plob precedent). A sprite's
  `TexI` is already decoded (R1, on the UI thread), and `Model`/`Material`/`addClientGob` never throw `Loading`
  (`RenderTree` slot mutation is tree-locked, safe from the UI thread) — so `newSprite` builds + publishes inline and
  the handle's gob is live on return. Don't cargo-cult the defer dance when there's nothing to wait for.
- **R2a: dispose only what you own — split the sprite's geometry from the shared texture.** `SpriteQuad.dispose()`
  frees only its `Model`'s `VertexArray`; the `TexI` belongs to the `LuaImage` handle (`Addon.images`) and is freed by
  `teardownImages`. This lets one image back several sprites + the screen-`g:image` at once, and keeps teardown order
  irrelevant (the sprite never touches the texture). Mirror of R1's "engine `dispose()` releases, doesn't invalidate."
- **R2b: a world billboard is the `SpeakerIcon`/`gobOverlay` pattern — a `PView.Render2D` on the gob, not a mesh.**
  A camera-facing world image is a screen-space blit anchored at a projected world point: implement `PView.Render2D`
  and, in `draw(GOut, Pipe state)`, `Homo3D.obj2view((0,0,z), state, …)` → screen, then `g.image(tex, pos, sz)`. The
  `state` already carries the gob's `Placed` world transform, so moving the gob (or a followed one) moves the blit —
  position + gizmo-move come free; world-rotate/scale are meaningless (it's 2D). The 2D pass draws after the 3D scene,
  so it's on top (no depth) and screen-sized. This is the ergonomic, gob-anchored twin of drawing at
  `player.worldToScreen` in a `hafen.ui.overlay`.
- **R2b GOTCHA: a Drawable-less virtual client gob self-removes every `ctick` — make the billboard the gob's `Drawable`.**
  [`Gob.ctick`](src/haven/Gob.java:463) ends with `if(virtual && ols.isEmpty() && getattr(Drawable.class)==null)
  glob.oc.remove(this)` — it treats a virtual gob with no overlays and no `Drawable` as garbage. A billboard drawn by a
  bare `GAttrib`(+`Render2D`) would hit this **every tick** (locking the shared `OCache` + copying its callback list;
  the remove itself is a no-op since a client gob was never in `objs`, but the churn is real). Fix: make the visual a
  resource-free **`Drawable`** (`getres()==null`, like `SprDrawable`) — then `getattr(Drawable.class)!=null` and the
  cleanup never fires, AND (bonus) `attrclass` stores it under `Drawable.class` = THE gob visual (correct), while
  `Gob.added`'s `slot.add(drawable)` still registers its `Render2D` (membership is by slot-object type in the tree
  adapter, independent of the node's no-op `added` — the same mechanism that renders `SpeakerIcon`).
- **R2b: generalize a subsystem event by naming it from the entity, not the call site.** The V2 click intercept
  (`MapView.Click.hit` → `onGhostClick`) was ghost-only; widening it to sprites needed **zero new core edit** — just
  `findGhostByGob`→`findEntityByGob` (scan `ghosts`+`sprites` → `LuaWorldEntity`) and let the base class name its own
  event via abstract `clickEvent()`/`clickKey()` (`GhostClicked`/`ghost` vs `SpriteClicked`/`sprite`). A **fixed**
  sprite is pickable (its quad renders into the clickmap); a **billboard** has no world mesh, so `clickable` is a
  harmless no-op — pick surfaces need geometry, and a 2D blit isn't in the 3D clickmap.
- **R2b: the D-013 shared core pays off at the EXAMPLE layer too — the planner became kind-agnostic with a rename.**
  Because a sprite handle and a ghost handle are identical, generalizing the `planner` to place both was mostly
  `it.ghost`→`it.entity` + a `kind` discriminator on the record; selection, the gizmo, grab, and grid-anchored
  persistence are untouched (they only ever call `:pos()`/`:move()`/`:alpha()`/…). Persist `kind`/`img`/`billboard`
  alongside `res`, default old layouts to `kind="ghost"`, and one code path drives ghosts + fixed + billboard sprites.
- **R3a: a whole new file format is one pure class + the shared visual pattern — the R-series core paid off a 3rd time.**
  Adding glTF models was ~2 real pieces: a **pure-Java parser** (`Gltf`, over our existing `Json`) and a **`MeshSprite`**
  that clones `SpriteQuad`'s "resource-free `Sprite` → engine `Model` + `Material`, added to the `SprDrawable` slot"
  shape (just N primitives instead of 1 quad, and a `BaseColor` instead of a `TexRender`). `LuaObject`/`LuaMesh`/the
  facade/teardown/pick are all copy-adjust of the R2 sprite equivalents. So the "big one" was mostly the *parser*, not
  the *engine plumbing* — the shared world-entity core (D-013) already had transform/look/gizmo/teardown solved.
- **R3a: keep the file parser 100% pure so it is fully headless-testable — bake into vertices, not a runtime matrix.**
  `Gltf` touches no GL and no session — only `Json`, `haven.Matrix4f`/`Coord3f` (pure math), and byte arrays — so a
  known model's baked geometry can be asserted numerically (27 checks: `.glb`/`.gltf`+data-URI, indexed/non-indexed,
  TRS + hierarchy baking, the basis round-trip, materials, the error paths). Baking the node transforms **and** the
  basis/units conversion into the vertex positions **at parse time** (rather than a per-frame root `Location`) is both
  cleaner (the gob's own `Placed`/`obstate` do the world transform) and what makes the output directly testable +
  `:bounds()` trivially world-unit-correct. The engine-`Model` build (`MeshSprite`) is then a thin GL wrapper verified
  by compile + in-game, the A8/A10 "headless resource skip" precedent.
- **R3a: the glTF→engine coordinate basis is a det-+1 rotation × a unit scale, chosen once and documented.** glTF is
  right-handed +Y-up metres; H&H model space is Z-up tiles (the ghost/sprite convention). `(x,y,z)→(x,-z,y)` (+90°
  about X) maps up→up and **preserves winding** (determinant +1), so R3b can honour `doubleSided`/back-face cull
  without reversing indices; times `MODEL_UNIT` (=`tilesz.y`=11 world units/metre → 1 metre = 1 tile). The glTF origin
  = the gob position (author base at `Y=0`), mirroring how ghost `.res` models sit at their feet. `haven.Matrix4f` is
  column-major with the SAME `m[col*4+row]` layout as a glTF `node.matrix`, so a glTF matrix drops straight in.
- **R3a: an unlit flat solid needs only `POSITION` + `BaseColor` — the scene provides the rest.** The `basic` PView
  scene already preps `Homo3D.state` (world-vertex transform), the camera/projection, and the `FragColor` target, so
  a `Model` with just `Homo3D.vertex` + a `new Material(new BaseColor(...))` renders as a solid, opaque, flat-coloured,
  depth-writing surface — `BaseColor` multiplies the default white fragment (no light math). No blend / no `maskdepth`
  for an opaque solid (those are the *translucent-overlay* recipe — the R2a "1% ghost" trap); `nofacecull` for R3a so a
  winding/basis quirk can never hide a face.
- **R3b: `texture × baseColorFactor` = `TexRender.TexDraw` + `BaseColor` (both `mul` at priority 0).** `Tex2D.mod`
  (from `TexDraw`) and `BaseColor.shader` both do `FragColor.fragcol().mod(in→mul(in, …), 0)`, so listing both in a
  `Material` composes them into a single multiply → the glTF base-colour semantics. Alpha modes reuse existing engine
  states: `MASK` = `TexRender.TexClip` (fixed 0.5 discard — the engine has no per-material cutoff, so glTF `alphaCutoff`
  ≠ 0.5 isn't honoured); `BLEND` = `FragColor.blend(new BlendMode())` + `States.maskdepth` (the exact translucent recipe
  `GhostGob.alpha` uses); `doubleSided` = `Material.nofacecull`, else `new States.Facecull()` (BACK). `State implements
  Pipe.Op`, so a `List<Pipe.Op>` of states → `new Material(list.toArray(new Pipe.Op[0]))`.
- **R3b: decode mesh textures with `new TexI(img, false)` (NO power-of-two rounding).** The default `new TexI(img)`
  rounds to POT (`tdim = nextp2(sz)`), which for a non-power-of-two image leaves glTF's `[0,1]` UVs sampling into the
  padding. `round=false` (`tdim == sz`) makes `[0,1]` map to the whole image — the correct choice for externally-authored
  UVs (modern desktop GL handles NPOT + NEAREST). (The 2D `.res` path dodges this by sampling in *pixels* / `tdim`; a
  3D `[0,1]`-UV mesh can't.)
- **R3b: keep the glTF *parser* GL-free — extract image BYTES, let the caller build the `TexI`.** `Gltf.resolveImage`
  pulls each referenced image to a raw `byte[]` (from a `bufferView` slice / `data:` URI / external file), **lazy +
  deduped** per glTF image (so N materials sharing a texture → one blob). `ImageIO`→`TexI` happens in `AddonManager.newMesh`
  (needs the addon session anyway). This keeps `Gltf` a pure byte/math class (headless-testable: assert blob count / PNG
  magic / dedup), the same discipline as R3a's geometry.
- **R3b: the shared mesh `TexI` changes `mesh:dispose()` semantics — teardown ORDER matters.** R3a's mesh held no GPU
  state (objects owned their own `Model`s), so a mesh `:dispose()` never hurt a live object. R3b's mesh owns the shared
  textures, so `teardownObjects` MUST run before `teardownMeshes` (it does) — else a live object references a freed `TexI`.
  A *manual* `mesh:dispose()` while an object still draws it now frees the textures out from under it (documented: dispose
  a mesh only when unused).
- **glTF UV `v`-orientation is a genuine can't-verify-headlessly item — make it a one-line switch.** glTF `v=0` = image
  top; `TexI.st()` uploads the `BufferedImage`'s row 0 (top) directly (no flip) → glTF UVs *should* map straight (no
  `1-v`). But 3D sampling orientation can't be asserted without GL, so `MeshSprite.TEXV_FLIP` is a single `boolean`:
  ship the reasoned default (no flip), flag it as the first in-game check, flip in one line if wrong. (Same spirit as the
  A8/A10 "headless resource skip" — isolate the un-testable bit behind a trivial toggle.)
- **R3b-2: the D-013 shared core pays off again — an example-addon integration can be pure Lua.** Adding glTF models to
  the `planner` (select + gizmo + persist) needed **zero** Java: the object handle is the same `:move`/`:rotate`/`:scale`
  handle a ghost/sprite exposes, the V2 pick/`ObjectClicked` + gizmo were generalized to objects back in R3a, and
  `gizmo.lua` already drives "anything with `:pos()`/`:move()`". So R3b-2 was one more `kind` on the planner's records +
  a `spawn` branch + `:planner object` — the same shape R2b used for sprites. **Lesson:** once the core is shared, a new
  visual kind rides *every* kind-agnostic consumer (selection, gizmo, grab, persistence, teardown) for free; the only
  per-kind code is the one `spawn` line that names its `hafen.render.*` constructor. Verify such a slice with the **LuaJ
  parse** check (compile each `.lua` via `Globals.load` without running it) + a compile-still-green + logic review — no
  rebuild, `ant bin` + `:reload` to test.
- **Ship the LIGHTEST asset that proves the flow.** The planner ships the 940-byte `cube.glb` (the R3a test cube), NOT
  the maintainer's 2 MB `tank.glb` — the *textured* render is already proven by `:hello object` (R3b-1); the planner's
  job is the **editor flow** (select/gizmo/persist), which is mesh-agnostic. A tiny generic cube is also a more natural
  "blueprint block" for a base planner. (The `bin/addons/hello/cube.glb` build artifact from R3a was the source — a valid
  glTF v2 the R3a checks + in-game already vetted.)
- **`files` in a manifest lists only the `.lua` sources, not assets.** `hello`'s manifest lists `["main.lua"]` though it
  ships `icon.png`/`tank.glb`; the planner's stays `["gizmo.lua","main.lua"]` with `cube.glb`/`icon.png` unlisted. Assets
  are resolved on demand by `hafen.render.*` (addon-relative, D-017-sandboxed) and packaged by `ant bin`'s whole-folder
  copy (`<fileset dir="addons"/>`). Don't add assets to `files`.
- **R3c: to make custom geometry lit, add `Homo3D.normal` + a `Light.PhongLight` state — the scene supplies the lights.**
  The engine's world lights (`Lighting.lights`/`Light.LightList`) are applied *at the MapView scene root*, so any gob in
  the `basic` scene (our ghost gobs included) already has them in its pipe. A material is **unlit** unless it declares a
  Phong state — that's the entire difference between R3b (fullbright) and R3c (world-shaded): one `Light.PhongLight`
  `Pipe.Op` on the material + the `normal` vertex attribute it consumes. No light *setup*, no per-frame light code, no
  core edit — the `.res` `col` layer does exactly this via `$col`→`PhongLight`. Reflectance = the engine's neutral
  `PhongLight` defaults (amb 0.2/dif 0.8/matte); the texture stays the albedo the light modulates.
- **Normals transform by the inverse-transpose, and it's cheap enough to always do right.** A normal is NOT a position:
  under a non-uniform scale a vertex-style transform *skews* it off the surface. Bake normals by `trim3(transpose(
  invert(fin)))` (fin = basis·node). For a pure rotation + uniform scale (BASIS and most nodes) this equals the plain
  transform after re-normalization — but it's one 4×4 invert per primitive, so just always do it; a headless check on a
  synthetic triangle proved the baked normal comes out unit-length and un-scaled (`(0,-1,0)`, not `(0,-11,0)`) — the
  unit-basis scale correctly drops out of the direction.
- **When a mesh lacks `NORMAL`, compute smooth ones from the BAKED geometry — the det-+1 basis keeps them outward.**
  Area-weighted face normals (`e1×e2` accumulated per vertex → normalize) computed *after* baking need no normal matrix
  and, because the basis preserves winding (det +1, the same reason back-face culling is correct), point outward
  consistently with front faces. The headless check confirmed the fallback matches the transformed attribute exactly.
- **sRGB was a non-issue because the engine doesn't sRGB-convert model textures.** Spec flagged sRGB as an R3c concern,
  but grepping the load path showed `Texture.srgb` is left `false` everywhere for models (game textures are plain
  `UNORM8`). Our `TexI`s already match, so *doing* sRGB would make ours the odd ones out. **Lesson:** "match the engine"
  can mean "do nothing" — verify what the engine actually does before adding a correction, and document the finding so
  the next person doesn't re-open it.
- **Pre-existing repo state:** `addons/planner/cube.glb` is byte-identical to `addons/hello/tank.glb` (both 2 MB), not the
  940-byte R3a cube the R3b-2 docs describe — flagged to the maintainer (it may make `:planner object` stand a tank; out
  of R3c scope, untouched). Worth a check before the next planner in-game test.
- **N1 — the JSON writer + JSON→Lua marshal already existed, just weren't shared or exposed.** The compact writer lived
  as private `AddonManager.json`/`jsontab`/`jsonstr`; a JSON→Lua converter lived as private `AddonManager.jsonToLua`.
  N1's real work was **consolidation** (D-013), not new code: move the writer into `Json.write(v[,strict])` beside the
  reader, move the marshal into `LuaMarshal.jsonToLua`, and point every caller (REPL echo, `hafen.store`, the new
  `hafen.json`) at the one copy. **Lesson:** before writing a "new" serializer, grep — the client had two, and the task
  was to *unify* them so `hafen.json` and `hafen.store` can never disagree.
- **`strict` is the only fork between the public encoder and the REPL echo.** The REPL echo must stay forgiving (a
  function result echoes as a quoted `tostring`, a cycle as `"<cycle>"`, `NaN`→`null`) so the console never throws mid-
  inspect; `hafen.json.encode` must be strict (those all throw) so its output is always valid JSON. One boolean flag on
  the shared writer covers both — no duplicated logic.
- **`Json.parse` always returns `Double`, so integer-ness is reconstructed at marshal time, not preserved.** The reader
  has no int type. `LuaMarshal.jsonToLua` narrows an **integral** value in Lua's int range back to a Lua int (`{"n":5}`
  → `5`), so it prints `5` and compares `== 5`. (Even without the narrowing the *encoded* form would be clean — the
  writer already normalizes integral doubles to `5` — but the narrowing makes the parsed value itself int-typed.)
- **Setting a table key to `NIL` is how JSON `null` becomes an absent key / array hole.** `LuaTable.set(k, NIL)` removes
  the key; for an array the position counter still advances, so `[1,null,3]` → `{[1]=1,[3]=3}` (a hole at 2). This is
  the standard Lua-JSON trade-off — documented, no `json.null` sentinel — and falls out for free from the marshal.
- **Hostile-input caps belong in the parser, not just the bridge.** The depth guard lives inside `Json.object()`/
  `array()` (a `depth` counter), so `Json.parse(text)` with the default 256 also protects the internal manifest/saved-var
  callers from a `StackOverflow`, not only `hafen.json`. The length cap is a cheap pre-check at the bridge. Both
  `-D`-tunable, mirroring `haven.addon.insncap`.
- **N2a — a blocking Java call from Lua is invisible to the watchdog, so network MUST be async.** The instruction
  watchdog counts **Lua** ops; a Lua→Java `HttpURLConnection` call blocks the UI thread with zero Lua instructions
  executing, so it would hang forever un-aborted. Hence `hafen.http` is async-only (no blocking `get`), reusing the
  exact `GobAdded` marshal: pool thread does I/O → enqueue → tick drains → armed+isolated callback. All addon Lua
  still runs serialized on the UI thread under the watchdog; the pool only ever touches JDK/`haven`-free code.
- **Per-addon concurrency limits must not block pool threads.** The naïve "acquire a per-addon `Semaphore(6)` in the
  worker" starves the shared 8-thread pool (blocked workers hold threads doing nothing, and one busy addon can wedge
  the rest). Instead a **UI-thread scheduler** (`maybeStartHttp`) counts running requests and only *submits* up to
  the limit, leaving the excess as un-started entries in `Addon.requests`; the drain re-runs it as slots free. The
  pool is always doing real work, never waiting.
- **`network` is a manifest BLOCK, not a `permissions[]` string — because the declaration carries config.** Like
  `saved_variables`, a capability-with-configuration (the host allowlist) gets its own object block. `usesActions()`
  is a bare flag; `hostAllowed(host)` needs the list. The block's presence (non-empty `hosts`) *is* the grant.
- **`InetAddress`'s own classifiers cover almost all the private ranges — except IPv6 ULA `fc00::/7`.**
  `isLoopbackAddress`/`isAnyLocalAddress`/`isLinkLocalAddress`/`isSiteLocalAddress`/`isMulticastAddress` between them
  cover `127/8`, `::1`, `0.0.0.0`/`::`, `169.254/16`+`fe80::/10`, `10/8`+`172.16/12`+`192.168/16`, and multicast —
  but **not** `fc00::/7`, which needs a manual `(b[0] & 0xfe) == 0xfc` check on the 16-byte address. Check **all**
  resolved addresses (`getAllByName`), not just the first, so a dual-record host can't smuggle a private A record.
- **`localtest.me` (and similar) resolve to `127.0.0.1` — a clean way to demo the private-IP block without a bad
  manifest.** Allowlisting a public *hostname* that DNS-resolves to loopback exercises the resolved-IP refusal path
  (accepted at the allowlist, refused on the resolved address) distinctly from the synchronous host-allowlist
  rejection. `netdemo :lan` uses it.
- **N2b — following redirects manually is the ONLY way to keep them inside the allowlist.** `HttpURLConnection`'s
  built-in `setInstanceFollowRedirects(true)` jumps silently, with **no per-hop callback** to re-check the target host —
  so it could carry a request from an allowlisted host to any redirect target (SSRF via an open redirect). The fix is
  `setInstanceFollowRedirects(false)` + a manual `while` hop-loop that runs the same `validateHop` (allowlist +
  private-IP) on **every** `Location` before connecting. Cap the hops (5) to stop redirect cycles, and resolve a
  relative `Location` with `new URL(base, loc)`. This is why the allowlist re-check is worth the loop.
- **A POST that follows a 301/302/303 must demote to GET + drop the body.** Per HTTP semantics (and every browser),
  a `303` is always a GET, and a `301`/`302` on a non-idempotent method (POST) becomes a GET too; only `307`/`308`
  preserve the method + body. Keep `method`/`body` as **mutable locals** in the hop-loop (seeded from the immutable
  request) so the demotion is local to the worker and the original handle is untouched.
- **`Content-Type` for a JSON body is set only if the addon didn't set its own** — a case-insensitive scan of the
  caller's headers (`hasContentType`), so `opts.headers = { ["Content-Type"] = "application/…" }` wins over the
  `application/json` default. The table→JSON convenience is the ergonomic default, never an override.
- **U1 — a widget becomes a drop target with ZERO core edit, because the engine already dispatches drops
  generically.** `MenuGrid.mouseup` calls `DropTarget.dropthing(ui.root, ui.mc, dragging)`, and the resulting
  `DropTarget.Drop` event walks the tree via `PointerEvent.propagation`, calling `dropthing` on the first
  `DropTarget` under the cursor — so just `implements DropTarget` + override `dropthing` on `LuaWidget` is enough.
  The `cc` handed to `dropthing` is **already widget-local** (the event derives child-local coords as it descends,
  exactly like the mouse events), so no manual `rootpos` subtraction is needed. Return `false` for a thing you don't
  handle so the engine keeps looking for another target.
- **The resource-based vs. id-only pagina split is the persistability line, and it's readable off `pag.id`.** A
  resource-based menu action stores its own resource `Indir` as `pag.id` (`id = pag.res` in `MenuGrid.uimsg`), so
  `pag.id instanceof Indir` ⇒ include the (stable, persistable) `res` name; an id-only pagina (`fl&2`) has only a
  per-session server number ⇒ deliver `kind` alone. Resolve the name through `pag.res.get().name` **guarded against
  `Loading`** (res absent until the icon streams in) — the same discipline as every other resource-name read.
- **`g:resource` needs no per-addon cache — engine resources are already globally cached.** `Resource.remote()`
  dedups `.load(name)`, and each `Resource.Image` caches its own `Tex`, so a static name→`Indir` map on `LuaGOut`
  is purely to skip the per-frame lookup, holds only lightweight global refs, and leaks nothing; clearing it on
  `:reload` is for faithfulness (D-039), not correctness. The draw must swallow `Loading` (draw nothing this frame,
  then blit once ready) — the client's own `MenuGrid.draw` idiom — so a not-yet-streamed icon never throws into the
  render thread.
- **A UI slice like U1 is thin on headless coverage by nature** — `onDrop` needs the engine's live drop dispatch, a
  bound `GOut`, and a real menu-grid drag; the pure pieces (`modsTable` bit mapping, the descriptor's resource/id-only
  gate) are trivial. So it ships on compile + LuaJ parse + an in-game DoD (drag an action → icon renders + res logs;
  Shift+click → shift=true), like the other draw/input slices (2a/2b/R1) whose real proof is on-screen.
- **W1 — `:type()` must climb past anonymous subclasses.** Hafen builds a huge number of widgets as anonymous
  inner classes (`new TextEntry(...){}`, `new Button(...){}`), and `getClass().getSimpleName()` is `""` for those —
  the first in-game tree dump showed blank types beside real text (`'znoG2Syr'`, `'Inventory'`). `nodeType` walks up
  to the nearest **named** superclass, which is the useful identity for building an adapter. `:text()`'s `instanceof`
  checks already saw through the anonymity (a subclass IS-A `TextEntry`), so only the name needed the fix.
- **W1 — a `WidgetNode` checks liveness with `hasparent(ui.root)`, not an id.** Models detect death by
  `ui.getwidget(id) != wdg`, but that only works for **server-bound** widgets; a `WidgetNode` must also cover
  **client-only** children (no id). The robust, id-free test is reachability: `Widget.remove()` nulls the widget's
  `parent`, so a destroyed widget is no longer reachable from `ui.root` — `w.hasparent(u.root)` (O(depth), the
  `GobRef`-per-access discipline) returns false. On the first stale access, **null the node's `wdg` field** so a
  stashed node can't pin a dead subtree in memory (the D-041 no-pin rule). Because nodes are never registered, there
  is literally nothing to tear down — `:reload` leaks nothing by construction (unlike models/ghosts/widgets).
- **The `:same` identity primitive rides the same opaque-userdata round-trip as `LuaImage`.** Each `node`/`children`/
  `walk` mints a *fresh* handle table and client-only leaves have no `:id()`, so Lua-side `==` and `:id()` can't
  answer "same widget as before?". The handle table carries its `LuaWidgetNode` as an unforgeable opaque userdata
  (KEY field, no metatable — the sandbox omits `luajava`); `:same` resolves the *other* handle back to its node and
  compares the wrapped `Widget` by reference (a stale node is never `:same` as a live one). This is exactly the
  facade-safe pattern `LuaImage`/`LuaMarshal` already use — reuse it whenever a Lua handle needs a hidden Java backref.
- **`node:text()` is the one upstream-volatile method — keep it a single switch.** Text lives in different public
  fields per widget (`Label.texts`, `Button.text.text`, `Window.cap`, `TextEntry.text()`); confining that knowledge
  to `nodeText(Widget)` means upstream churn breaks one method, not the API, and an unknown type just returns nil.
  Note `CheckBox.lbl` is **package-private** → deliberately not read (would need a `haven` accessor; not worth it for
  a best-effort read that's allowed to return nil).
- **W2 — mirror the engine's pointer dispatch for hit-testing; a rect test is a trap.** `hafen.ui.at` must reuse the
  exact walk of [`PointerEvent.propagation`](src/haven/Widget.java:981) — children `lchild→prev` (topmost-first, since
  the last child draws on top), `!visible()` skipped, descend by `from.xlate(child.c,true)` (NOT `child.c` directly —
  a `Scrollport` overrides `xlate` to apply the scroll offset), and `checkhit(c)` at the leaf (a widget can override
  it for a non-rectangular hit area). A naïve "is the cursor in `pos..pos+size`?" gives *wrong* answers inside scrolled
  lists and for custom hit shapes — the whole point of `/framestack` is to report the widget a click would actually
  hit. The engine's own tooltip walk ([`Widget.tooltip`](src/haven/Widget.java:1906)) is the template: `propagate`
  (walk children) first, then `checkhit` on self as the fall-back — so `hitTest` returns the deepest child, else self,
  else null. All backings are public (`lchild`/`prev`/`c`/`sz`/`xlate`/`checkhit`/`rootpos`) → zero core edit.
- **W2 — `node:at` and `hafen.ui.at` share one hitTest by converting to node-local up front.** `hafen.ui.at(x,y)`
  starts the recursion at `ui.root` with the point as-is (root coords == root-local). `node:at(coord)` takes the SAME
  root-coord point and converts it to the node's local frame with [`Widget.rootxlate(c)`](src/haven/Widget.java:504)
  (`c - rootpos()`) before starting the recursion at that node — so a caller passes `hafen.ui.mouse()` to either
  unchanged. `rootpos`/`rootxlate` already thread `xlate` up the chain, matching `hitTest`'s `xlate`-down, so scroll
  offsets stay consistent between the two directions.
- **W2 — hit-test logic is headless-testable with a hand-built `Widget` tree (no GL).** A bare `new Widget(sz)` +
  `parent.add(child, coord)` links the `child`/`next`/`prev`/`lchild` pointers with no `ui` and no GL, and
  `visible()`/`checkhit`/`xlate` are pure — so `AddonManager.hitTest` (a private static) can be exercised via
  reflection over an anonymous `Widget` subclass that overrides `checkhit`/`xlate` (12 checks: topmost-first,
  deepest-descent, parent/root fall-back, invisible-skip, `checkhit`-fall-through, a scrolled subtree, subtree-miss).
  This is a rare case where an interactive-looking UI primitive still has real headless coverage — the *dispatch* math
  is pure even though the *hover polling* is in-game-only.
- **W2 — the `:same` guard is why W1 shipped `:same`, and it's load-bearing for `OnUpdate` cost.** `widgetstack` reads
  `mouse()`+`at()` every frame but must NOT re-walk the tree + rebuild the window every frame. The guard is
  `if leaf and last and leaf:same(last) then return end` — each `at()` mints a fresh handle and client-only leaves
  have no `:id()`, so reference identity (`:same`) is the *only* reliable "unchanged since last frame?" test. Design
  the cheap per-frame primitive (`at`) alongside the identity primitive (`:same`) that lets callers throttle it.
- **F1 — keep the provider registry in `haven`, tag owners by opaque `Object`, so core files gain no addon dep.**
  The spec sketched "`FontApi` owns the registry, `Fonts` is a thin facade" — but then `Text`/`Label` (calling
  `Fonts.foundry`) would transitively depend on `io.brodgar.addon`. Putting the whole registry **in `haven.Fonts`**
  and tagging each override with the owning `Addon` as a bare `Object` (compared by identity only) keeps the core's
  dependency graph clean while behaving identically. The addon layer (`FontApi`) drives it (`push`/`reset`/
  `removeOwner`) — the normal addon→haven direction. When a spec's class layout would force a `haven → io.brodgar`
  edge into a fundamental file, flip it: data + logic in `haven`, opaque owner tokens, addon drives.
- **F1 — a headless font test needs `-Djava.awt.headless=true`, or `Text.Foundry`'s AWT init hangs forever.**
  Constructing any `Text.Foundry` calls `TexI.mkbuf(...).getGraphics()` → the AWT toolkit; on a headful-defaulting
  JVM with no display that stalls indefinitely (a 2-min timeout, not an error). `jshell -R-Djava.awt.headless=true`
  builds foundries in ~0.5 s. Also: never touch `Text.std` in a headless test — `Text.<clinit>` loads the
  `ui/fraktur` resource (absent headless, the A8/A10 "resource skip"). Test `Fonts.foundry(scope, stock)` with a
  hand-built stock `Foundry` and size-less overrides (a `size` would call `UI.scale` → `UI.<clinit>`), and assert on
  `foundry.font.getFamily()` — that covers resolution/cascade/last-wins/teardown without the engine.
- **F1 — a cached `Text` only restyles if the site re-renders on a generation bump; route the traffic, accept the
  cost.** `Text.render(…)` statics rebuild a `Line` every call, so they pick up an override for free — but a `Label`
  caches its rendered `Text`, so "live" means it must re-render. The pattern: the label follows a scope, remembers
  the `gen` it rendered at, and in `draw()` re-resolves + re-renders (preserving wrap width + colour) only when
  `Fonts.gen()` moved (one int compare otherwise; only *visible* labels pay it, once per bump). That single
  `(gen, foundry)` check is the whole invalidation model every later F-slice reuses as it routes more sites.
- **F1 — the `"default"` scope is NARROW in practice; the visible native chrome is F3's job (via the cascade).**
  In-game, `setFont("default", h)` changed addon `g:text` (→ `GOut.text` → `Text.render`, routed) but **nothing in
  the native chrome** — because buttons (`Button.tf`), tooltips (`RichText.stdf`), window titles (fraktur `DefaultDeco`),
  menus/chat/textentry each build their **own** dedicated `Text.Foundry`; only default `Label`s + the `Text.render`
  statics read the `"default"` surface. The spec's "routing them alone restyles most of the UI" was optimistic. This
  is fine and by design — the cascade means the moment F3 routes `Fonts.foundry("button", Button.tf)` (etc.), an
  unset `"button"` scope **falls back to `"default"`**, so those surfaces start following `setFont("default")`
  automatically. **F3 takeaway:** to make `"default"` feel like "the whole client," route the big shared foundries
  (`Button.tf`, `RichText.stdf`/tooltips first — highest visible impact) and give each a gen-based re-render at its
  cache site (Button.draw like Label; tooltips rebuild per-hover but cache `hasrend`, so bump on gen).
- **F2 — the api-reference's `g:text(str, pos, opts)` sketch fought the shipped positional `g:text(str, x, y)`;
  the shipped canon wins.** ~30 call sites across every addon (2a onward) already use positional coords, and spec 07
  documents them positionally. Adding an optional trailing `opts` table (`g:text(str, x, y [, opts])`) satisfies the
  DoD with **zero breakage**; a `pos`-table rewrite would have churned every addon for nothing. When a spec sketch
  and the shipped surface disagree on shape, prefer the shipped surface and correct the sketch (D-012 is about *one*
  way, not the sketch's exact spelling).
- **F2 — `$font` in an addon's own text needs the RICH path, not `Text.render`.** `GOut.text`/`Text.render` build a
  plain `Text.Line` — they **do not** parse `$font`/`$col`/`$b`. To make the spec's `g:text("$font[fam,12]{…} …")`
  work you must render through a **`RichText.Foundry`** (`.render(str, 0)` = one line, no wrap). Key on the string
  containing `$` (the engine's own markup lead — `Text.Foundry.renderwrap` *quotes* `$` precisely because bare `$`
  means markup) OR a font handle being present; keep the untouched fast path otherwise so existing plain text is
  byte-identical. `RichText.Foundry` allocates a `Graphics2D`/`FontRenderContext` at construction → **cache** it
  (per effective px on the immutable `FontHandle`; a lazy static for the stock font).
- **F2 — colour is a blit tint, not a foundry property — keeps foundries cacheable AND matches `g:color`.** Render
  glyphs WHITE and apply a requested colour as a temporary `GOut` draw colour (`getcolor()`→`chcolor(col)`→restore)
  around the `aimage`/`atext` blit. This is exactly how the stock text path already tints (a white glyph tex
  modulated by `cur2d`'s colour), so `g:color(...) + g:text(...)` is unchanged, `$col` runs still render their own
  colour, and one cached foundry serves every colour.
- **F2 — no headless render test: `Text`/`RichText` `<clinit>` loads `ui/fraktur`, absent headless.** Any test
  touching a `Text.Foundry`/`RichText.Foundry`/`Text.std` triggers `Text.<clinit>` →
  `Resource.local().loadwait("ui/fraktur")`, which throws headless (no `res/ui/fraktur.res` in the tree) — the same
  skip A8/A10/R2a documented. So the F2 draw path is compile + LuaJ-parse + **in-game** verified, not headless. (F1
  tested `haven.Fonts` because that class avoids `Text.std` — F2's `FontHandle.rich`/`stockRich` cannot.)
- **F3 chrome scopes are NOT one-line foundry swaps — each render site is a different beast; split F3 by site.** F1's
  `"default"` sites (`Text.render` statics, `Label`) were trivial because they already build a plain `Text.Foundry`
  per call / cache one `Text`. The chrome scopes are heterogeneous: `window.title` is a **blur/tex furnace**
  (`BlurFurn(TexFurn(foundry,…),…)` — you must rebuild the *whole furnace* from the provider foundry, not just swap
  a foundry), `button` rasterizes each caption to a **`BufferedImage cont`** (re-render per button on `gen`), `chat`
  uses a **`RichText.Foundry`** (a different type — `Fonts.foundry` returns a `Text.Foundry`, so chat needs its own
  provider path), tooltips mostly already ride `Text.render`=`"default"`. So F3 was split into F3a…F3d, one site
  family per slice + per-slice in-game verify (like 1c/1d/2/3). **Do not try all 7 in one prompt.**
- **F3a — furnace-backed scope pattern: keep a stock `Text.Foundry`, rebuild the furnace on `gen`, invalidate the
  cached render.** For `window.title`: (1) extract the inline `new Text.Foundry(fraktur,15)` into a named
  `public static final titlefnd` (the stock fallback passed to `Fonts.foundry`); (2) make `cf`/`ncf` non-final +
  a `checktitlefont()` that rebuilds them from `Fonts.foundry("window.title", titlefnd)` when `Fonts.gen()` moved
  (called at the top of `drawframe`); (3) add a per-instance `capgen` and re-render the cached `cap` when `gen`
  moved (the F1 `Label`-restyle pattern). All draw-thread, `gen` is `volatile` → worst case one frame late. Grep
  first: `cf`/`ncf` were `public static final` but referenced only inside `Window.java`, so narrowing to `private
  static` was safe (`Button.tf` by contrast IS referenced by `Charlist.df` — F3b must keep it accessible).

---

## 9. THE REUSABLE PROMPT

Paste this (unchanged) into a **fresh** session to continue with the next task:

```
Continue the AddOn system (Lua/LuaJ) for brodgar-io-client, on branch feature/addons.

1. Read specs/addons/PLAN.md — the living plan (status §5, task queue §7, per-task procedure §6).
   The whole design is in specs/addons/ (decisions.md, api-reference.md, code-map.md, …).
2. Take the FIRST unchecked task in §7 and do it following §6: read the specs it names + code-map,
   implement it, verify it compiles (ant hafen-client → BUILD SUCCESSFUL) and the logic (jshell
   where feasible), document the change in docs/addons/, and update PLAN.md (check the task off,
   move a summary to STATUS §5, append learnings to §8).
3. Then STOP and report: what to test in-game and the proposed commit message. Do ONLY one task.

MANDATORY RULES:
- NEVER push. Everything local.
- NEVER commit on your own: the maintainer verifies in-game and says when to commit.
- specs/ is local (gitignored) — never upload it. docs/addons/ IS committed.
- Document each task in docs/addons/ BEFORE the commit.
- Converse in Spanish; write docs/specs/code comments in English.
- Java changes need a rebuild + client restart (the JVM does not hot-reload classes).
```
