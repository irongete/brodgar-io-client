# AddOns System — Design Specification

> **Status:** 🟡 Draft / In design
> **Last updated:** 2026-07-23
> **Owner:** gonzalo (@irongete)

> **Design status: CLOSED. Implementation underway on `feature/addons`.**
> **➡ To continue building, read [PLAN.md](PLAN.md)** — the self-contained living execution plan
> (current status + task queue + per-task procedure + a reusable prompt). All design questions are
> resolved into decisions ([decisions.md](decisions.md)); the spec was audited against the real
> client. This `specs/` folder is **local-only** (gitignored); `docs/addons/` is the committed
> implementation/usage documentation.

This directory is the **living design specification** for a World-of-Warcraft-style
**AddOn system** for `brodgar-io-client` — a customized Haven & Hearth (Hafen) client.

The goal is a client that is **fully moddable by installing and enabling addons written in
Lua**, instead of the historical Haven & Hearth approach of forking and editing the Java
client for every change.

These documents are the base that will be **reviewed several times before any implementation
starts**. Nothing here is built yet. Decisions and open questions are tracked explicitly.

---

## How to read this spec

Recommended reading order for a first pass:

1. [00-vision-scope.md](00-vision-scope.md) — what we are building and why, and where it stops.
2. [01-architecture.md](01-architecture.md) — the layered architecture and the threading model.
3. [02-filesystem-and-build.md](02-filesystem-and-build.md) — where addons live on disk and how the engine ships.
4. [03-addon-format.md](03-addon-format.md) — what a single addon looks like.
5. [05-lifecycle-and-reload.md](05-lifecycle-and-reload.md) — load / enable / Reload UI.
6. Then the capability docs: [06-lua-api.md](06-lua-api.md), [07-ui-and-drawing.md](07-ui-and-drawing.md),
   [08-widget-replacement.md](08-widget-replacement.md), [09-events-catalog.md](09-events-catalog.md).

Always cross-check against [decisions.md](decisions.md) and [open-questions.md](open-questions.md),
which hold the current agreed decisions and the unresolved points.

---

## Document tree

| Document | Status | What it covers |
|---|---|---|
| [00-vision-scope.md](00-vision-scope.md) | 🟡 Draft | Vision, goals, non-goals, phased plan |
| [01-architecture.md](01-architecture.md) | 🟡 Draft | Layers, threading, core principles |
| [02-filesystem-and-build.md](02-filesystem-and-build.md) | 🟡 Draft | `addons/`, `savedata/`, path resolution, build |
| [03-addon-format.md](03-addon-format.md) | 🟡 Draft | Per-addon folder, `manifest.toml`, load order |
| [04-engine.md](04-engine.md) | 🟡 Draft | LuaJ, sandbox, per-addon envs, tick pump, watchdog |
| [05-lifecycle-and-reload.md](05-lifecycle-and-reload.md) | 🟡 Draft | Lifecycle, Reload UI, teardown/ownership |
| [06-lua-api.md](06-lua-api.md) | 🟠 Outline | The `hafen.*` Lua SDK — conceptual overview |
| [api-reference.md](api-reference.md) | 🟡 Draft | **Public function contract** — every `hafen.*` function by category, with verified Java backing |
| [07-ui-and-drawing.md](07-ui-and-drawing.md) | 🟠 Outline | `LuaWidget`/`LuaWindow`, `GOut`, input, overlays |
| [08-widget-replacement.md](08-widget-replacement.md) | 🟡 Draft | Intercepting/replacing server widgets |
| [09-events-catalog.md](09-events-catalog.md) | 🟠 Outline | Event catalog and core hook per event |
| [10-options-panel.md](10-options-panel.md) | 🟡 Draft | "AddOns" button, enable/disable, Reload UI |
| [11-core-hooks.md](11-core-hooks.md) | 🟡 Draft | Exact core edits (invasiveness ledger) |
| [12-security-and-permissions.md](12-security-and-permissions.md) | 🟠 Outline | Sandbox, write-actions permission, action gating |
| [13-hooks-and-interception.md](13-hooks-and-interception.md) | 🟡 Draft | **Hooks** — pre/post/replace, `preventDefault`, altering client logic |
| [14-widget-tree-reads.md](14-widget-tree-reads.md) | 🟡 Draft | GameUI-bound reads (vitals/buffs/char/FEP/action bar) — Locator + Adapters |
| [15-implementation-plan.md](15-implementation-plan.md) | 🟡 Draft | **Build order** — packages, core edits, phases, DoD |
| [16-virtual-entities.md](16-virtual-entities.md) | 🟢 Closed | **NEW capability** — client-only world ghosts (`hafen.ghost.*`) + transform gizmo (V-series) |
| [17-custom-rendering.md](17-custom-rendering.md) | 🟡 Draft | **NEW capability** — `hafen.render.*`: non-`.res` PNG images (screen + world) & glTF models (R-series) |
| [18-custom-models-gltf.md](18-custom-models-gltf.md) | 🟡 Draft | **NEW capability** — glTF 2.0 static 3D models (R3), the deep-dive for [17](17-custom-rendering.md) |
| [19-data-and-network.md](19-data-and-network.md) | 🟢 Closed | **NEW capability** — `hafen.json` (parse/encode) + `hafen.http` (external GET/POST, async, gated by a manifest `network` allowlist) (N-series) |
| [20-widget-introspection.md](20-widget-introspection.md) | 🟡 Draft | **NEW capability** — generic read-only widget-tree walk (`hafen.ui.root()`/`node()` → `WidgetNode`: `:type/:id/:children/:text/:walk`) for pure-Lua window adapters (W1) + coordinate hit-testing (`hafen.ui.at`/`mouse`/`node:rootpos`) = a WoW-`/framestack` clone (W2) (W-series) |
| [21-fonts.md](21-fonts.md) | 🟡 Draft | **NEW capability** — `hafen.font.*`: per-addon font handles (`load`→`FontHandle`) + owned overrides on client surfaces (`setFont(scope,h)`/`reset`), custom fonts in own widgets + `$font` runs; total typography control, no shared registry (F-series, [D-043](decisions.md)) |
| [code-map.md](code-map.md) | 🟢 Living | **Java code index** — key `file:line` anchors per subsystem |
| [coverage-gaps.md](coverage-gaps.md) | 🟢 Living | **Audit output** — client subsystems not yet covered + unflagged risks |
| [decisions.md](decisions.md) | 🟢 Living | Decision log (ADR-lite) |
| [open-questions.md](open-questions.md) | 🟢 Living | Unresolved questions |
| [glossary.md](glossary.md) | 🟢 Living | Hafen + addon terminology |

Status legend: 🟢 Living (continuously updated) · 🟡 Draft (written, needs review) ·
🟠 Outline (structure + known content, needs detail) · 🔵 Reviewed · ⚫ Frozen (ready to implement).

---

## Conventions

- **Language:** all specification documents are written in **English**.
- **Code references** use clickable links relative to the repo root, e.g.
  [`Widget.wdgmsg`](src/haven/Widget.java:737). Line numbers are indicative and may drift as
  upstream `dolda2000/hafen-client` is merged; the class/method name is the stable anchor.
- **Decisions** are recorded in [decisions.md](decisions.md) with an ID like `D-001`. When a
  document depends on a decision, it links to it.
- **Open questions** are recorded in [open-questions.md](open-questions.md) with an ID like
  `Q-001` and referenced inline where relevant.
- **Terminology:** Hafen-specific terms (gob, genus, wdgmsg, pagina, …) are defined once in
  [glossary.md](glossary.md).

---

## Project context (for reviewers)

- The client is the standard **`dolda2000/hafen-client`** (~537 Java files under `src/haven/`),
  forked as `brodgar-io-client`. The fork's only functional change vs upstream is the
  **proximity voice chat** under `src/io/brodgar/voice/` plus a few `haven` hooks.
- That voice integration is our **template for non-invasive integration**: a self-contained
  package + a static facade + a handful of one-line hooks in the core. See
  [11-core-hooks.md](11-core-hooks.md).
- The addon engine will live in a new **`src/io/brodgar/addon/`** package, mirroring that
  pattern. The Lua runtime is **LuaJ**, shipped as a jar exactly like the voice jar.
